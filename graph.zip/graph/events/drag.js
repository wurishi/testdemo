import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _defineProperty from '@babel/runtime/helpers/defineProperty';
import * as d3 from 'd3v7';
import CONSTANTS from '../constants.js';
import { getData } from '../utils.js';

var DragEvent = /*#__PURE__*/function () {
  function DragEvent(graph, layoutController) {
    _classCallCheck(this, DragEvent);
    _defineProperty(this, "graph", void 0);
    _defineProperty(this, "layoutController", void 0);
    _defineProperty(this, "_dragStarted", void 0);
    _defineProperty(this, "_drag", void 0);
    _defineProperty(this, "_dragStoreData", void 0);
    this.graph = graph;
    this.layoutController = layoutController;
    this._dragStarted = false;
  }
  _createClass(DragEvent, [{
    key: "setDragStoreData",
    value: function setDragStoreData(draggingNode) {
      var _this = this;
      this._dragStoreData = {
        draggingNode: draggingNode,
        dragWithNodes: [],
        initialPosition: _defineProperty({}, draggingNode.id, [draggingNode.x, draggingNode.y])
      };
      var selectedNodeIds = this.graph.selectedNodes || [];
      if (selectedNodeIds.includes(draggingNode.id) && selectedNodeIds.length > 1) {
        var nodes = getData.call(this.graph).nodes;
        selectedNodeIds.forEach(function (nid) {
          if (nid !== draggingNode.id) {
            var n = nodes.find(function (v) {
              return v.id === nid;
            });
            if (n) {
              _this._dragStoreData.dragWithNodes.push(n);
              _this._dragStoreData.initialPosition[n.id] = [n.x, n.y];
            }
          }
        });
      }
    }
  }, {
    key: "setNodesPosition",
    value: function setNodesPosition(dragId) {
      var _this2 = this;
      if (!this._dragStoreData || this._dragStoreData.draggingNode.id !== dragId) {
        return;
      }
      var draggingNode = this._dragStoreData.draggingNode;
      var deltaX = draggingNode.fx - this._dragStoreData.initialPosition[draggingNode.id][0];
      var deltaY = draggingNode.fy - this._dragStoreData.initialPosition[draggingNode.id][1];
      this._dragStoreData.dragWithNodes.forEach(function (v) {
        v.x = _this2._dragStoreData.initialPosition[v.id][0] + deltaX;
        v.y = _this2._dragStoreData.initialPosition[v.id][1] + deltaY;
        v.fx = v.x;
        v.fy = v.y;
      });
    }
  }, {
    key: "dragging",
    value: function dragging(evt, data) {
      if (!this._dragStarted) {
        /**
         * event triggered when drag started
         * both dragStart and click event triggered at the same time
         * move dragStart to here to make sure it is a drag event not a click
         */
        this.graph.event.emit(CONSTANTS.EVENT.DRAG_START, data, evt);
        this._dragStarted = true;
        evt.subject.fx = evt.subject.x;
        evt.subject.fy = evt.subject.y;
        this.setDragStoreData(data);
      } else {
        evt.subject.fx = evt.x;
        evt.subject.fy = evt.y;
        this.setNodesPosition(data.id);
        this.graph.event.emit(CONSTANTS.EVENT.DRAG, data, evt);
      }
    }
  }, {
    key: "dragEnd",
    value: function dragEnd(evt) {
      if (!evt.active) {
        this.layoutController.stop();
      }
      this._dragStarted = false;
      delete this._dragStoreData;
    }
  }, {
    key: "init",
    value: function init() {
      var _this3 = this;
      this._drag = d3.drag().on('drag', function (evt, data) {
        _this3.dragging(evt, data);
      }).on('end', function (evt, data) {
        if (_this3._dragStarted) {
          _this3.graph.event.emit(CONSTANTS.EVENT.DRAG_END, data, evt);
        }
        _this3.dragEnd(evt);
      });
    }
  }, {
    key: "drag",
    get: function get() {
      return this._drag;
    }
  }, {
    key: "dragStarted",
    get: function get() {
      return this._dragStarted;
    }
  }]);
  return DragEvent;
}();

export { DragEvent as default };
