import _toConsumableArray from '@babel/runtime/helpers/toConsumableArray';
import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _assertThisInitialized from '@babel/runtime/helpers/assertThisInitialized';
import _inherits from '@babel/runtime/helpers/inherits';
import _possibleConstructorReturn from '@babel/runtime/helpers/possibleConstructorReturn';
import _getPrototypeOf from '@babel/runtime/helpers/getPrototypeOf';
import _defineProperty from '@babel/runtime/helpers/defineProperty';
import BaseBehavior from '../base.js';
import CONSTANTS from '../../constants.js';

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var MARKER_DEF_ID = 'highlight_def_marker';
var MARKER_ID = 'highlight_end_arrow';
var FILTER_COLOR_ID = 'highlight_filtercolor';
var DEFAULT_LINK_STROKE = '#fbf300';
var DEFAULT_NODE_STROKE = '#f7e406';
var DEFAULT_NODE_FILL = '#fbf300';
var LocateHighlight = /*#__PURE__*/function (_BaseBehavior) {
  _inherits(LocateHighlight, _BaseBehavior);
  var _super = _createSuper(LocateHighlight);
  function LocateHighlight(graph, options) {
    var _this;
    _classCallCheck(this, LocateHighlight);
    _this = _super.call(this, graph, options);
    // private graph: IGraph
    _defineProperty(_assertThisInitialized(_this), "stores", void 0);
    _defineProperty(_assertThisInitialized(_this), "timeout", void 0);
    _this.timeout = options.timeout || 10 * 1000; // 10s
    _this.stores = [];
    return _this;
  }

  /**
   * restore highlighted nodes and links to original fill and stroke color
   * @param {IStore} store
   */
  _createClass(LocateHighlight, [{
    key: "restoreElements",
    value: function restoreElements(store) {
      if (store.timer) {
        clearTimeout(store.timer);
      }
      if (store.highlightNodes) {
        store.highlightNodes.selectAll('.graph__node').style('fill', function (v) {
          return v.fill;
        }).style('stroke', function (v) {
          return v.stroke;
        });
        store.highlightNodes.selectAll('image').style('filter', null);
      }
      if (store.highlightLinks) {
        store.highlightLinks.selectAll('.graph__link--path').style('stroke', function (v) {
          return v.stroke;
        }).style('marker-end', function (d) {
          return d.arrow ? 'url(#end-arrow)' : '';
        });
        store.highlightLinks.selectAll('.graph__link--path--overlay').style('stroke', function (v) {
          return v.stroke;
        }).style('opacity', '');
      }
      store.highlightLinks = undefined;
      store.highlightNodes = undefined;
      this.stores = this.stores.filter(function (v) {
        return v.id !== store.id;
      });
    }

    /**
     * highlight nodes and links according to inputs, save original color into store, and start timer
     * @param {string[]} nodeIds
     * @param {string[]} linkIds
     */
  }, {
    key: "hightlightElements",
    value: function hightlightElements(nodeIds, linkIds) {
      var _this2 = this;
      var store = {
        id: String(Date.now()),
        highlightLinks: undefined,
        highlightNodes: undefined,
        timer: null
      };
      var _this$graph$getContai = this.graph.getContainer(),
        zoomContainer = _this$graph$getContai.zoomContainer;
      var nodeGroup = zoomContainer.selectAll('.graph__node-group');
      var linkGroup = zoomContainer.selectAll('.graph__link-group');
      if (nodeIds && nodeIds.length > 0) {
        var _this$options, _this$options2;
        var nodeStroke = ((_this$options = this.options) === null || _this$options === void 0 ? void 0 : _this$options.nodeStroke) || DEFAULT_NODE_STROKE;
        var nodeFill = ((_this$options2 = this.options) === null || _this$options2 === void 0 ? void 0 : _this$options2.nodeFill) || DEFAULT_NODE_FILL;
        store.highlightNodes = nodeGroup.filter(function (v) {
          return nodeIds.includes(v.id);
        });
        store.highlightNodes.selectAll('.graph__node').style('fill', nodeFill).style('stroke', nodeStroke);
        if (nodeFill === DEFAULT_NODE_FILL) {
          store.highlightNodes.selectAll('image').style('filter', "url(#".concat(FILTER_COLOR_ID, ")"));
        }
      }
      if (linkIds && linkIds.length > 0) {
        var _this$options3;
        var linkStroke = ((_this$options3 = this.options) === null || _this$options3 === void 0 ? void 0 : _this$options3.linkStroke) || DEFAULT_LINK_STROKE;
        store.highlightLinks = linkGroup.filter(function (v) {
          return linkIds.includes(v.id);
        });
        store.highlightLinks.selectAll('.graph__link--path').style('stroke', linkStroke).style('marker-end', function (d) {
          return d.arrow ? "url(#".concat(MARKER_ID, ")") : '';
        });
        store.highlightLinks.selectAll('.graph__link--path--overlay').style('stroke', linkStroke).style('opacity', '0.3');
      }
      this.stores.forEach(function (v) {
        if (linkIds && linkIds.length > 0 && v.highlightLinks) {
          v.highlightLinks = v.highlightLinks.filter(function (t) {
            return !linkIds.includes(t.id);
          });
        }
        if (nodeIds && nodeIds.length > 0 && v.highlightNodes) {
          v.highlightNodes = v.highlightNodes.filter(function (t) {
            return !nodeIds.includes(t.id);
          });
        }
      });
      this.stores.push(store);
      store.timer = setTimeout(function () {
        return _this2.restoreElements(store);
      }, this.timeout);
    }

    /**
     *
     * @param {string[]} values
     * @param {string} field eg. 'id' 'raw.properity.xxx'
     * @param {'nodes' | 'links' | 'all'} scope optional, default is 'all'
     * @returns {nodes: IGraphNode[], links: IGraphLink[]} return matched data
     */
  }, {
    key: "locateByAttributes",
    value: function locateByAttributes(values, field, scope) {
      var targetNodes = [],
        targetLinks = [];
      if (scope !== 'nodes') {
        var findLinks = this.graph.getLinksByAttributes(values, field, 'children');
        targetLinks.push.apply(targetLinks, _toConsumableArray(findLinks.links));
        if (findLinks.subLinks.length > 0) {
          this.graph.expandAggregatedEdges(findLinks.subLinks.map(function (v) {
            return v.parentLink;
          }));
          findLinks.subLinks.forEach(function (d) {
            targetLinks.push.apply(targetLinks, _toConsumableArray(d.links));
          });
        }
      }
      if (scope !== 'links') {
        var findNodes = this.graph.getNodesByAttributes(values, field);
        targetNodes.push.apply(targetNodes, _toConsumableArray(findNodes.nodes));
      }
      // emit an event to support some extra search logic from outside, such as expand cluster node
      var extraNodes = [],
        extraLinks = [];
      this.graph.event.emit(CONSTANTS.EVENT.BEHAVIOR_LOCATEHIGHLIGHT_ONLOCATE, {
        values: values,
        field: field,
        scope: scope
      }, {
        nodes: extraNodes,
        links: extraLinks
      });
      targetLinks.push.apply(targetLinks, extraLinks);
      targetNodes.push.apply(targetNodes, extraNodes);
      this.hightlightElements(targetNodes.map(function (v) {
        return v.id;
      }), targetLinks.map(function (v) {
        return v.id;
      }));
      return {
        nodes: targetNodes,
        links: targetLinks
      };
    }

    /**
     * restore highlight and stop timer ahead of time
     */
  }, {
    key: "stopTimers",
    value: function stopTimers() {
      var _this3 = this;
      this.stores.forEach(function (s) {
        _this3.restoreElements(s);
      });
      this.stores = [];
    }
  }, {
    key: "getColorMatrixValue",
    value: function getColorMatrixValue() {
      /** https://www.w3cplus.com/svg/finessing-fecolormatrix.html */
      // TODO calculate matrix value according to `this.options.nodeFill`
      return "\n    1 0 0 0 0 ".concat("\n    0 1 0 0 0 ", "\n    -0.6 0.2 0.1 0.4 0 ", "\n    0 0 0 1 0 ", "\n    ");
    }
  }, {
    key: "init",
    value: function init() {
      var _this$options4;
      var _this$graph$getContai2 = this.graph.getContainer(),
        svg = _this$graph$getContai2.svg;
      var linkStroke = ((_this$options4 = this.options) === null || _this$options4 === void 0 ? void 0 : _this$options4.linkStroke) || DEFAULT_LINK_STROKE;
      svg.selectAll("#".concat(MARKER_DEF_ID)).remove();
      svg.append('defs').attr('id', MARKER_DEF_ID).html("\n    <marker id=\"".concat(MARKER_ID, "\" viewBox=\"0 -5 10 10\" refX=\"6\" markerWidth=\"3\" markerHeight=\"3\" orient=\"auto\"><path d=\"M0,-5L10,0L0,5\" fill=\"").concat(linkStroke, "\"></path></marker>\n    "));
      svg.append('filter').attr('id', FILTER_COLOR_ID).append('feColorMatrix').attr('type', 'matrix').attr('values', this.getColorMatrixValue());
      /** stop timers after graph update */
      this.graph.event.on(CONSTANTS.EVENT.CHANGE_GRAPH_DATA, this.stopTimers.bind(this));
    }
  }, {
    key: "destroy",
    value: function destroy() {
      this.stopTimers();
      var _this$graph$getContai3 = this.graph.getContainer(),
        svg = _this$graph$getContai3.svg;
      svg.selectAll("#".concat(MARKER_DEF_ID)).remove();
    }
  }]);
  return LocateHighlight;
}(BaseBehavior);

export { LocateHighlight as default };
