import _toConsumableArray from '@babel/runtime/helpers/toConsumableArray';
import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _assertThisInitialized from '@babel/runtime/helpers/assertThisInitialized';
import _inherits from '@babel/runtime/helpers/inherits';
import _possibleConstructorReturn from '@babel/runtime/helpers/possibleConstructorReturn';
import _getPrototypeOf from '@babel/runtime/helpers/getPrototypeOf';
import _defineProperty from '@babel/runtime/helpers/defineProperty';
import * as d3 from 'd3v7';
import BaseBehavior from '../base.js';
import { UpdateGraphScope } from '../../types.js';
import CONSTANTS from '../../constants.js';
import { clickcancel, getLinksConnection, getData, getRelatedNodesAndLinks, getTickCount, getDataByAttributes, getGraphDataWhenNodesRemove, getGraphNodeUnions, setLinksAttributes } from '../../utils.js';
import { calculateLinkPath, drawNodes, drawLinks, updateLinkLabelPosition } from '../../layout/drawUtils.js';
import { CLUSTER_SUBITEM_FIELD, getLinkNodesId, getNewClusteredLinks, calculateClusterNodesRadius, clusterGraphData, unclusterGraphData, getGroupedLinkData, moveIntoCluster, moveOutofCluster, extractLinks, restoreClusterData, getLinkTypeValue } from './utils.js';

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var CHILDREN_FIELD = 'children';
var DEFAULT_CLUSTERNODE_ATTR = {
  collapse: {
    fill: '#A194D4',
    strokeWidth: 2,
    stroke: '#640487',
    badgeShow: true,
    badgePosition: 'topRight',
    badgeBackground: '#000',
    badgeColor: '#fff',
    badgeStroke: '#fff',
    badgeStrokeWidth: 2,
    badgeFontsize: '0.85rem'
  },
  uncollapse: {
    fill: '#f1eff9',
    strokeWidth: 2,
    stroke: '#640487',
    badgeShow: false
  }
};
var SubNodes = /*#__PURE__*/function (_BaseBehavior) {
  _inherits(SubNodes, _BaseBehavior);
  var _super = _createSuper(SubNodes);
  function SubNodes(graph, options) {
    var _this;
    _classCallCheck(this, SubNodes);
    _this = _super.call(this, graph, options);
    // private graph: IGraph
    _defineProperty(_assertThisInitialized(_this), "clusterSubItemField", CLUSTER_SUBITEM_FIELD);
    _defineProperty(_assertThisInitialized(_this), "storeNodeRadius", void 0);
    _defineProperty(_assertThisInitialized(_this), "storeNodeAttr", void 0);
    _defineProperty(_assertThisInitialized(_this), "storeNodeMap", void 0);
    _defineProperty(_assertThisInitialized(_this), "subNodeGroup", void 0);
    _defineProperty(_assertThisInitialized(_this), "clusterSubLinksMap", void 0);
    _defineProperty(_assertThisInitialized(_this), "clusterOuterLinkDraw", void 0);
    _defineProperty(_assertThisInitialized(_this), "clusterSubLinkDraw", void 0);
    _defineProperty(_assertThisInitialized(_this), "clusterLinksConnection", void 0);
    _defineProperty(_assertThisInitialized(_this), "linkTypeFilter", void 0);
    _defineProperty(_assertThisInitialized(_this), "unDeletableNodeIds", void 0);
    _defineProperty(_assertThisInitialized(_this), "enableDragInOut", void 0);
    _defineProperty(_assertThisInitialized(_this), "isClusterPositionFixed", void 0);
    _defineProperty(_assertThisInitialized(_this), "dragData", void 0);
    _defineProperty(_assertThisInitialized(_this), "getSubLinkPath", function (d) {
      var _this$storeNodeMap$so, _this$storeNodeMap$ta;
      var isLabelPath = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      var _getLinkNodesId = getLinkNodesId(d),
        sourceId = _getLinkNodesId.sourceId,
        targetId = _getLinkNodesId.targetId;
      var source = (_this$storeNodeMap$so = _this.storeNodeMap[sourceId]) === null || _this$storeNodeMap$so === void 0 ? void 0 : _this$storeNodeMap$so.data;
      var target = (_this$storeNodeMap$ta = _this.storeNodeMap[targetId]) === null || _this$storeNodeMap$ta === void 0 ? void 0 : _this$storeNodeMap$ta.data;
      if (!source || !target) {
        return '';
      }
      return calculateLinkPath(_objectSpread(_objectSpread({}, d), {}, {
        source: source,
        target: target
      }), _this.clusterLinksConnection, isLabelPath ? source.x >= target.x : false);
    });
    _defineProperty(_assertThisInitialized(_this), "getRealPosition", function (nodeId) {
      var preX = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
      var preY = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
      var d = _this.storeNodeMap[nodeId];
      var x = d.data.x + preX,
        y = d.data.y + preY;
      if (d.parentId) {
        return _this.getRealPosition(d.parentId, x, y);
      }
      return {
        x: x,
        y: y
      };
    });
    _defineProperty(_assertThisInitialized(_this), "getLinkPath", function (d) {
      var isLabelPath = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      var sourceId = typeof d.source === 'string' ? d.source : d.source.id;
      var targetId = typeof d.target === 'string' ? d.target : d.target.id;
      if (!_this.storeNodeMap[sourceId] || !_this.storeNodeMap[targetId]) {
        return '';
      }
      var sourcePosition = _this.getRealPosition(sourceId);
      var targetPosition = _this.getRealPosition(targetId);
      return calculateLinkPath(_objectSpread(_objectSpread({}, d), {}, {
        source: {
          id: sourceId,
          x: sourcePosition.x,
          y: sourcePosition.y,
          r: _this.storeNodeMap[sourceId].data.r
        },
        target: {
          id: targetId,
          x: targetPosition.x,
          y: targetPosition.y,
          r: _this.storeNodeMap[targetId].data.r
        }
      }), _this.clusterLinksConnection, isLabelPath ? sourcePosition.x >= targetPosition.x : false);
    });
    _this.clusterSubItemField = (options === null || options === void 0 ? void 0 : options.clusterSubItemField) || CLUSTER_SUBITEM_FIELD;
    /** storeNodeR - used to store cluster node radius value, so that circle can restore to normal size after subnodes hide */
    _this.storeNodeRadius = {};
    _this.clusterSubLinksMap = {};
    _this.clusterLinksConnection = {};
    _this.linkTypeFilter = options.linkTypeFilter;
    _this.unDeletableNodeIds = options.unDeletableNodeIds || [];
    _this.enableDragInOut = !!options.enableDragInOut;
    return _this;
  }
  /**
   * draw subnodes under specific .graph__node-group elements
   * draw sublinks under specific .graph__node-group elements
   * draw outerlinks when subnodes show
   * call drawUtils to be sure no duplicated draw logic
   */
  _createClass(SubNodes, [{
    key: "drawSubNodes",
    value: function drawSubNodes() {
      var _this2 = this;
      var _this$graph$getContai = this.graph.getContainer(),
        nodeGroup = _this$graph$getContai.nodeGroup,
        linkGroup = _this$graph$getContai.linkGroup,
        zoomContainer = _this$graph$getContai.zoomContainer;
      var childFieldName = CHILDREN_FIELD;
      var updateNodeIds = [];

      /** outer links data */
      var clusterLinks = new Set();
      var linksRelatedMap = {}; // {subLinkId: clusterLinkId}

      /** draw subnodes inside cluster */
      var subNodesGroupContainer = nodeGroup.selectAll('.graph__node__behavior-subnodes').data(function (v) {
        var subnodes = v[childFieldName] || [];
        var sublinks = _this2.clusterSubLinksMap[v.id] || [];
        /** check subnodes has position, if no position applied, calculate for it */
        var noposition = subnodes.some(function (n) {
          return typeof n.x !== 'number' || typeof n.y !== 'number';
        });
        if (noposition) {
          _this2.calculateSubnodesPosition(subnodes, sublinks);
          _this2.storeClusterNodesRadius(v);
          updateNodeIds.push(v.id);
        } else if (v[_this2.clusterSubItemField] && !v.r) {
          _this2.storeClusterNodesRadius(v);
          updateNodeIds.push(v.id);
        }
        return v[childFieldName] && v[childFieldName].length > 0 ? [v] : [];
      }).join('g').classed('graph__node__behavior-subnodes', true);
      if (updateNodeIds.length > 0) {
        this.graph.updateGraph([], updateNodeIds);
        return;
      }
      var clusterNodeGroups = nodeGroup.filter(function (v) {
        return v[childFieldName] && v[childFieldName].length > 0;
      });
      clusterNodeGroups.selectAll('.graph__node__icon').remove();

      /** custom label content */
      if (this.options.getNodeLabelDom) {
        nodeGroup.filter(function (v) {
          return !!v[_this2.clusterSubItemField];
        }).selectAll('.graph__node__label-group').html(function (d, idx, list) {
          var dom = list[idx];
          var level = dom.getAttribute('labelLevel');
          return _this2.options.getNodeLabelDom(d, dom.innerHTML, level);
        });
      }

      /** draw subnodes */
      var subNodeGroup = drawNodes({
        container: subNodesGroupContainer,
        nodeGroupClassName: 'graph__node-sub',
        nodeGroupSelectedClassName: 'graph__node-sub-selected',
        nodeData: function nodeData(v) {
          return v[childFieldName];
        },
        selectedNodes: this.graph.selectedNodes || [],
        showSecondaryLabel: this.graph.getOption('showSecondaryLabel'),
        getCustomShapePath: this.graph.getOption('getCustomShapePath')
      });
      subNodeGroup.attr('transform', function (d) {
        return "translate(".concat(d.x, ",").concat(d.y, ")");
      });
      subNodeGroup.call(clickcancel({
        stopPropagation: true
      }).on('click', function (evt, data) {
        _this2.graph.event.emit(CONSTANTS.EVENT.NODE_CLICK, data, evt);
      }).on('dblclick', function (evt, data) {
        _this2.graph.event.emit(CONSTANTS.EVENT.NODE_DBLCLICK, data, evt);
      }));
      this.subNodeGroup = subNodeGroup;
      this.registerDragEvent();
      this.updateClusterSelectedStyle();

      /** cluster links hide when subnodes show */
      var shownClusterNodeIds = subNodesGroupContainer.data().map(function (v) {
        return v.id;
      });
      linkGroup.style('visibility', function (v) {
        if (!v[_this2.clusterSubItemField]) {
          return '';
        }
        var hide = shownClusterNodeIds.includes(v.target.id) || shownClusterNodeIds.includes(v.source.id);
        if (hide) {
          v[_this2.clusterSubItemField].forEach(function (c) {
            clusterLinks.add(c);
            linksRelatedMap[c.id] = v.id;
          });
        }
        return hide ? 'hidden' : '';
      });

      /** draw sub links inside cluster */
      var subLinksGroupContainer = nodeGroup.selectAll('.graph__node__behavior-sublinks').data(function (v) {
        return v[childFieldName] && v[childFieldName].length > 0 ? [v] : [];
      }).join(function (enter) {
        return enter.insert('g', '.graph__node__behavior-subnodes');
      }).classed('graph__node__behavior-sublinks', true);
      this.clusterSubLinkDraw = drawLinks({
        container: subLinksGroupContainer,
        linkGroupClassName: 'graph__link-sub',
        linkGroupSelectedClassName: 'graph__link-sub-selected',
        linkData: function linkData(v) {
          var _v$_this2$clusterSubI;
          return ((_v$_this2$clusterSubI = v[_this2.clusterSubItemField]) === null || _v$_this2$clusterSubI === void 0 ? void 0 : _v$_this2$clusterSubI.links) || [];
        },
        selectedLinks: this.graph.selectedLinks || []
      });
      this.clusterSubLinkDraw.linksOverlay.on('mouseover', function (evt) {
        evt.target.classList.add('graph-opacity');
      });
      this.clusterSubLinkDraw.linksOverlay.on('mouseout', function (evt) {
        evt.target.classList.remove('graph-opacity');
      });
      this.clusterSubLinkDraw.linksOverlay.call(clickcancel({
        stopPropagation: true
      }).on('click', function (evt, data) {
        _this2.graph.event.emit(CONSTANTS.EVENT.LINK_CLICK, data, evt);
      }).on('dblclick', function (evt, data) {
        _this2.graph.event.emit(CONSTANTS.EVENT.LINK_DBLCLICK, data, evt);
      }));
      this.clusterLinksConnection = getLinksConnection({
        links: [].concat(_toConsumableArray(Array.from(clusterLinks)), _toConsumableArray(this.clusterSubLinkDraw.linkGroup.data())),
        nodes: []
      });
      this.updateSubLinksPath(); // if subnodes requires force drag in future, need move this into 'this.updateLinkPosition'

      /** draw outer links when subnodes show */
      var clusterLinksContainer = zoomContainer.select('.cluster__links');
      if (clusterLinksContainer.size() === 0) {
        clusterLinksContainer = zoomContainer.append('g')
        // .insert('g', ':first-child')
        .attr('class', 'cluster__links');
      }
      var graphSelectedLinks = this.graph.selectedLinks || [];
      var clusterOuerLinkSelected = Array.from(clusterLinks).filter(function (v) {
        if (graphSelectedLinks.includes(v.id)) {
          return true;
        }
        var sub = v[_this2.clusterSubItemField] || [];
        return sub.some(function (s) {
          return graphSelectedLinks.includes(s.id);
        });
      }).map(function (v) {
        return v.id;
      });
      var clusterLinksDraw = drawLinks({
        container: clusterLinksContainer,
        linkGroupClassName: 'cluster__link',
        linkGroupSelectedClassName: 'cluster__link-selected',
        linkData: Array.from(clusterLinks),
        selectedLinks: clusterOuerLinkSelected
      });
      this.clusterOuterLinkDraw = clusterLinksDraw;
      clusterLinksDraw.links.attr('d', function (d) {
        return calculateLinkPath(d, _this2.clusterLinksConnection);
      });
      this.clusterOuterLinkDraw.linksOverlay.on('mouseover', function (evt) {
        evt.target.classList.add('graph-opacity');
      });
      this.clusterOuterLinkDraw.linksOverlay.on('mouseout', function (evt) {
        evt.target.classList.remove('graph-opacity');
      });
      this.clusterOuterLinkDraw.linksOverlay.call(clickcancel().on('click', function (evt, data) {
        _this2.graph.event.emit(CONSTANTS.EVENT.LINK_CLICK, data, evt);
      }).on('dblclick', function (evt, data) {
        _this2.graph.event.emit(CONSTANTS.EVENT.LINK_DBLCLICK, data, evt);
      }));

      /** send/receive filter && highlightrelations will listen to this event, and apply these extra links style */
      this.graph.event.emit(CONSTANTS.EVENT.APPLY_EXTRA_LINKS, {
        links: clusterLinksDraw.linkGroup,
        relatedMap: linksRelatedMap
      });

      /** generate link path */
      this.updateLinkPosition();
    }

    /**
     * if user enable drag in out behavior
     * register drag events to subnodes
     * boardcast 'dragstart' 'dragging' 'dragend' events
     */
  }, {
    key: "registerDragEvent",
    value: function registerDragEvent() {
      var _this3 = this;
      if (this.enableDragInOut) {
        this.subNodeGroup.call(d3.drag().on('drag', function (evt, data) {
          if (!_this3.enableDragInOut) {
            return;
          }
          if (!_this3.dragData) {
            _this3.graph.event.emit(CONSTANTS.EVENT.DRAG_START, data, evt);
          } else {
            _this3.graph.event.emit(CONSTANTS.EVENT.DRAG, data, evt);
          }
        }).on('end', function (evt, node) {
          if (!_this3.enableDragInOut) {
            return;
          }
          _this3.graph.event.emit(CONSTANTS.EVENT.DRAG_END, node, evt);
        }));
      } else {
        this.subNodeGroup.on('.drag', null);
      }
    }
  }, {
    key: "onNodeDragStart",
    value: function onNodeDragStart(node, evt) {
      var _this$storeNodeMap$no,
        _this4 = this,
        _this$storeNodeMap$pa;
      if (node[this.clusterSubItemField] || !this.enableDragInOut || this.dragData) {
        /** ignore cluster node drag event, and not enabled drag */
        return;
      }
      var originalPosition = _defineProperty({}, node.id, [node.x, node.y]);
      var parentId = (_this$storeNodeMap$no = this.storeNodeMap[node.id]) === null || _this$storeNodeMap$no === void 0 ? void 0 : _this$storeNodeMap$no.parentId;
      var selectedIncludeCluster = false;
      var dragWithNodes = [];
      if (this.graph.selectedNodes.includes(node.id)) {
        this.graph.selectedNodes.forEach(function (nid) {
          if (selectedIncludeCluster || nid === node.id) {
            return;
          }
          if (_this4.storeNodeMap[nid].data[_this4.clusterSubItemField]) {
            selectedIncludeCluster = true;
            return;
          }
          var n = _this4.storeNodeMap[nid];
          if (n.parentId === parentId) {
            dragWithNodes.push(n.data);
            originalPosition[nid] = [n.data.x, n.data.y];
          }
        });
      }
      if (this.graph.selectedNodes.includes(node.id) && selectedIncludeCluster) {
        /** if user select multiple nodes includes one or more cluster nodes, not handle this interaction */
        return;
      }
      var _this$graph$getContai2 = this.graph.getContainer(),
        nodeGroup = _this$graph$getContai2.nodeGroup;
      var clusterNodeGroup = nodeGroup.filter(function (v) {
        return !!v[_this4.clusterSubItemField];
      });
      this.dragData = {
        draggingNode: node,
        draggingElement: evt.sourceEvent.target,
        dragWithNodes: dragWithNodes,
        parentNode: parentId ? (_this$storeNodeMap$pa = this.storeNodeMap[parentId]) === null || _this$storeNodeMap$pa === void 0 ? void 0 : _this$storeNodeMap$pa.data : undefined,
        clusterNodeGroup: clusterNodeGroup,
        originalPosition: originalPosition
      };
      if (parentId) {
        clusterNodeGroup.filter(function (v) {
          return v.id === parentId;
        }).select('.graph__node').style('stroke-dasharray', '10, 5');
      }
      this.fixClusterPosition();
    }
  }, {
    key: "onNodeDragging",
    value: function onNodeDragging(node, evt) {
      var _this5 = this;
      if (node[this.clusterSubItemField] || !this.enableDragInOut || !this.dragData) {
        /** ignore cluster node drag event, and not enabled drag */
        return;
      }
      if (this.dragData.parentNode) {
        node.x = evt.x;
        node.y = evt.y;
        var updateNodeIds = [node.id].concat(_toConsumableArray(this.dragData.dragWithNodes.map(function (v) {
          return v.id;
        })));
        this.dragData.dragWithNodes.forEach(function (v) {
          v.x += evt.dx;
          v.y += evt.dy;
        });
        this.subNodeGroup.filter(function (s) {
          return updateNodeIds.includes(s.id);
        }).attr('transform', function (d) {
          return "translate(".concat(d.x, ",").concat(d.y, ")");
        });
        this.updateSubLinksPath();
        this.updateClusterOuterLinksPath();
        var isOutsideOfParent = Math.sqrt(evt.x * evt.x + evt.y * evt.y) > this.dragData.parentNode.r;
        if (isOutsideOfParent) {
          this.showDropMask(this.dragData.parentNode, false);
          this.dragData.dropOut = this.dragData.parentNode;
        } else {
          this.removeDropMask(this.dragData.parentNode);
          this.dragData.dropOut = undefined;
        }
      }
      var nodex = node.x,
        nodey = node.y;
      if (this.dragData.parentNode) {
        nodex += this.dragData.parentNode.x;
        nodey += this.dragData.parentNode.y;
      }
      var dropIn;
      this.dragData.clusterNodeGroup.data().forEach(function (v) {
        if (!_this5.dragData.parentNode || _this5.dragData.parentNode.id !== v.id) {
          var deltX = nodex - v.x,
            deltY = nodey - v.y;
          var isOutSide = Math.sqrt(deltX * deltX + deltY * deltY) > v.r;
          if (isOutSide) {
            _this5.removeDropMask(v);
          } else {
            _this5.showDropMask(v, true);
            dropIn = v;
          }
        }
      });
      if (dropIn !== this.dragData.dropIn) {
        this.dragData.clusterNodeGroup.select('.graph__node').style('stroke-dasharray', function (d) {
          return dropIn && d.id === dropIn.id || _this5.dragData.dropOut && d.id === _this5.dragData.dropOut.id ? '10, 5' : null;
        });
      }
      this.dragData.dropIn = dropIn;
    }
  }, {
    key: "onNodeDragEnd",
    value: function onNodeDragEnd(node) {
      var _this6 = this;
      if (node[this.clusterSubItemField] || !this.enableDragInOut || !this.dragData) {
        /** ignore cluster node drag event, and not enabled drag */
        return;
      }
      var moveActiveNodeIds = [node.id].concat(_toConsumableArray(this.dragData.dragWithNodes.map(function (v) {
        return v.id;
      })));
      var restoreOriginalPosition = function restoreOriginalPosition(restorNodeIds) {
        if (!restorNodeIds || restorNodeIds.includes(node.id)) {
          node.x = _this6.dragData.originalPosition[node.id][0];
          node.y = _this6.dragData.originalPosition[node.id][1];
        }
        _this6.dragData.dragWithNodes.forEach(function (v) {
          if (!restorNodeIds || restorNodeIds.includes(v.id)) {
            v.x = _this6.dragData.originalPosition[v.id][0];
            v.y = _this6.dragData.originalPosition[v.id][1];
            if (v.hasOwnProperty('fx') || v.hasOwnProperty('fy')) {
              v.fx = v.x;
              v.fy = v.y;
            }
          }
        });
        var updateNodeIds = [node.id].concat(_toConsumableArray(_this6.dragData.dragWithNodes.map(function (v) {
          return v.id;
        })));
        if (_this6.dragData.parentNode) {
          _this6.subNodeGroup.filter(function (s) {
            return updateNodeIds.includes(s.id);
          }).attr('transform', function (d) {
            return "translate(".concat(_this6.dragData.originalPosition[d.id].join(','), ")");
          });
          _this6.updateSubLinksPath();
          _this6.updateClusterOuterLinksPath();
        } else {
          node.fx = node.x;
          node.fy = node.y;
          _this6.graph.updateGraph([UpdateGraphScope.position]);
        }
      };
      this.dragData.clusterNodeGroup.select('.graph__node').style('stroke-dasharray', null);
      if (this.dragData.parentNode) {
        if (!this.dragData.dropOut) {
          restoreOriginalPosition();
        } else {
          var restoreSubIds = [];
          if (this.options.shouldDragOutofCluster) {
            var activeSubIds = this.options.shouldDragOutofCluster(moveActiveNodeIds.map(function (v) {
              var _this6$storeNodeMap$v;
              return (_this6$storeNodeMap$v = _this6.storeNodeMap[v]) === null || _this6$storeNodeMap$v === void 0 ? void 0 : _this6$storeNodeMap$v.data;
            }), this.dragData.parentNode) || [];
            restoreSubIds = moveActiveNodeIds.filter(function (v) {
              return !activeSubIds.includes(v);
            });
            moveActiveNodeIds = activeSubIds;
          }
          if (restoreSubIds.length > 0) {
            restoreOriginalPosition(restoreSubIds);
          }
          if (moveActiveNodeIds.length > 0) {
            this.moveOutofCluster(moveActiveNodeIds, this.dragData.parentNode.id);
          }
        }
      }
      if (this.dragData.dropIn) {
        var restoreNodeIds = [];
        if (this.options.shouldDragIntoCluster) {
          var activeNodeIds = this.options.shouldDragIntoCluster(moveActiveNodeIds.map(function (v) {
            var _this6$storeNodeMap$v2;
            return (_this6$storeNodeMap$v2 = _this6.storeNodeMap[v]) === null || _this6$storeNodeMap$v2 === void 0 ? void 0 : _this6$storeNodeMap$v2.data;
          }), this.dragData.dropIn) || [];
          restoreNodeIds = moveActiveNodeIds.filter(function (v) {
            return !activeNodeIds.includes(v);
          });
          moveActiveNodeIds = activeNodeIds;
        }
        if (restoreNodeIds.length > 0) {
          restoreOriginalPosition(restoreNodeIds);
        }
        if (moveActiveNodeIds.length > 0) {
          this.moveIntoCluster(moveActiveNodeIds, this.dragData.dropIn.id);
        }
      }
      this.removeDropMask();
      this.dragData = undefined;
    }

    /**
     * when outernode drag into area of one cluster, show drop mask
     * @param node
     * @param isDropIn
     */
  }, {
    key: "showDropMask",
    value: function showDropMask(node, isDropIn) {
      var _this$dragData,
        _this7 = this;
      var clusterNode = (_this$dragData = this.dragData) === null || _this$dragData === void 0 ? void 0 : _this$dragData.clusterNodeGroup.filter(function (v) {
        return v.id === node.id;
      });
      if (!clusterNode || clusterNode.selectAll('.graph__node__behavior-dropmask').size() > 0) {
        return;
      }
      clusterNode.style('opacity', 0.8);
      var mask = clusterNode.append('g').classed('graph__node__behavior-dropmask', true);
      mask.append('path').attr('d', function () {
        var shapePath = this.parentNode.parentNode.querySelector('.graph__node');
        return shapePath === null || shapePath === void 0 ? void 0 : shapePath.getAttribute('d');
      }).style('fill', function (d) {
        return _this7.getClusterNodeAttr(d, false).fill;
      }).style('opacity', function (d) {
        return d[CHILDREN_FIELD] ? 0.8 : 1;
      });
      mask.append('text').text(isDropIn ? '+' : '-').style('font-size', '40px').style('text-anchor', 'middle').style('fill', '#fff');
      mask.append('text').text(isDropIn ? 'Drop here' : 'Drop outside').style('font-size', '14px').attr('y', 15).style('text-anchor', 'middle').style('fill', '#fff');
    }

    /**
     * when dragging node move out of one cluster, remove drop mask
     * @param node
     */
  }, {
    key: "removeDropMask",
    value: function removeDropMask(node) {
      var _this$dragData2;
      var nodeGroup = (_this$dragData2 = this.dragData) === null || _this$dragData2 === void 0 ? void 0 : _this$dragData2.clusterNodeGroup;
      if (!nodeGroup) {
        return;
      }
      if (node) {
        nodeGroup = nodeGroup.filter(function (v) {
          return v.id === node.id;
        });
      }
      nodeGroup.style('opacity', null);
      nodeGroup.selectAll('.graph__node__behavior-dropmask').remove();
    }

    /**
     * update sublinks path and label position
     */
  }, {
    key: "updateSubLinksPath",
    value: function updateSubLinksPath() {
      var _this8 = this;
      if (!this.clusterSubLinkDraw) {
        return;
      }
      this.clusterSubLinkDraw.links.attr('d', function (d) {
        return _this8.getSubLinkPath(d, false);
      });
    }
  }, {
    key: "updateClusterOuterLinksPath",
    value:
    /**
     * update outerlinks path and label position
     */
    function updateClusterOuterLinksPath() {
      var _this9 = this;
      if (!this.clusterOuterLinkDraw) {
        return;
      }
      this.clusterOuterLinkDraw.links.attr('d', function (d) {
        return _this9.getLinkPath(d);
      });
    }
  }, {
    key: "updateLinkPosition",
    value:
    /**
     * show/hide cluster related links
     * executed when layout tick
     * call `updateClusterOuterLinksPath`
     * @param {boolean} hideClusterLinks whether to hide cluster outerlinks forcely
     */
    function updateLinkPosition() {
      var _this$clusterOuterLin, _this$clusterSubLinkD;
      var hideClusterLinks = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
      (_this$clusterOuterLin = this.clusterOuterLinkDraw) === null || _this$clusterOuterLin === void 0 ? void 0 : _this$clusterOuterLin.linkGroup.style('display', hideClusterLinks ? 'none' : '');
      (_this$clusterSubLinkD = this.clusterSubLinkDraw) === null || _this$clusterSubLinkD === void 0 ? void 0 : _this$clusterSubLinkD.linkGroup.style('display', hideClusterLinks ? 'none' : '');
      if (hideClusterLinks) {
        return;
      }
      this.updateClusterOuterLinksPath();
    }

    /**
     * return node data accroding to vertical provided `options.getClusterNodeAttributes` along with some default attributes
     * @param {IGraphNode} node
     * @param {boolean} show
     * @returns Omit<Partial<IGraphNode>, 'id' | 'children'>
     */
  }, {
    key: "getClusterNodeAttr",
    value: function getClusterNodeAttr(node, show) {
      var defaultAttr = show ? DEFAULT_CLUSTERNODE_ATTR.uncollapse : DEFAULT_CLUSTERNODE_ATTR.collapse;
      var presetAttr = {
        fill: defaultAttr.fill,
        stroke: defaultAttr.stroke,
        strokeWidth: defaultAttr.strokeWidth,
        badges: defaultAttr.badgeShow ? [{
          position: defaultAttr.badgePosition,
          text: String(node[this.clusterSubItemField].nodes.length),
          background: defaultAttr.badgeBackground,
          color: defaultAttr.badgeColor,
          stroke: defaultAttr.badgeStroke,
          strokeWidth: defaultAttr.badgeStrokeWidth,
          fontSize: defaultAttr.badgeFontsize
        }] : []
      };
      return _objectSpread(_objectSpread({}, presetAttr), this.options.getClusterNodeAttributes && this.options.getClusterNodeAttributes(node, presetAttr));
    }

    /**
     * show or hide subnodes through update 'children' field of node
     * update graph data after that which will trigger draw
     * include cluster links under toggle logic
     * @param {string[]} parentNodeIds
     * @param {boolean} show optional
     * @returns {{[nodeId:string]:boolean}}
     */
  }, {
    key: "toggleCluster",
    value: function toggleCluster(parentNodeIds, show) {
      var _this10 = this;
      var graphData = getData.call(this.graph);
      var clusterSubItemField = this.clusterSubItemField;
      var changeResult = {};
      var hasChange = false;
      var pendingNodes = [];
      var toggleNodeIds = [];
      var newData = _objectSpread(_objectSpread({}, graphData), {}, {
        nodes: graphData.nodes.map(function (v) {
          if (parentNodeIds.indexOf(v.id) === -1 || !v[clusterSubItemField]) {
            return v;
          }
          var currentShowStatus = !!v[CHILDREN_FIELD];
          if (typeof show === 'boolean' && show === currentShowStatus) {
            changeResult[v.id] = show;
            return v;
          }
          if (!_this10.storeNodeRadius[v.id]) {
            _this10.storeClusterNodesRadius(v);
          }
          toggleNodeIds.push(v.id);
          show = !currentShowStatus;
          if (show) {
            var _v$clusterSubItemFiel;
            pendingNodes.push.apply(pendingNodes, _toConsumableArray(((_v$clusterSubItemFiel = v[clusterSubItemField]) === null || _v$clusterSubItemFiel === void 0 ? void 0 : _v$clusterSubItemFiel.nodes) || []));
          } else {
            pendingNodes.push(v);
          }
          Object.assign(v, _this10.getClusterNodeAttr(v, show));
          hasChange = true;
          changeResult[v.id] = show;
          v[CHILDREN_FIELD] = v[CHILDREN_FIELD] ? undefined : v[clusterSubItemField].nodes;
          v.r = !show ? _this10.storeNodeRadius[v.id].collapseRadius : _this10.storeNodeRadius[v.id].realRadius;
          _this10.clusterSubLinksMap[v.id] = v[clusterSubItemField].links || [];
          return v;
        })
      });
      if (!hasChange) {
        return changeResult;
      }
      this.storeNodeData(newData);
      /**
       * if existing grouplinks between two cluster nodes and toggle one of them
       * will re-cluster these realated links
       */
      var relatedNodesLinks = getRelatedNodesAndLinks(toggleNodeIds, newData);
      relatedNodesLinks.nodes.forEach(function (v) {
        if (!toggleNodeIds.includes(v.id)) {
          if (v[CHILDREN_FIELD]) {
            pendingNodes.push.apply(pendingNodes, _toConsumableArray(v[CHILDREN_FIELD]));
          } else {
            pendingNodes.push(v);
          }
        }
      });
      relatedNodesLinks.links.forEach(function (v) {
        if (v[clusterSubItemField] && v.source[clusterSubItemField] && v.target[clusterSubItemField]) {
          v[clusterSubItemField] = v[clusterSubItemField].map(function (l) {
            return l[clusterSubItemField] || l;
          }).flat();
          var sShow = !!v.source[CHILDREN_FIELD],
            tShow = !!v.target[CHILDREN_FIELD];
          if (sShow !== tShow) {
            var newlinks = getNewClusteredLinks({
              pendingNodes: pendingNodes,
              clusterLinks: [v],
              subItemFieldName: _this10.clusterSubItemField,
              linkTypeFilter: _this10.linkTypeFilter,
              groupLinkAttr: _this10.options.getClusterLinkAttributes
            });
            v[clusterSubItemField] = newlinks;
          }
        }
      });
      this.graph.updateData(newData).restart();
      return changeResult;
    }

    /**
     * calculate and set new position to subnodes
     * based on results of force simulation
     * @param {IGraphNode} clusterNode
     */
  }, {
    key: "calculateSubnodesPositionByClusterSubItemField",
    value: function calculateSubnodesPositionByClusterSubItemField(clusterNode) {
      var subItems = clusterNode[this.clusterSubItemField];
      var subNodes = subItems.nodes;
      var subLinks = subItems.links;
      this.calculateSubnodesPosition(subNodes, subLinks);
      this.storeClusterNodesRadius(clusterNode);
    }

    /**
     * calculate node radius
     * collapse level - by number
     * show subnodes level - by area
     * @param {IGraphNode} clusterNode
     */
  }, {
    key: "storeClusterNodesRadius",
    value: function storeClusterNodesRadius(clusterNode) {
      var isShowSubNodes = !!clusterNode[CHILDREN_FIELD];
      this.storeNodeRadius[clusterNode.id] = calculateClusterNodesRadius({
        clusterNode: clusterNode,
        clusterSubItemField: this.clusterSubItemField
      });
      clusterNode.r = isShowSubNodes ? this.storeNodeRadius[clusterNode.id].realRadius : this.storeNodeRadius[clusterNode.id].collapseRadius;
    }

    /**
     * calculate and set new position to subnodes
     * based on results of force simulation
     * @param {IGraphNode[]} subNodes
     * @param {IGraphLink[]} subLinks
     */
  }, {
    key: "calculateSubnodesPosition",
    value: function calculateSubnodesPosition(subNodes, subLinks) {
      subNodes.forEach(function (v) {
        ['vx', 'vy', 'fx', 'fy', 'x', 'y'].forEach(function (k) {
          return delete v[k];
        });
      });
      try {
        var sim = d3.forceSimulation(subNodes).force('link', d3.forceLink(subLinks).id(function (d) {
          return d.id;
        }).distance(100).strength(0.02)).force('charge', d3.forceManyBody()
        // .strength(-100)
        // .distanceMax(100),
        ).force('collide', d3.forceCollide().radius(function (v) {
          return (v.r || CONSTANTS.DEFAULT_NODE_RADIUS) * 1.5;
        })).force('center', d3.forceCenter()).stop();
        var tickCount = getTickCount(sim);
        sim.tick(tickCount);
      } catch (err) {
        console.log('has error when calculate subnodes position', err);
      }
    }

    /**
     * get and update new graphdata, group nodes by filter
     * calculate subnodes' position before draw
     * @param {IClusterNodesOptions} options
     * @return {IGraphNode[]} return new created cluster nodes
     */
  }, {
    key: "clusterNodes",
    value: function clusterNodes(options) {
      var _this11 = this;
      if (options.subItemFieldName) {
        this.clusterSubItemField = options.subItemFieldName;
      }
      var groupNodeAttr = function groupNodeAttr(node, groupValue) {
        return _objectSpread({
          labels: {
            primary: "cluster-".concat(groupValue),
            secondary: "cluster-".concat(groupValue)
          }
        }, _this11.getClusterNodeAttr(node, false));
      };
      var groupLinkAttr = this.options.getClusterLinkAttributes ? function (link, typeValue) {
        return _this11.options.getClusterLinkAttributes(link, typeValue);
      } : undefined;
      var newGraphData = clusterGraphData({
        data: options.data || this.graph.getData(),
        filter: options.filter,
        linkTypeFilter: this.linkTypeFilter,
        subItemFieldName: this.clusterSubItemField,
        allowSingleNode: this.options.allowSingleNode
      }, groupNodeAttr, groupLinkAttr);
      if (newGraphData.newClusterNodes.length === 0) {
        return [];
      }
      newGraphData.newClusterNodes.forEach(function (n) {
        _this11.calculateSubnodesPositionByClusterSubItemField(n);
        _this11.clusterSubLinksMap[n.id] = n[_this11.clusterSubItemField].links;
      });
      this.graph.updateData(newGraphData).restart();
      return newGraphData.newClusterNodes;
    }

    /**
     * get and update new graphdata, ungroup nodes by clusterNodeId
     * subnodes position will be set same as when they are in cluster bubble
     * @param {string[]} nodeIds
     */
  }, {
    key: "unclusterNodes",
    value: function unclusterNodes(nodeIds) {
      var _this12 = this;
      var graphData = getData.call(this.graph);
      graphData.nodes.filter(function (n) {
        return nodeIds.includes(n.id);
      }).forEach(function (n) {
        var _n$_this12$clusterSub;
        var subnodes = ((_n$_this12$clusterSub = n[_this12.clusterSubItemField]) === null || _n$_this12$clusterSub === void 0 ? void 0 : _n$_this12$clusterSub.nodes) || [];
        subnodes.forEach(function (v) {
          v.x += n.x;
          v.y += n.y;
          v.fx = v.x;
          v.fy = v.y;
        });
      });
      var groupLinkAttr = this.options.getClusterLinkAttributes ? function (link, typeValue) {
        return _this12.options.getClusterLinkAttributes(link, typeValue);
      } : undefined;
      var newGraphData = unclusterGraphData({
        data: graphData,
        nodeIds: nodeIds,
        subItemFieldName: this.clusterSubItemField,
        linkTypeFilter: this.linkTypeFilter
      }, groupLinkAttr);
      this.graph.updateData(newGraphData).restart(0);
    }

    /**
     * get subitem field name, by default is '@clusterSubItems'
     * @returns {string}
     */
  }, {
    key: "getClusterSubItemField",
    value: function getClusterSubItemField() {
      return this.clusterSubItemField;
    }

    /**
     * change global options 'linkTypeFilter'
     * re-generate graph links
     * @param {IClusterGraphDataFilter<IGraphLink>} linkTypeFilter
     */
  }, {
    key: "setLinkTypeFilter",
    value: function setLinkTypeFilter(linkTypeFilter) {
      var _this13 = this;
      this.linkTypeFilter = linkTypeFilter;
      var groupLinkAttr = this.options.getClusterLinkAttributes ? function (link, typeValue) {
        return _this13.options.getClusterLinkAttributes(link, typeValue);
      } : undefined;
      var graphData = getData.call(this.graph);
      var newData = _objectSpread(_objectSpread({}, graphData), {}, {
        links: getGroupedLinkData({
          data: graphData,
          autoExtractLinks: true,
          subItemFieldName: this.clusterSubItemField,
          linkTypeFilter: linkTypeFilter,
          groupLinkAttr: groupLinkAttr
        })
      });
      this.graph.updateData(newData).restart();
    }

    /**
     * subnodes with undeletable will not be deleted, when it's parent node execute delete
     * @param {string[]} nodeIds
     */
  }, {
    key: "setUndeletableNodeIds",
    value: function setUndeletableNodeIds(nodeIds) {
      this.unDeletableNodeIds = nodeIds;
    }
  }, {
    key: "setEnableDragInOut",
    value: function setEnableDragInOut(isEnable) {
      this.enableDragInOut = isEnable;
    }
    /**
     * move individual nodes into one specific cluster node
     * @param {string[]} nodeIds
     * @param {string} clusterId
     */
  }, {
    key: "moveIntoCluster",
    value: function moveIntoCluster$1(nodeIds, clusterId) {
      var data = this.graph.getData();
      if (nodeIds.includes(clusterId)) {
        return;
      }
      var generateData = moveIntoCluster({
        nodeIds: _toConsumableArray(nodeIds),
        clusterId: clusterId,
        data: data,
        clusterSubItemField: this.clusterSubItemField,
        linkTypeFilter: this.linkTypeFilter,
        groupLinkAttr: this.options.getClusterLinkAttributes
      });
      if (!generateData.clusterNode) {
        return;
      }
      this.calculateSubnodesPositionByClusterSubItemField(generateData.clusterNode);
      if (generateData.clusterNode[CHILDREN_FIELD]) {
        generateData.clusterNode[CHILDREN_FIELD] = generateData.clusterNode[this.clusterSubItemField].nodes;
      }
      Object.assign(generateData.clusterNode, this.getClusterNodeAttr(generateData.clusterNode, !!generateData.clusterNode[CHILDREN_FIELD]));
      this.clusterSubLinksMap[clusterId] = generateData.clusterNode[this.clusterSubItemField].links;
      this.storeNodeData(generateData.data);
      this.graph.updateData(generateData.data).restart();
      if (this.options.onMoveIntoCluster) {
        this.options.onMoveIntoCluster(nodeIds, generateData.clusterNode);
      }
    }

    /**
     * move subnodes outof one cluster node
     * @param {string[]} nodeIds
     * @param {string} clusterId
     */
  }, {
    key: "moveOutofCluster",
    value: function moveOutofCluster$1(nodeIds, clusterId) {
      var data = this.graph.getData();
      if (nodeIds.includes(clusterId)) {
        return;
      }
      var generateData = moveOutofCluster({
        nodeIds: _toConsumableArray(nodeIds),
        clusterId: clusterId,
        data: data,
        allowSingleNode: this.options.allowSingleNode,
        clusterSubItemField: this.clusterSubItemField,
        linkTypeFilter: this.linkTypeFilter,
        groupLinkAttr: this.options.getClusterLinkAttributes
      });
      if (!generateData.clusterNode) {
        return;
      }
      Object.assign(generateData.clusterNode, this.getClusterNodeAttr(generateData.clusterNode, !!generateData.clusterNode[CHILDREN_FIELD]));
      this.clusterSubLinksMap[generateData.clusterNode.id] = generateData.clusterNode[this.clusterSubItemField].links;
      this.calculateSubnodesPositionByClusterSubItemField(generateData.clusterNode);
      if (generateData.clusterNode[CHILDREN_FIELD]) {
        generateData.clusterNode[CHILDREN_FIELD] = generateData.clusterNode[this.clusterSubItemField].nodes;
      }
      this.storeNodeData(generateData.data);
      this.graph.updateData(generateData.data).restart();
      if (this.options.onMoveOutofCluster) {
        this.options.onMoveOutofCluster(nodeIds, generateData.clusterNode);
      }
    }

    /**
     * get clusternode by subnodeId
     * @param subnodeId
     * @returns {IGraphNode | undefined}
     */
  }, {
    key: "getClusterBySubNode",
    value: function getClusterBySubNode(subnodeId) {
      var d = this.storeNodeMap[subnodeId];
      if (d && d.parentId) {
        return this.storeNodeMap[d.parentId].data;
      }
      return undefined;
    }

    /**
     * be called when graph data change
     * check if children length is not equal CLUSTER_SUBITEM_FIELD, which will be occured after remove subnodes
     * if one cluster group not contain any children anymore, should be removed
     * [todo - performance check]
     */
  }, {
    key: "checkAndUpdate",
    value: function checkAndUpdate() {
      var _this14 = this;
      var data = getData.call(this.graph);
      var hasChange = [];
      var removeNodeIds = [];
      var unclusterNodeIds = [];
      var newData = {
        links: [],
        nodes: data.nodes
      };
      newData.nodes.filter(function (n) {
        return n[_this14.clusterSubItemField];
      }).forEach(function (n) {
        var _this14$storeNodeMap$;
        var subItems = n[_this14.clusterSubItemField];
        var storedSubItems = (_this14$storeNodeMap$ = _this14.storeNodeMap[n.id]) === null || _this14$storeNodeMap$ === void 0 ? void 0 : _this14$storeNodeMap$.data[_this14.clusterSubItemField];
        if (n[CHILDREN_FIELD] && subItems.nodes.length !== n[CHILDREN_FIELD].length) {
          if (n[CHILDREN_FIELD].length === 0) {
            removeNodeIds.push(n.id);
          } else {
            subItems.nodes = n[CHILDREN_FIELD] || [];
            var subNodeIds = subItems.nodes.map(function (c) {
              return c.id;
            });
            subItems.links = subItems.links.filter(function (l) {
              var _getLinkNodesId2 = getLinkNodesId(l),
                sourceId = _getLinkNodesId2.sourceId,
                targetId = _getLinkNodesId2.targetId;
              return subNodeIds.includes(sourceId) && subNodeIds.includes(targetId);
            });
            _this14.clusterSubLinksMap[n.id] = subItems.links;
            _this14.calculateSubnodesPositionByClusterSubItemField(n);
            hasChange.push(n);
            if (!_this14.options.allowSingleNode && n[CHILDREN_FIELD].length === 1) {
              /** if has one node remain, do uncluster */
              unclusterNodeIds.push(n.id);
            } else {
              Object.assign(n, _this14.getClusterNodeAttr(n, !!n[CHILDREN_FIELD]));
            }
          }
        } else if (storedSubItems && (storedSubItems.nodes.length !== subItems.nodes.length || storedSubItems.links.length !== subItems.links.length)) {
          _this14.clusterSubLinksMap[n.id] = subItems.links;
          _this14.storeNodeMap[n.id].data = n;
          _this14.calculateSubnodesPositionByClusterSubItemField(n);
          hasChange.push(n);
          if (!_this14.options.allowSingleNode && subItems.nodes.length === 1) {
            /** if has one node remain, do uncluster */
            unclusterNodeIds.push(n.id);
          } else {
            Object.assign(n, _this14.getClusterNodeAttr(n, !!n[CHILDREN_FIELD]));
          }
        }
        if (!_this14.clusterSubLinksMap[n.id]) {
          _this14.clusterSubLinksMap[n.id] = subItems.links;
          if (!hasChange.find(function (v) {
            return v.id === n.id;
          })) {
            hasChange.push(n);
          }
        }
      });
      if (removeNodeIds.length > 0) {
        this.graph.removeNodes(removeNodeIds);
      } else if (hasChange.length > 0) {
        var relatedItems = getRelatedNodesAndLinks(hasChange.map(function (v) {
          return v.id;
        }), data);
        var _nodeIds = [].concat(_toConsumableArray(relatedItems.nodes.map(function (v) {
          var res = [v.id];
          if (v[_this14.clusterSubItemField]) {
            res.push.apply(res, _toConsumableArray(v[_this14.clusterSubItemField].nodes.map(function (n) {
              return n.id;
            })));
          }
          return res;
        }).flat()), _toConsumableArray(hasChange.map(function (n) {
          return n[_this14.clusterSubItemField].nodes;
        }).flat().map(function (n) {
          return n.id;
        })));
        var removeLinkIds = [];
        relatedItems.links.forEach(function (v) {
          if (v[_this14.clusterSubItemField]) {
            var checkLink = function checkLink(link) {
              var restlinks = link[_this14.clusterSubItemField].filter(function (l) {
                if (l[_this14.clusterSubItemField]) {
                  return checkLink(l);
                }
                var _getLinkNodesId3 = getLinkNodesId(l),
                  sourceId = _getLinkNodesId3.sourceId,
                  targetId = _getLinkNodesId3.targetId;
                return _nodeIds.includes(sourceId) && _nodeIds.includes(targetId);
              });
              if (restlinks.length === 0) {
                removeLinkIds.push(link.id);
              } else if (link[_this14.clusterSubItemField].length !== restlinks.length && _this14.options.getClusterLinkAttributes) {
                Object.assign(v, _this14.options.getClusterLinkAttributes(v, getLinkTypeValue(v, _this14.linkTypeFilter)));
              }
              link[_this14.clusterSubItemField] = restlinks;
              return restlinks.length > 0;
            };
            checkLink(v);
          }
        });
        if (removeLinkIds.length > 0) {
          newData.links = data.links.filter(function (v) {
            if (removeLinkIds.includes(v.id)) {
              return false;
            }
            if (v[_this14.clusterSubItemField]) {
              v[_this14.clusterSubItemField] = v[_this14.clusterSubItemField].filter(function (l) {
                return !removeLinkIds.includes(l.id);
              });
            }
            return true;
          });
        } else {
          newData.links = data.links;
        }
        this.graph.updateData(newData).restart();
        this.storeNodeData(getData.call(this.graph));
        if (unclusterNodeIds.length > 0) {
          this.unclusterNodes(unclusterNodeIds);
        } else {
          this.updateSubLinksPath();
        }
      } else {
        this.storeNodeData(getData.call(this.graph));
      }
    }

    /**
     * store node data by id, so that can be get efficiently later in draw and tick
     * @param {IGraphData} graphData
     */
  }, {
    key: "storeNodeData",
    value: function storeNodeData(graphData) {
      var _this15 = this;
      this.storeNodeMap = {};
      var store = function store(node, parentId) {
        var _node$_this15$cluster;
        _this15.storeNodeMap[node.id] = {
          data: node,
          parentId: parentId
        };
        var subNodes = node[CHILDREN_FIELD] || ((_node$_this15$cluster = node[_this15.clusterSubItemField]) === null || _node$_this15$cluster === void 0 ? void 0 : _node$_this15$cluster.nodes);
        if (subNodes && subNodes.length > 0) {
          subNodes.forEach(function (c) {
            return store(c, node.id);
          });
        }
      };
      graphData.nodes.forEach(function (n) {
        return store(n);
      });
    }

    /**
     * be executed on event BEFORE_REMOVE_NODES
     * if ids include cluster node, uncluster it first
     * then push subnodeids into nodeids
     * @param {string[]} nodeIds
     */
  }, {
    key: "beforeRemoveNodes",
    value: function beforeRemoveNodes(nodeIds) {
      var _this16 = this;
      var subIds = [];
      var unclusterIds = [];
      nodeIds.forEach(function (nid) {
        var _this16$storeNodeMap$, _nodeData$_this16$clu;
        var nodeData = (_this16$storeNodeMap$ = _this16.storeNodeMap[nid]) === null || _this16$storeNodeMap$ === void 0 ? void 0 : _this16$storeNodeMap$.data;
        if (!nodeData) {
          return;
        }
        var subnodes = ((_nodeData$_this16$clu = nodeData[_this16.clusterSubItemField]) === null || _nodeData$_this16$clu === void 0 ? void 0 : _nodeData$_this16$clu.nodes) || nodeData[CHILDREN_FIELD];
        if (subnodes && subnodes.length > 0) {
          subnodes.forEach(function (n) {
            if (!_this16.unDeletableNodeIds.includes(n.id)) {
              subIds.push(n.id);
            }
          });
          unclusterIds.push(nid);
        }
      });
      subIds.forEach(function (sid) {
        return nodeIds.push(sid);
      });
      if (unclusterIds.length > 0) {
        this.unclusterNodes(unclusterIds);
      }
    }

    /**
     * when user enable drag in out behavior
     * fix cluster position through 'fx' 'fy'
     * to avoid collide between nodes
     */
  }, {
    key: "fixClusterPosition",
    value: function fixClusterPosition() {
      var _this17 = this;
      if (!this.enableDragInOut || this.isClusterPositionFixed) {
        return;
      }
      /** if enable drag in out, fix cluster nodes to avoid collide between nodes */
      var clusterNodes = this.graph.getContainer().nodeGroup.filter(function (v) {
        return v[_this17.clusterSubItemField];
      });
      clusterNodes.data().forEach(function (v) {
        v.fx = v.x;
        v.fy = v.y;
      });
      this.isClusterPositionFixed = true;
    }

    /**
     * if graph.selectedNodes includes cluster nodes
     * show special style of these nodes
     */
  }, {
    key: "updateClusterSelectedStyle",
    value: function updateClusterSelectedStyle() {
      var _this$storeNodeAttr,
        _this18 = this;
      var ids = this.graph.selectedNodes || [];
      this.storeNodeAttr = (_this$storeNodeAttr = this.storeNodeAttr) !== null && _this$storeNodeAttr !== void 0 ? _this$storeNodeAttr : {};
      var clusterNodeGroup = this.graph.getContainer().nodeGroup.filter(function (v) {
        return !!v[_this18.clusterSubItemField];
      });
      clusterNodeGroup.selectAll('.graph__node').style('stroke', function (d) {
        if (d[_this18.clusterSubItemField]) {
          var _this18$storeNodeAttr;
          if (ids.includes(d.id)) {
            _this18.storeNodeAttr[d.id] = {
              stroke: d.stroke,
              strokeWidth: d.strokeWidth
            };
            return '#000';
          }
          return ((_this18$storeNodeAttr = _this18.storeNodeAttr[d.id]) === null || _this18$storeNodeAttr === void 0 ? void 0 : _this18$storeNodeAttr.stroke) || d.stroke;
        }
        return d.stroke;
      }).style('stroke-width', function (d) {
        if (d[_this18.clusterSubItemField]) {
          var _this18$storeNodeAttr2;
          if (ids.includes(d.id)) {
            return 7;
          }
          return ((_this18$storeNodeAttr2 = _this18.storeNodeAttr[d.id]) === null || _this18$storeNodeAttr2 === void 0 ? void 0 : _this18$storeNodeAttr2.strokeWidth) || d.strokeWidth;
        }
        return d.strokeWidth;
      });
      if (ids.length === 0) {
        this.storeNodeAttr = {};
      }
    }

    /**
     * be executed on event BEHAVIOR_LOCATEHIGHLIGHT_ONLOCATE
     * enhance the power of locate highlight
     * locate from cluster nodes and links, toggle show related cluster, push target data
     * @param {{ values: string[]; field: string; scope?: string }} options
     * @param {{ nodes: IGraphNode[]; links: IGraphLink[] }} res
     */
  }, {
    key: "locateFromCluster",
    value: function locateFromCluster(options, res) {
      var _this19 = this,
        _res$nodes,
        _res$links;
      var _this$graph$getContai3 = this.graph.getContainer(),
        nodeGroup = _this$graph$getContai3.nodeGroup,
        linkGroup = _this$graph$getContai3.linkGroup;
      var clusterNodeGroup = nodeGroup.filter(function (v) {
        return !!v[_this19.clusterSubItemField];
      });
      var clusterLinkGroup = linkGroup.filter(function (v) {
        return !!v[_this19.clusterSubItemField];
      });
      var expandNodeId = new Set();
      var resNodes = [];
      var resLinks = [];
      clusterNodeGroup.data().forEach(function (d) {
        var subNodes = d[_this19.clusterSubItemField].nodes || [];
        var subLinks = d[_this19.clusterSubItemField].links || [];
        if (options.scope !== 'node') {
          var findLinks = getDataByAttributes(subLinks, options.values, options.field).items;
          if (findLinks.length > 0) {
            expandNodeId.add(d.id);
            resLinks.push.apply(resLinks, _toConsumableArray(findLinks));
          }
        }
        if (options.scope !== 'link') {
          var findNodes = getDataByAttributes(subNodes, options.values, options.field).items;
          if (findNodes.length > 0) {
            expandNodeId.add(d.id);
            resNodes.push.apply(resNodes, _toConsumableArray(findNodes));
          }
        }
      });
      if (options.scope !== 'node') {
        clusterLinkGroup.data().forEach(function (d) {
          var _getLinkNodesId4 = getLinkNodesId(d),
            sourceId = _getLinkNodesId4.sourceId,
            targetId = _getLinkNodesId4.targetId;
          var subLinks = extractLinks([d], _this19.clusterSubItemField);
          var findLinks = getDataByAttributes(subLinks, options.values, options.field).items;
          if (findLinks.length > 0) {
            expandNodeId.add(sourceId);
            expandNodeId.add(targetId);
            resLinks.push.apply(resLinks, _toConsumableArray(findLinks));
          }
        });
      }
      if (expandNodeId.size > 0) {
        this.toggleCluster(Array.from(expandNodeId), true);
      }
      (_res$nodes = res.nodes).push.apply(_res$nodes, resNodes);
      (_res$links = res.links).push.apply(_res$links, resLinks);
    }
  }, {
    key: "brushSelectFromCluster",
    value: function brushSelectFromCluster(selectedNodes, selection) {
      var _this20 = this;
      if (!this.options.enhanceBrushSelectBehavior) {
        return;
      }
      this.subNodeGroup.data().forEach(function (v) {
        var _this20$storeNodeMap$, _this20$storeNodeMap$2;
        var parentId = (_this20$storeNodeMap$ = _this20.storeNodeMap[v.id]) === null || _this20$storeNodeMap$ === void 0 ? void 0 : _this20$storeNodeMap$.parentId;
        var parentNode = parentId && ((_this20$storeNodeMap$2 = _this20.storeNodeMap[parentId]) === null || _this20$storeNodeMap$2 === void 0 ? void 0 : _this20$storeNodeMap$2.data);
        if (parentNode) {
          var x = v.x + parentNode.x,
            y = v.y + parentNode.y;
          var isSelected = x > selection[0][0] && x < selection[1][0] && y > selection[0][1] && y < selection[1][1];
          if (isSelected) {
            selectedNodes.push(_objectSpread(_objectSpread({}, v), {}, _defineProperty({}, '@brushSelectParentNode', parentNode)));
          }
        }
      });
    }
  }, {
    key: "generateByExtraData",
    value: function generateByExtraData(extraData) {
      var _this21 = this,
        _newData$links;
      var relatedClusterId = new Set();
      var relatedNodeIds = new Set();
      extraData.links.forEach(function (v) {
        var _this21$storeNodeMap$, _this21$storeNodeMap$2;
        var _getLinkNodesId5 = getLinkNodesId(v),
          sourceId = _getLinkNodesId5.sourceId,
          targetId = _getLinkNodesId5.targetId;
        if ((_this21$storeNodeMap$ = _this21.storeNodeMap[sourceId]) !== null && _this21$storeNodeMap$ !== void 0 && _this21$storeNodeMap$.parentId) {
          relatedClusterId.add(_this21.storeNodeMap[sourceId].parentId);
        } else {
          relatedNodeIds.add(sourceId);
        }
        if ((_this21$storeNodeMap$2 = _this21.storeNodeMap[targetId]) !== null && _this21$storeNodeMap$2 !== void 0 && _this21$storeNodeMap$2.parentId) {
          relatedClusterId.add(_this21.storeNodeMap[targetId].parentId);
        } else {
          relatedNodeIds.add(targetId);
        }
      });
      var graphData = this.graph.getData();
      if (relatedClusterId.size === 0) {
        return {
          nodes: [].concat(_toConsumableArray(graphData.nodes), _toConsumableArray(extraData.nodes)),
          links: [].concat(_toConsumableArray(graphData.links), _toConsumableArray(extraData.links))
        };
      }
      var newData = {
        nodes: [].concat(_toConsumableArray(graphData.nodes), _toConsumableArray(extraData.nodes)),
        links: []
      };
      var relatedNodesLinks = getRelatedNodesAndLinks([].concat(_toConsumableArray(Array.from(relatedClusterId)), _toConsumableArray(Array.from(relatedNodeIds))), graphData);
      var relatedLinkIds = relatedNodesLinks.links.map(function (v) {
        return v.id;
      });
      graphData.links.forEach(function (v) {
        if (!relatedLinkIds.includes(v.id)) {
          newData.links.push(v);
        }
      });
      var newLinks = getGroupedLinkData({
        data: {
          nodes: [].concat(_toConsumableArray(relatedNodesLinks.nodes), _toConsumableArray(extraData.nodes)),
          links: [].concat(_toConsumableArray(relatedNodesLinks.links), _toConsumableArray(extraData.links))
        },
        subItemFieldName: this.clusterSubItemField,
        linkTypeFilter: this.linkTypeFilter,
        autoExtractLinks: true,
        groupLinkAttr: this.options.getClusterLinkAttributes ? function (link, typeValue) {
          return _this21.options.getClusterLinkAttributes(link, typeValue);
        } : undefined
      });
      (_newData$links = newData.links).push.apply(_newData$links, _toConsumableArray(newLinks));
      return newData;
    }
  }, {
    key: "generateByRestoredData",
    value: function generateByRestoredData(data, openIds) {
      var _this22 = this;
      var groupNodeAttr = function groupNodeAttr(node) {
        return _this22.getClusterNodeAttr(node, openIds ? openIds.includes(node.id) : false);
      };
      var groupLinkAttr = this.options.getClusterLinkAttributes ? function (link, typeValue) {
        return _this22.options.getClusterLinkAttributes(link, typeValue);
      } : undefined;
      var newData = restoreClusterData({
        data: data,
        childField: CHILDREN_FIELD,
        linkTypeFilter: this.linkTypeFilter,
        subItemFieldName: this.clusterSubItemField,
        allowSingleNode: this.options.allowSingleNode,
        groupNodeAttr: groupNodeAttr,
        groupLinkAttr: groupLinkAttr,
        openIds: openIds
      });
      return {
        nodes: newData.nodes,
        links: newData.links
      };
    }
  }, {
    key: "removeNodesAndSingleUnions",
    value: function removeNodesAndSingleUnions(removeNodeIds, unionLinkFilter) {
      var _this23 = this;
      var graphData = this.graph.getData();
      /** remove nodes */
      if (removeNodeIds && removeNodeIds.length > 0) {
        this.beforeRemoveNodes(removeNodeIds);
        graphData = getGraphDataWhenNodesRemove(removeNodeIds, this.graph.getData());
      }
      /** flat cluster */
      var flatNodes = [];
      var flatLinks = [];
      var flatLinkIds = new Set();
      graphData.nodes.forEach(function (n) {
        if (n[_this23.clusterSubItemField]) {
          n[_this23.clusterSubItemField].nodes.forEach(function (d) {
            flatNodes.push(d);
          });
          n[_this23.clusterSubItemField].links.forEach(function (d) {
            if (!flatLinkIds.has(d.id)) {
              flatLinks.push(d);
              flatLinkIds.add(d.id);
            }
          });
        } else {
          flatNodes.push(n);
        }
      });
      graphData.links.forEach(function (n) {
        if (n[_this23.clusterSubItemField]) {
          extractLinks([n], _this23.clusterSubItemField).forEach(function (d) {
            if (!flatLinkIds.has(d.id)) {
              flatLinks.push(d);
              flatLinkIds.add(d.id);
            }
          });
        } else {
          flatLinks.push(n);
          flatLinkIds.add(n.id);
        }
      });
      /** check unions and delete nodeIds */
      var deleteNodeIds = [];
      var deleteOuterNodes = [];
      var deleteSubNodes = {};
      if (unionLinkFilter) {
        flatLinks = flatLinks.filter(unionLinkFilter);
      }
      var flatGraphUnions = getGraphNodeUnions({
        nodes: flatNodes,
        links: flatLinks
      });
      flatGraphUnions.forEach(function (list) {
        var undeletable = list.some(function (v) {
          return _this23.unDeletableNodeIds.includes(v);
        });
        if (!undeletable) {
          list.forEach(function (v) {
            var _this23$storeNodeMap$;
            var pId = (_this23$storeNodeMap$ = _this23.storeNodeMap[v]) === null || _this23$storeNodeMap$ === void 0 ? void 0 : _this23$storeNodeMap$.parentId;
            if (pId) {
              deleteSubNodes[pId] = deleteSubNodes[pId] || [];
              deleteSubNodes[pId].push(v);
            } else {
              deleteOuterNodes.push(v);
            }
            deleteNodeIds.push(v);
          });
        }
      });
      /** delete nodes */
      if (deleteOuterNodes.length > 0) {
        graphData = getGraphDataWhenNodesRemove(deleteOuterNodes, graphData);
      }
      if (Object.keys(deleteSubNodes).length > 0) {
        var nodes = [];
        var links = [];
        var unclusterId = [];
        graphData.nodes.forEach(function (n) {
          if (deleteSubNodes[n.id] && n[_this23.clusterSubItemField]) {
            var subitems = n[_this23.clusterSubItemField] || {
              nodes: [],
              links: []
            };
            var subnodes = subitems.nodes.filter(function (v) {
              return !deleteSubNodes[n.id].includes(v.id);
            });
            var sublinks = subitems.links.filter(function (v) {
              var _getLinkNodesId6 = getLinkNodesId(v),
                sourceId = _getLinkNodesId6.sourceId,
                targetId = _getLinkNodesId6.targetId;
              return !deleteNodeIds.includes(sourceId) && !deleteNodeIds.includes(targetId);
            });
            n[_this23.clusterSubItemField].nodes = subnodes;
            n[_this23.clusterSubItemField].links = sublinks;
            if (n[CHILDREN_FIELD]) {
              n[CHILDREN_FIELD] = subnodes;
            }
            if (subnodes.length === 0 || !_this23.options.allowSingleNode && subnodes.length <= 1) {
              subnodes.forEach(function (v) {
                v.x += n.x;
                v.y += n.y;
                v.fx = v.x;
                v.fy = v.y;
              });
              unclusterId.push(n.id);
              nodes.push(n);
            } else {
              _this23.clusterSubLinksMap[n.id] = sublinks;
              _this23.calculateSubnodesPositionByClusterSubItemField(n);
            }
          }
          nodes.push(n);
        });
        graphData.links.forEach(function (d) {
          var _getLinkNodesId7 = getLinkNodesId(d),
            sourceId = _getLinkNodesId7.sourceId,
            targetId = _getLinkNodesId7.targetId;
          if (deleteSubNodes[sourceId] || deleteSubNodes[targetId]) {
            var checkSubLinks = function checkSubLinks(l) {
              var subLinks = l[_this23.clusterSubItemField] || [];
              var restLinks = subLinks.filter(function (s) {
                if (s[_this23.clusterSubItemField]) {
                  return checkSubLinks(s);
                }
                var st = getLinkNodesId(s);
                return !deleteNodeIds.includes(st.sourceId) && !deleteNodeIds.includes(st.targetId);
              });
              l[_this23.clusterSubItemField] = restLinks;
              if (restLinks.length > 0 && subLinks.length !== restLinks.length && _this23.options.getClusterLinkAttributes) {
                Object.assign(l, _this23.options.getClusterLinkAttributes(l, getLinkTypeValue(l, _this23.linkTypeFilter)));
              }
              return restLinks.length > 0;
            };
            if (checkSubLinks(d)) {
              links.push(d);
            }
          } else {
            links.push(d);
          }
        });
        graphData = {
          nodes: nodes,
          links: links
        };
        if (unclusterId.length > 0) {
          graphData = unclusterGraphData({
            data: graphData,
            nodeIds: unclusterId,
            subItemFieldName: this.clusterSubItemField,
            linkTypeFilter: this.linkTypeFilter
          }, this.options.getClusterLinkAttributes ? function (link, typeValue) {
            return _this23.options.getClusterLinkAttributes(link, typeValue);
          } : undefined);
        }
      }
      this.graph.updateData(graphData).restart(0);
      return this.graph.getData();
    }
  }, {
    key: "init",
    value: function init() {
      var _this24 = this;
      this.graph.event.on(CONSTANTS.EVENT.CHANGE_GRAPH_DATA, function () {
        _this24.checkAndUpdate();
        _this24.isClusterPositionFixed = false;
      });
      this.graph.event.on(CONSTANTS.EVENT.BEFORE_REMOVE_NODES, this.beforeRemoveNodes.bind(this));
      this.graph.event.on(CONSTANTS.EVENT.LAYOUT_AFTER_DRAW, function () {
        if (!_this24.storeNodeMap) {
          _this24.storeNodeData(getData.call(_this24.graph));
        }
        _this24.drawSubNodes();
      });
      this.graph.event.on(CONSTANTS.EVENT.LAYOUT_TICK_START, function () {
        /* performance enhancement, prevent path and label calculation from every tick */
        _this24.clusterOuterLinkDraw.linksOverlay.classed('graph-invisible', true);
        _this24.clusterOuterLinkDraw.linkGroup.selectAll('.graph__link--label').classed('graph-invisible', true);
        _this24.clusterSubLinkDraw.linksOverlay.classed('graph-invisible', true);
        _this24.clusterSubLinkDraw.linkGroup.selectAll('.graph__link--label').classed('graph-invisible', true);
        /* end performance enhancement */
      });

      this.graph.event.on(CONSTANTS.EVENT.LAYOUT_TICK_END, function () {
        _this24.fixClusterPosition();
        /* performance enhancement, prevent path and label calculation from every tick */
        // clusterOuterLink
        _this24.clusterOuterLinkDraw.linksOverlay.classed('graph-invisible', false);
        _this24.clusterOuterLinkDraw.linkGroup.selectAll('.graph__link--label').classed('graph-invisible', false);
        _this24.clusterOuterLinkDraw.linksOverlay.attr('d', function (d) {
          return _this24.getLinkPath(d);
        });
        _this24.clusterOuterLinkDraw.linkGroup.selectAll('.graph__link--label path').attr('d', function (d) {
          return _this24.getLinkPath(d, true);
        });
        updateLinkLabelPosition(_this24.clusterOuterLinkDraw.linkGroup);

        // clusterSubLink
        _this24.clusterSubLinkDraw.linksOverlay.classed('graph-invisible', false);
        _this24.clusterSubLinkDraw.linkGroup.selectAll('.graph__link--label').classed('graph-invisible', false);
        _this24.clusterSubLinkDraw.linksOverlay.attr('d', function (d) {
          return _this24.getSubLinkPath(d, false);
        });
        _this24.clusterSubLinkDraw.linkGroup.selectAll('.graph__link--label path').attr('d', function (d) {
          return _this24.getSubLinkPath(d, true);
        });
        updateLinkLabelPosition(_this24.clusterSubLinkDraw.linkGroup);
        /* end performance enhancement */
      });

      this.graph.event.on(CONSTANTS.EVENT.LAYOUT_TICK, function () {
        _this24.updateLinkPosition();
      });
      this.graph.event.on(CONSTANTS.EVENT.DRAG_START, function (node, evt) {
        if (!_this24.enableDragInOut) {
          return;
        }
        _this24.onNodeDragStart(node, evt);
      });
      this.graph.event.on(CONSTANTS.EVENT.DRAG, function (node, evt) {
        if (!_this24.enableDragInOut) {
          return;
        }
        _this24.onNodeDragging(node, evt);
      });
      this.graph.event.on(CONSTANTS.EVENT.DRAG_END, function (node) {
        if (!_this24.enableDragInOut) {
          return;
        }
        _this24.onNodeDragEnd(node);
      });
      this.graph.event.on(CONSTANTS.EVENT.CHANGE_SELECTED_NODES, function () {
        return _this24.updateClusterSelectedStyle();
      });
      this.graph.event.on(CONSTANTS.EVENT.CHANGE_SELECTED_LINKS, function () {
        var graphSelectedLinks = _this24.graph.selectedLinks || [];
        _this24.clusterOuterLinkDraw.linkGroup.classed(CONSTANTS.CLASSNAME.LINKGROUP_SELECTED, function (v) {
          if (graphSelectedLinks.includes(v.id)) {
            return true;
          }
          var sub = v[_this24.clusterSubItemField] || [];
          return sub.some(function (s) {
            return graphSelectedLinks.includes(s.id);
          });
        });
        _this24.clusterSubLinkDraw.linkGroup.classed(CONSTANTS.CLASSNAME.LINKGROUP_SELECTED, function (v) {
          return graphSelectedLinks.includes(v.id);
        });
      });
      this.graph.event.on(CONSTANTS.EVENT.BEHAVIOR_LOCATEHIGHLIGHT_ONLOCATE, this.locateFromCluster.bind(this));
      this.graph.event.on(CONSTANTS.EVENT.BEHAVIOR_BRUSHSELECT_ONBRUSHEND, this.brushSelectFromCluster.bind(this));
      this.graph.event.on(CONSTANTS.EVENT.SET_LINKS_ATTRIBUTES, function (_ref) {
        var linkMap = _ref.linkMap,
          childFields = _ref.childFields;
        if (!linkMap || !_this24.clusterSubLinksMap) return;
        var sublinksInsideCluster = Object.keys(_this24.clusterSubLinksMap).map(function (nodeId) {
          return _this24.clusterSubLinksMap[nodeId];
        }).flat();
        var _setLinksAttributes = setLinksAttributes(sublinksInsideCluster, linkMap, childFields),
          matchedIds = _setLinksAttributes.matchedIds;
        if (matchedIds.length === 0) return;
        getData.call(_this24.graph).nodes.forEach(function (n) {
          if (_this24.clusterSubLinksMap[n.id]) {
            n[_this24.clusterSubItemField] = _objectSpread(_objectSpread({}, n[_this24.clusterSubItemField]), {}, {
              links: _this24.clusterSubLinksMap[n.id]
            });
          }
        });
        _this24.graph.updateData(getData.call(_this24.graph));
      });
    }
  }]);
  return SubNodes;
}(BaseBehavior);

export { SubNodes as default };
