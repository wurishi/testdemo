import _toConsumableArray from '@babel/runtime/helpers/toConsumableArray';
import _defineProperty from '@babel/runtime/helpers/defineProperty';
import { getObjectValueByKeyChain, getRelatedNodesAndLinks } from '../../utils.js';
import { v4 } from 'uuid';
import CONSTANTS from '../../constants.js';

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
var CLUSTER_SUBITEM_FIELD = '@clusterSubItems';

/**
 * getLinkNodesId
 * @param {IGraphLink} link
 * @returns { {sourceId: string, targetId: string} }
 */
function getLinkNodesId(link) {
  var sourceId = typeof link.source === 'string' ? link.source : link.source.id;
  var targetId = typeof link.target === 'string' ? link.target : link.target.id;
  return {
    sourceId: sourceId,
    targetId: targetId
  };
}

/**
 * getLinkTypeValue
 * @param {IGraphLink} link
 * @param {IClusterGraphDataFilter<IGraphLink>} filter optional
 * @returns {string}
 */
function getLinkTypeValue(link, filter) {
  var linkTypeValue = '';
  if (typeof filter === 'string') {
    linkTypeValue = getObjectValueByKeyChain(link, filter);
  } else if (typeof filter === 'function') {
    linkTypeValue = filter(link);
  }
  return linkTypeValue;
}

/**
 * generate new graph data according to input filter, grouped by filtervalue
 * @param {IClusterGraphDataOptions} options
 * @param {(groupNode:IGraphNode, groupValue:string) => Object} groupNodeAttr optional
 * @param {(groupLink:IGraphLink, groupValue:string) => Object} groupLinkAttr optional
 * @returns {nodes:IGraphNode[], links:IGraphLink[], newClusterNodes:IGraphNode[]}
 */
function clusterGraphData(options, groupNodeAttr, groupLinkAttr) {
  var data = options.data,
    filter = options.filter,
    linkTypeFilter = options.linkTypeFilter,
    subItemFieldName = options.subItemFieldName,
    allowSingleNode = options.allowSingleNode;
  var nodes = [];
  var groupNodeMap = {}; // { [groupnodeid]: groupValue }
  var groupMap = {}; // { [groupValue]: { id: uuidv4(), nodes: [], links: [] }}
  var subItemField = subItemFieldName || CLUSTER_SUBITEM_FIELD;
  var newClusterNodes = [];
  if (filter && typeof filter !== 'string' && typeof filter !== 'function') {
    return _objectSpread(_objectSpread({}, data), {}, {
      newClusterNodes: []
    });
  }
  /** calculate each node's groupvalue
   * fill `groupMap` { [groupValue]: { id: uuidv4(), nodes: [], links: [] }}
   *  - move nodes with same groupvalue together
   * fill `groupNodeMap` { [groupnodeid]: groupValue }
   * push nodes without groupvalue into `nodes`
   */
  data.nodes.forEach(function (d) {
    var groupValue;
    if (typeof filter === 'string') {
      groupValue = getObjectValueByKeyChain(d, filter);
    } else {
      groupValue = filter(d);
    }
    if (typeof groupValue === 'string' && groupValue !== '' || typeof groupValue === 'number') {
      var _groupMap$groupValue;
      groupValue = String(groupValue);
      groupMap[groupValue] = (_groupMap$groupValue = groupMap[groupValue]) !== null && _groupMap$groupValue !== void 0 ? _groupMap$groupValue : {
        id: v4(),
        nodes: [],
        links: []
      };
      groupMap[groupValue].nodes.push(d);
      groupNodeMap[d.id] = groupValue;
    } else {
      nodes.push(d);
    }
  });
  /** loop `groupMap` and genreate new nodes by groupvalue, push into `nodes` */
  for (var key in groupMap) {
    var _groupNode = groupMap[key];
    if (!allowSingleNode && _groupNode.nodes.length <= 1) {
      nodes.push.apply(nodes, _toConsumableArray(_groupNode.nodes));
      delete groupMap[key];
      continue;
    }
    var newNode = _defineProperty({
      id: _groupNode.id,
      '@clusterGroupValue': key
    }, subItemField, _groupNode);
    if (groupNodeAttr) {
      Object.assign(newNode, groupNodeAttr(newNode, key));
    }
    nodes.push(newNode);
    newClusterNodes.push(newNode);
  }
  if (newClusterNodes.length === 0) {
    /** no new nodes, return data directly */
    return {
      nodes: nodes,
      links: data.links,
      newClusterNodes: newClusterNodes
    };
  }
  /** generate links */
  var links = getGroupedLinkData({
    data: {
      nodes: nodes,
      links: data.links
    },
    autoExtractLinks: true,
    subItemFieldName: subItemFieldName,
    linkTypeFilter: linkTypeFilter,
    groupLinkAttr: groupLinkAttr
  });
  return {
    nodes: nodes,
    links: links,
    newClusterNodes: newClusterNodes
  };
}
function restoreClusterData(options) {
  var nodes = [];
  var subItemField = options.subItemFieldName || CLUSTER_SUBITEM_FIELD;
  var childField = options.childField || 'children';
  var clusterNodes = [];
  var openIds = options.openIds || [];
  var openClusters = [];
  options.data.nodes.forEach(function (d) {
    var subNodes = d[childField] || [];
    if (subNodes.length > 0) {
      var clusterNode = _objectSpread(_objectSpread({}, d), {}, _defineProperty({}, subItemField, {
        id: d.id,
        nodes: subNodes,
        links: []
      }));
      if (!openIds.includes(d.id)) {
        delete clusterNode[childField];
      } else {
        openClusters.push(clusterNode);
      }
      delete clusterNode.r;
      if (options.groupNodeAttr) {
        Object.assign(clusterNode, options.groupNodeAttr(clusterNode, ''));
      }
      nodes.push(clusterNode);
      clusterNodes.push(clusterNode);
    } else {
      nodes.push(d);
    }
  });
  if (clusterNodes.length === 0) {
    return _objectSpread(_objectSpread({}, options.data), {}, {
      clusterNodes: clusterNodes
    });
  }
  var links = getGroupedLinkData({
    data: {
      nodes: nodes,
      links: options.data.links
    },
    autoExtractLinks: true,
    subItemFieldName: subItemField,
    linkTypeFilter: options.linkTypeFilter,
    groupLinkAttr: options.groupLinkAttr
  });
  if (openClusters.length > 0) {
    var relatedNodesLinks = getRelatedNodesAndLinks(openClusters.map(function (v) {
      return v.id;
    }), {
      nodes: nodes,
      links: links
    });
    var pendingNodes = openClusters.map(function (v) {
      return v[childField];
    }).flat();
    relatedNodesLinks.links.forEach(function (v) {
      if (v[subItemField] && v.source[subItemField] && v.target[subItemField]) {
        var sShow = !!v.source[childField],
          tShow = !!v.target[childField];
        if (sShow !== tShow) {
          var newlinks = getNewClusteredLinks({
            pendingNodes: pendingNodes,
            clusterLinks: [v],
            subItemFieldName: subItemField,
            linkTypeFilter: options.linkTypeFilter,
            groupLinkAttr: options.groupLinkAttr
          });
          v[subItemField] = newlinks;
        }
      }
    });
  }
  return {
    nodes: nodes,
    links: links,
    clusterNodes: clusterNodes
  };
}
/**
 * generate new links by linkTypeFilter
 * @param {IGetNewClusteredLinksOptions} options
 * @returns {IGraphLink[]}
 */
function getNewClusteredLinks(options) {
  var pendingNodes = options.pendingNodes,
    clusterLinks = options.clusterLinks,
    subItemFieldName = options.subItemFieldName,
    linkTypeFilter = options.linkTypeFilter,
    groupLinkAttr = options.groupLinkAttr;
  var subItemField = subItemFieldName || CLUSTER_SUBITEM_FIELD;
  var nodeMap = {}; // {[nodeId]: node}
  var parentMap = {}; // {[nodeId]: parentId}
  var mapNodes = function mapNodes(nodes) {
    nodes.forEach(function (n) {
      var _n$subItemField;
      nodeMap[n.id] = n;
      var subnodes = ((_n$subItemField = n[subItemField]) === null || _n$subItemField === void 0 ? void 0 : _n$subItemField.nodes) || [];
      subnodes.forEach(function (s) {
        parentMap[s.id] = n.id;
      });
    });
  };
  mapNodes(pendingNodes);
  var links = [];
  var groupLinkMap = {}; // { [groupValue]: links }
  var groupLinkValueMap = {}; // {[groupLinkId]: groupValue}
  var newClusterLinks = [];
  clusterLinks.forEach(function (v) {
    var _getLinkNodesId = getLinkNodesId(v),
      sourceId = _getLinkNodesId.sourceId,
      targetId = _getLinkNodesId.targetId;
    var subLinks = v[subItemField] || [];
    var sourceNode = nodeMap[sourceId];
    var targetNode = nodeMap[targetId];
    var getNodeId = function getNodeId(n) {
      var subLinkNodeIds = getLinkNodesId(n);
      if (!n.arrow) {
        var sp = parentMap[subLinkNodeIds.sourceId];
        var tp = parentMap[subLinkNodeIds.targetId];
        var isReverseLink = sp === targetId || tp === sourceId;
        if (isReverseLink) {
          return {
            lsourceId: sp || subLinkNodeIds.sourceId,
            ltargetId: tp || subLinkNodeIds.targetId
          };
        }
      }
      return {
        lsourceId: sourceNode && sourceId || subLinkNodeIds.sourceId,
        ltargetId: targetNode && targetId || subLinkNodeIds.targetId
      };
    };
    if (sourceNode && targetNode) {
      links.push(v);
    } else {
      subLinks.forEach(function (l) {
        var hasArrow = !!l.arrow;
        var linkTypeValue = getLinkTypeValue(l, linkTypeFilter);
        // const subLinkNodeIds = getLinkNodesId(l)
        // const lsourceId = (sourceNode && sourceId) || subLinkNodeIds.sourceId
        // const ltargetId = (targetNode && targetId) || subLinkNodeIds.targetId
        var _getNodeId = getNodeId(l),
          lsourceId = _getNodeId.lsourceId,
          ltargetId = _getNodeId.ltargetId;
        var lkey = "".concat(lsourceId, "@").concat(ltargetId, "@").concat(hasArrow, "@").concat(linkTypeValue);
        groupLinkValueMap[l.id] = linkTypeValue;
        if (!groupLinkMap[lkey]) {
          var _groupLinkMap$lkey;
          groupLinkMap[lkey] = (_groupLinkMap$lkey = groupLinkMap[lkey]) !== null && _groupLinkMap$lkey !== void 0 ? _groupLinkMap$lkey : [];
          newClusterLinks.push(_defineProperty({
            id: v4(),
            source: lsourceId,
            target: ltargetId,
            arrow: hasArrow
          }, subItemField, groupLinkMap[lkey]));
        }
        groupLinkMap[lkey].push(l);
      });
    }
  });
  newClusterLinks.forEach(function (v) {
    links.push(v);
    if (groupLinkAttr) {
      Object.assign(v, groupLinkAttr(v, groupLinkValueMap[v.id]));
    }
  });
  return links;
}
function extractLinks(links, subItemFieldName) {
  var subItemField = subItemFieldName || CLUSTER_SUBITEM_FIELD;
  var elinks = [];
  links.forEach(function (v) {
    if (v[subItemField]) {
      elinks.push.apply(elinks, _toConsumableArray(extractLinks(v[subItemField], subItemField)));
    } else {
      elinks.push(v);
    }
  });
  return elinks;
}
/**
 * deliver links to each group, judge from each link's source and target nodes's group
 * @param {IGetGroupedLinkDataOptions} options
 * @returns {IGraphLink[]}
 */
function getGroupedLinkData(options) {
  var data = options.data,
    subItemFieldName = options.subItemFieldName,
    linkTypeFilter = options.linkTypeFilter,
    groupLinkAttr = options.groupLinkAttr,
    autoExtractLinks = options.autoExtractLinks;
  var subItemField = subItemFieldName || CLUSTER_SUBITEM_FIELD;
  var groupNodeMap = {},
    groupMap = {},
    nodeMap = {}; // { [nodeId]: IGraphNode }
  data.nodes.forEach(function (v) {
    if (v[subItemField]) {
      var _v$subItemField, _v$subItemField2, _groupMap$v$id;
      var subNodes = ((_v$subItemField = v[subItemField]) === null || _v$subItemField === void 0 ? void 0 : _v$subItemField.nodes) || [];
      var subLinks = ((_v$subItemField2 = v[subItemField]) === null || _v$subItemField2 === void 0 ? void 0 : _v$subItemField2.links) || [];
      groupMap[v.id] = (_groupMap$v$id = groupMap[v.id]) !== null && _groupMap$v$id !== void 0 ? _groupMap$v$id : {
        id: v.id,
        nodes: subNodes,
        links: subLinks
      };
      subNodes.forEach(function (n) {
        groupNodeMap[n.id] = v.id;
      });
    }
    nodeMap[v.id] = v;
  });
  var links = [];
  var groupLinkConnection = {}; // { [sourceid@targetid]: grouplinkid }
  var groupLinkMap = {}; // { [grouplinkid]: links }
  var newClusteredLinks = [];
  var groupLinkValueMap = {}; // {[groupLinkId]: groupValue}
  var datalinks = autoExtractLinks ? extractLinks(data.links, subItemField) : data.links;
  datalinks.forEach(function (v) {
    var _getLinkNodesId2 = getLinkNodesId(v),
      sourceId = _getLinkNodesId2.sourceId,
      targetId = _getLinkNodesId2.targetId;
    var sourceHasGroupValue = groupNodeMap.hasOwnProperty(sourceId);
    var targetHasGroupValue = groupNodeMap.hasOwnProperty(targetId);
    v.source = sourceId;
    v.target = targetId;
    if (!sourceHasGroupValue && !targetHasGroupValue) {
      links.push(v);
    } else {
      var hasArrow = !!v.arrow;
      var linkTypeValue = getLinkTypeValue(v, linkTypeFilter);
      var groupSourceNode = sourceHasGroupValue && groupMap[groupNodeMap[sourceId]];
      var groupTargetNode = targetHasGroupValue && groupMap[groupNodeMap[targetId]];
      var getLinkConnectionKey = function getLinkConnectionKey(sid, tid) {
        return hasArrow ? "".concat(sid, "@").concat(tid, "@").concat(hasArrow, "@").concat(linkTypeValue) : "".concat([sid, tid].sort(function (a, b) {
          return a > b ? 1 : -1;
        }).join('@'), "@").concat(hasArrow, "@").concat(linkTypeValue);
      };
      var groupLinkConnection_1 = groupSourceNode && groupLinkConnection[getLinkConnectionKey(groupSourceNode.id, targetId)];
      var groupLinkConnection_2 = groupTargetNode && groupLinkConnection[getLinkConnectionKey(sourceId, groupTargetNode.id)];
      var groupLinkConnection_3 = groupTargetNode && groupSourceNode && groupLinkConnection[getLinkConnectionKey(groupSourceNode.id, groupTargetNode.id)];
      var addNewLink = function addNewLink(id, source, target, arrow) {
        groupLinkMap[id] = [v];
        var newLink = _defineProperty({
          id: id,
          source: source,
          target: target,
          arrow: arrow
        }, subItemField, []);
        links.push(newLink);
        newClusteredLinks.push(newLink);
        groupLinkValueMap[id] = linkTypeValue;
      };
      if (groupSourceNode.id === groupTargetNode.id) {
        groupMap[groupNodeMap[sourceId]].links.push(v);
      } else if (groupSourceNode && groupTargetNode) {
        if (!groupLinkConnection_3) {
          var groupLinkId = v4();
          groupLinkConnection[getLinkConnectionKey(groupSourceNode.id, groupTargetNode.id)] = groupLinkId;
          addNewLink(groupLinkId, groupSourceNode.id, groupTargetNode.id, hasArrow);
        }
      } else {
        if (groupSourceNode && !groupLinkConnection_1) {
          var _groupLinkId = v4();
          groupLinkConnection[getLinkConnectionKey(groupSourceNode.id, targetId)] = _groupLinkId;
          addNewLink(_groupLinkId, groupSourceNode.id, targetId, hasArrow);
        }
        if (groupTargetNode && !groupLinkConnection_2) {
          var _groupLinkId2 = v4();
          groupLinkConnection[getLinkConnectionKey(sourceId, groupTargetNode.id)] = _groupLinkId2;
          addNewLink(_groupLinkId2, sourceId, groupTargetNode.id, hasArrow);
        }
      }
      if (groupLinkConnection_1) {
        groupLinkMap[groupLinkConnection_1].push(v);
      }
      if (groupLinkConnection_2) {
        groupLinkMap[groupLinkConnection_2].push(v);
      }
      if (groupLinkConnection_3) {
        groupLinkMap[groupLinkConnection_3].push(v);
      }
    }
  });
  newClusteredLinks.forEach(function (v) {
    var _getLinkNodesId3 = getLinkNodesId(v),
      sourceId = _getLinkNodesId3.sourceId,
      targetId = _getLinkNodesId3.targetId;
    v[subItemField] = groupLinkMap[v.id] || [];
    if (groupLinkAttr) {
      Object.assign(v, groupLinkAttr(v, groupLinkValueMap[v.id]));
    }
    var sourceNode = nodeMap[sourceId],
      targetNode = nodeMap[targetId];
    if (autoExtractLinks && sourceNode[subItemField] && targetNode[subItemField] && !!(sourceNode !== null && sourceNode !== void 0 && sourceNode.children) !== !!(targetNode !== null && targetNode !== void 0 && targetNode.children)) {
      var _nodeMap$sourceId, _nodeMap$targetId;
      v[subItemField] = getNewClusteredLinks({
        pendingNodes: [].concat(_toConsumableArray((_nodeMap$sourceId = nodeMap[sourceId]) !== null && _nodeMap$sourceId !== void 0 && _nodeMap$sourceId.children ? groupMap[sourceId].nodes : [nodeMap[sourceId]]), _toConsumableArray((_nodeMap$targetId = nodeMap[targetId]) !== null && _nodeMap$targetId !== void 0 && _nodeMap$targetId.children ? groupMap[targetId].nodes : [nodeMap[targetId]])),
        clusterLinks: [v],
        subItemFieldName: subItemField,
        linkTypeFilter: linkTypeFilter,
        groupLinkAttr: groupLinkAttr
      });
    }
  });
  return links;
}

/**
 * generate new graph data according to input nodeIds which need to be unclusterd
 * @param {IUnClusterGraphDataOptions} options
 * @param {(groupLink:IGraphLink, groupValue:string) => Object} groupLinkAttr optional
 * @returns {IGraphData}
 */
function unclusterGraphData(options, groupLinkAttr) {
  var data = options.data,
    nodeIds = options.nodeIds,
    subItemFieldName = options.subItemFieldName,
    linkTypeFilter = options.linkTypeFilter;
  var subItemField = subItemFieldName || CLUSTER_SUBITEM_FIELD;
  var nodeMap = {};
  var groupNodes = [];
  var groupLinks = [];
  /** expand nodes */
  var nodes = data.nodes.filter(function (v) {
    nodeMap[v.id] = v;
    if (nodeIds.indexOf(v.id) >= 0 && v[subItemField]) {
      var subNodes = v[subItemField].nodes;
      var subLinks = v[subItemField].links;
      groupNodes.push.apply(groupNodes, _toConsumableArray(subNodes));
      groupLinks.push.apply(groupLinks, _toConsumableArray(subLinks));
      return false;
    }
    return true;
  });
  groupNodes.forEach(function (v) {
    if (!nodeMap[v.id]) {
      nodeMap[v.id] = v;
      nodes.push(v);
    }
  });
  nodes.sort(function (a, b) {
    return a[subItemField] && !b[subItemField] ? 1 : -1;
  });
  /** expand links */
  var linkIdSet = new Set();
  var linkIds = getRelatedNodesAndLinks(nodeIds, data).links.map(function (v) {
    return v.id;
  });
  var links = [];
  data.links.forEach(function (v) {
    if (linkIds.indexOf(v.id) >= 0 && v[subItemField]) {
      var _getLinkNodesId4 = getLinkNodesId(v),
        sourceId = _getLinkNodesId4.sourceId,
        targetId = _getLinkNodesId4.targetId;
      var sourceNode = nodeMap[sourceId];
      var targetNode = nodeMap[targetId];
      if (sourceNode[subItemField] && targetNode[subItemField] && nodeIds.includes(sourceId) !== nodeIds.includes(targetId)) {
        var _sourceNode$subItemFi, _targetNode$subItemFi;
        groupLinks.push.apply(groupLinks, _toConsumableArray(getGroupedLinkData({
          data: {
            nodes: [].concat(_toConsumableArray(nodeIds.includes(sourceId) ? (_sourceNode$subItemFi = sourceNode[subItemField]) === null || _sourceNode$subItemFi === void 0 ? void 0 : _sourceNode$subItemFi.nodes : [sourceNode]), _toConsumableArray(nodeIds.includes(targetId) ? (_targetNode$subItemFi = targetNode[subItemField]) === null || _targetNode$subItemFi === void 0 ? void 0 : _targetNode$subItemFi.nodes : [targetNode])),
            links: [v]
          },
          autoExtractLinks: true,
          subItemFieldName: subItemFieldName,
          linkTypeFilter: linkTypeFilter,
          groupLinkAttr: groupLinkAttr
        })));
      } else {
        groupLinks.push.apply(groupLinks, _toConsumableArray(extractLinks(v[subItemField], subItemField)));
      }
    } else {
      linkIdSet.add(v.id);
      links.push(v);
    }
  });
  groupLinks.forEach(function (v) {
    if (!linkIdSet.has(v.id)) {
      var _getLinkNodesId5 = getLinkNodesId(v),
        sourceId = _getLinkNodesId5.sourceId,
        targetId = _getLinkNodesId5.targetId;
      if (nodeMap[targetId] && nodeMap[sourceId]) {
        v.target = targetId;
        v.source = sourceId;
        links.push(v);
        linkIdSet.add(v.id);
      }
    }
  });
  return {
    nodes: nodes,
    links: links
  };
}
/**
 * calculate cluster node's radius
 * collapseRadius: radius before zoomin
 * realRadius: radius after zoomin
 * @param {ICalculateClusterNodesRadiusOptions} options
 * @returns {collapseRadius: number, realRadius: number}
 */
function calculateClusterNodesRadius(options) {
  var subNodes = [];
  if (options.clusterNode.hasOwnProperty(options.clusterSubItemField)) {
    var _options$clusterNode$;
    subNodes = ((_options$clusterNode$ = options.clusterNode[options.clusterSubItemField]) === null || _options$clusterNode$ === void 0 ? void 0 : _options$clusterNode$.nodes) || [];
  } else {
    subNodes = options.clusterNode.children || [];
  }
  var collapseRadius = CONSTANTS.DEFAULT_NODE_RADIUS * Math.max(Math.log2(subNodes.length), 1.5);
  var padding = options.padding || CONSTANTS.DEFAULT_NODE_RADIUS;
  var realRadius = 0;
  subNodes.forEach(function (n) {
    var r = n.r || CONSTANTS.DEFAULT_NODE_RADIUS;
    realRadius = Math.max(realRadius, Math.sqrt(n.x * n.x + n.y * n.y) + r + padding);
  });
  return {
    collapseRadius: collapseRadius,
    realRadius: realRadius
  };
}
function moveIntoCluster(options) {
  var _clusterNode$clusterS;
  var nodeIds = options.nodeIds,
    data = options.data,
    clusterId = options.clusterId,
    linkTypeFilter = options.linkTypeFilter,
    groupLinkAttr = options.groupLinkAttr;
  var clusterSubItemField = options.clusterSubItemField || CLUSTER_SUBITEM_FIELD;
  var nodes = [];
  var clusterNode;
  var hasChange = false;
  var newsubnodes = [];
  data.nodes.forEach(function (v) {
    if (v.id === clusterId && v[clusterSubItemField]) {
      clusterNode = v;
    }
    if (nodeIds.includes(v.id)) {
      newsubnodes.push(v);
      hasChange = true;
    } else {
      nodes.push(v);
    }
  });
  if (!hasChange || !clusterNode) {
    return {
      clusterNode: clusterNode,
      data: data
    };
  }
  (_clusterNode$clusterS = clusterNode[clusterSubItemField].nodes).push.apply(_clusterNode$clusterS, newsubnodes);
  var relatedNodesAndLinks = getRelatedNodesAndLinks([].concat(_toConsumableArray(nodeIds), [clusterId]), data);
  var relatedLinkIds = relatedNodesAndLinks.links.map(function (v) {
    return v.id;
  });
  var links = [];
  data.links.forEach(function (v) {
    if (!relatedLinkIds.includes(v.id)) {
      links.push(v);
    } else {
      var _getLinkNodesId6 = getLinkNodesId(v),
        sourceId = _getLinkNodesId6.sourceId,
        targetId = _getLinkNodesId6.targetId;
      var nids = [].concat(_toConsumableArray(nodeIds), [clusterId]);
      if (nids.includes(sourceId) && nids.includes(targetId)) ;
    }
  });
  var newLinks = getGroupedLinkData({
    data: {
      nodes: relatedNodesAndLinks.nodes.filter(function (v) {
        return !nodeIds.includes(v.id);
      }),
      links: relatedNodesAndLinks.links
    },
    subItemFieldName: clusterSubItemField,
    linkTypeFilter: linkTypeFilter,
    autoExtractLinks: true,
    groupLinkAttr: groupLinkAttr
  });
  links.push.apply(links, _toConsumableArray(newLinks));
  var newData = {
    nodes: nodes,
    links: links
  };
  return {
    clusterNode: clusterNode,
    data: newData
  };
}
function moveOutofCluster(options) {
  var nodeIds = options.nodeIds,
    data = options.data,
    clusterId = options.clusterId,
    linkTypeFilter = options.linkTypeFilter,
    groupLinkAttr = options.groupLinkAttr,
    allowSingleNode = options.allowSingleNode;
  var clusterSubItemField = options.clusterSubItemField || CLUSTER_SUBITEM_FIELD;
  var moveOutNodes = [];
  var pendingLinks = [];
  var nodes = [];
  var clusterNode;
  data.nodes.forEach(function (v) {
    if (v.id === clusterId && v[clusterSubItemField]) {
      clusterNode = v;
      var subnodes = [];
      v[clusterSubItemField].nodes.forEach(function (n) {
        if (nodeIds.includes(n.id)) {
          n.x = n.x + v.x;
          n.y = n.y + v.y;
          n.fx = n.x;
          n.fy = n.y;
          moveOutNodes.push(n);
        } else {
          subnodes.push(n);
        }
      });
      if (!allowSingleNode && subnodes.length === 1) {
        /** if not allow single node inside cluster, move this single node out, just like uncluster */
        nodeIds.push(subnodes[0].id);
        subnodes[0].x = subnodes[0].x + v.x;
        subnodes[0].y = subnodes[0].y + v.y;
        subnodes[0].fx = subnodes[0].x;
        subnodes[0].fy = subnodes[0].y;
        moveOutNodes.push(subnodes[0]);
        subnodes = [];
      }
      v[clusterSubItemField].nodes = subnodes;
      if (moveOutNodes.length > 0) {
        v[clusterSubItemField].links = v[clusterSubItemField].links.filter(function (l) {
          var _getLinkNodesId7 = getLinkNodesId(l),
            sourceId = _getLinkNodesId7.sourceId,
            targetId = _getLinkNodesId7.targetId;
          if (nodeIds.includes(sourceId) || nodeIds.includes(targetId)) {
            pendingLinks.push(l);
            return false;
          }
          return true;
        });
      }
      if (subnodes.length > 0) {
        nodes.push(v);
      }
    } else {
      nodes.push(v);
    }
  });
  if (moveOutNodes.length === 0) {
    return {
      clusterNode: null,
      data: data
    };
  }
  var relatedNodesAndLinks = getRelatedNodesAndLinks([clusterId], data),
    relatedLinkIds = relatedNodesAndLinks.links.map(function (v) {
      return v.id;
    });
  var links = data.links.filter(function (v) {
    if (relatedLinkIds.includes(v.id)) {
      pendingLinks.push(v);
      return false;
    }
    return true;
  });
  var newLinks = getGroupedLinkData({
    data: {
      nodes: [].concat(_toConsumableArray(relatedNodesAndLinks.nodes), moveOutNodes),
      links: pendingLinks
    },
    subItemFieldName: clusterSubItemField,
    linkTypeFilter: linkTypeFilter,
    autoExtractLinks: true,
    groupLinkAttr: groupLinkAttr
  });
  links.push.apply(links, _toConsumableArray(newLinks));
  nodes.push.apply(nodes, moveOutNodes);
  nodes.sort(function (a, b) {
    return a[clusterSubItemField] && !b[clusterSubItemField] ? 1 : -1;
  });
  var newData = {
    nodes: nodes,
    links: links
  };
  return {
    clusterNode: clusterNode,
    data: newData
  };
}

export { CLUSTER_SUBITEM_FIELD, calculateClusterNodesRadius, clusterGraphData, extractLinks, getGroupedLinkData, getLinkNodesId, getLinkTypeValue, getNewClusteredLinks, moveIntoCluster, moveOutofCluster, restoreClusterData, unclusterGraphData };
