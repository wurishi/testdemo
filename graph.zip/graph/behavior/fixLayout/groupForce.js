import _toConsumableArray from '@babel/runtime/helpers/toConsumableArray';
import _typeof from '@babel/runtime/helpers/typeof';
import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _defineProperty from '@babel/runtime/helpers/defineProperty';

var CircleCollider = /*#__PURE__*/function () {
  function CircleCollider(utils) {
    var moveNodesMode = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'v';
    _classCallCheck(this, CircleCollider);
    _defineProperty(this, "_coordinates", void 0);
    _defineProperty(this, "_fixed", void 0);
    _defineProperty(this, "_center", void 0);
    _defineProperty(this, "_radius", void 0);
    _defineProperty(this, "_pingpong", void 0);
    _defineProperty(this, "_prevOffset", void 0);
    _defineProperty(this, "_offset", void 0);
    _defineProperty(this, "_moveNodesMode", void 0);
    _defineProperty(this, "_utils", void 0);
    this._coordinates = [];
    this._fixed = false;
    this._center = {
      x: 0,
      y: 0
    };
    this._radius = 0;
    this._pingpong = false;
    this._prevOffset = null;
    this._offset = {
      vx: 0,
      vy: 0
    };
    this._utils = utils;
    this._moveNodesMode = moveNodesMode;
  }
  _createClass(CircleCollider, [{
    key: "center",
    get: function get() {
      return this._center;
    }
  }, {
    key: "radius",
    get: function get() {
      return this._radius;
    }
  }, {
    key: "_testPingpong",
    value: function _testPingpong(x, vx) {
      if (x === vx) {
        return false;
      }
      if (x === 0 || vx === 0) {
        return false;
      }
      if (x > 0 && vx < 0) {
        return true;
      } else if (x < 0 && vx > 0) {
        return true;
      }
      return false;
    }
  }, {
    key: "_resetWithPingpong",
    value: function _resetWithPingpong(x, prevX) {
      if (prevX > 0) {
        return Math.abs(x);
      } else if (prevX < 0) {
        return -Math.abs(x);
      }
      return x;
    }
  }, {
    key: "calculateBoundingBox",
    value: function calculateBoundingBox() {
      this._fixed = false;
      var center = {
        x: 0,
        y: 0
      };
      var radius = 0;
      var n = this._coordinates.length;
      if (n > 0) {
        if (n === 1) {
          var _this$_coordinates$0$, _this$_coordinates$0$2;
          if (isFixed(this._coordinates[0])) {
            this._fixed = true;
          }
          center.x = (_this$_coordinates$0$ = this._coordinates[0].x) !== null && _this$_coordinates$0$ !== void 0 ? _this$_coordinates$0$ : 0;
          center.y = (_this$_coordinates$0$2 = this._coordinates[0].y) !== null && _this$_coordinates$0$2 !== void 0 ? _this$_coordinates$0$2 : 0;
          radius = 25;
          var _isClusterNode = this._utils.isClusterNode(this._coordinates[0]);
          if (_isClusterNode) {
            this._fixed = true;
          }
        } else {
          var _this$_coordinates$0$3, _this$_coordinates$0$4;
          var minX = (_this$_coordinates$0$3 = this._coordinates[0].x) !== null && _this$_coordinates$0$3 !== void 0 ? _this$_coordinates$0$3 : 0;
          var minY = (_this$_coordinates$0$4 = this._coordinates[0].y) !== null && _this$_coordinates$0$4 !== void 0 ? _this$_coordinates$0$4 : 0;
          var maxX = minX,
            maxY = minY;
          for (var i = 1; i < n; i++) {
            var coord = this._coordinates[i];
            var _coord$x = coord.x,
              x = _coord$x === void 0 ? 0 : _coord$x,
              _coord$y = coord.y,
              y = _coord$y === void 0 ? 0 : _coord$y;
            minX = Math.min(minX, x);
            minY = Math.min(minY, y);
            maxX = Math.max(maxX, x);
            maxY = Math.max(maxY, y);
            if (isFixed(coord)) {
              this._fixed = true;
            }
          }
          center.x = (minX + maxX) * 0.5;
          center.y = (minY + maxY) * 0.5;
          radius = Math.max(Math.sqrt(Math.pow(maxX - center.x, 2) + Math.pow(maxY - center.y, 2)), 25);
        }
      }
      this._center = center;
      this._radius = radius;
    }
  }, {
    key: "setCoordinates",
    value: function setCoordinates(coordinates) {
      this._coordinates = Array.isArray(coordinates) ? coordinates : [];
      this.calculateBoundingBox();
    }
  }, {
    key: "isFixed",
    value: function isFixed() {
      return this._fixed;
    }
  }, {
    key: "hitTest",
    value: function hitTest(collider) {
      var circleCollider = collider;
      if (circleCollider) {
        var targetCenter = circleCollider.center,
          targetRadius = circleCollider.radius;
        var dx = targetCenter.x - this._center.x;
        var dy = targetCenter.y - this._center.y;
        var distance = Math.sqrt(dx * dx + dy * dy);
        if (distance < targetRadius + this._radius) {
          var angle = Math.atan2(dy, dx);
          var force = targetRadius + this._radius - distance;
          return {
            vx: force * Math.cos(angle),
            vy: force * Math.sin(angle)
          };
        }
      }
      return null;
    }
  }, {
    key: "moveSelf",
    value: function moveSelf(offset) {
      if (!this._fixed) {
        var vx = offset.vx,
          vy = offset.vy;
        if (!this._prevOffset) {
          this._prevOffset = {
            vx: vx,
            vy: vy
          };
        } else {
          if (!this._pingpong) {
            var xP = this._testPingpong(this._prevOffset.vx, vx);
            var yP = this._testPingpong(this._prevOffset.vy, vy);
            this._pingpong = xP && yP;
          }
          if (this._pingpong) {
            vx = this._resetWithPingpong(vx, this._prevOffset.vx);
            vy = this._resetWithPingpong(vy, this._prevOffset.vy);
          } else {
            this._prevOffset.vx = vx;
            this._prevOffset.vy = vy;
          }
        }
        this._center.x += vx;
        this._center.y += vy;
        this._offset.vx += vx;
        this._offset.vy += vy;
      }
    }
  }, {
    key: "moveNodes",
    value: function moveNodes(alpha) {
      if (!this._fixed) {
        if (this._moveNodesMode === 'v') {
          this._updateVPosition(alpha);
        } else if (this._moveNodesMode === 'f') {
          this._updateFPosition();
        }
      }
    }
  }, {
    key: "_updateVPosition",
    value: function _updateVPosition(alpha) {
      var _this$_offset = this._offset,
        vx = _this$_offset.vx,
        vy = _this$_offset.vy;
      var alphaX = vx * alpha;
      var alphaY = vy * alpha;
      this._offset.vx -= alphaX;
      this._offset.vy -= alphaY;
      this._coordinates.forEach(function (node) {
        if (isNaN(node.vx)) {
          node.vx = alphaX;
        } else {
          node.vx += alphaX;
        }
        if (isNaN(node.vy)) {
          node.vy = alphaY;
        } else {
          node.vy += alphaY;
        }
      });
    }
  }, {
    key: "_updateFPosition",
    value: function _updateFPosition() {
      var _this$_offset2 = this._offset,
        vx = _this$_offset2.vx,
        vy = _this$_offset2.vy;
      var x = vx,
        y = vy;
      this._offset.vx = this._offset.vy = 0;
      this._coordinates.forEach(function (node) {
        if (isNaN(node.x)) {
          node.x = x;
        } else {
          node.x += x;
        }
        if (isNaN(node.y)) {
          node.y = y;
        } else {
          node.y += y;
        }
        node.fx = node.x;
        node.fy = node.y;
      });
    }
  }]);
  return CircleCollider;
}();
function groupForce(fixLayoutBehavior) {
  var ignoreForce = false;
  var groups = [];
  var utils = {
    isClusterNode: function isClusterNode(node) {
      var graph = fixLayoutBehavior.graph;
      var subNodesBehavior = graph === null || graph === void 0 ? void 0 : graph.getBehavior('subNodes');
      if (subNodesBehavior && node) {
        return !!node[subNodesBehavior.getClusterSubItemField()];
      }
      return false;
    }
  };
  var force = function force(alpha) {
    if (fixLayoutBehavior.getEnabled()) {
      if (!ignoreForce) {
        ignoreForce = groups.every(function (collider) {
          collider.calculateBoundingBox();
          return collider.isFixed();
        });
      }
      if (!ignoreForce) {
        groupCollideTest(groups, alpha);
      }
    }
  };
  var nodes = null;
  force.initialize = function (_nodes) {
    ignoreForce = false;
    nodes = _nodes;
  };
  force.links = function (links) {
    if (nodes && links) {
      if (fixLayoutBehavior.getEnabled()) {
        var result = calculateGroup({
          nodes: nodes,
          links: links
        }, utils);
        groups = result.groups;
        ignoreForce = result.allFixed;
      } else {
        groups = [];
      }
    }
  };
  return force;
}
function calculateGroup(data, utils) {
  var links = data.links,
    nodes = data.nodes;
  var groupMap = new Map();
  var cacheMap = new Map();
  var idIncremental = 0;
  links.forEach(function (link) {
    var sid = _typeof(link.source) === 'object' ? link.source.id : '';
    var tid = _typeof(link.target) === 'object' ? link.target.id : '';
    var minId = Number.MAX_SAFE_INTEGER;
    minId = Math.min(groupMap.has(sid) ? groupMap.get(sid) : minId, groupMap.has(tid) ? groupMap.get(tid) : minId);
    if (minId === Number.MAX_SAFE_INTEGER) {
      minId = idIncremental++;
    }
    updateNodesGroup(groupMap, cacheMap, [sid, tid], minId);
  });
  var groupFixedNodes = [];
  var groupNoFixedNodes = [];
  nodes.forEach(function (node) {
    var id = node.id;
    var groupId = -1;
    if (groupMap.has(id)) {
      groupId = groupMap.get(id);
    } else {
      // no link node
      groupId = idIncremental++;
    }
    if (groupId >= 0) {
      if (isFixed(node)) {
        var groupList = groupFixedNodes[groupId] || [];
        groupList.push(node);
        groupFixedNodes[groupId] = groupList;
      } else {
        var _groupList = groupNoFixedNodes[groupId] || [];
        _groupList.push(node);
        groupNoFixedNodes[groupId] = _groupList;
      }
    }
  });
  var colliderList = [];
  var allFixed = false;
  groupFixedNodes.forEach(function (gNodes) {
    if (Array.isArray(gNodes)) {
      var cc = new CircleCollider(utils);
      cc.setCoordinates(gNodes);
      colliderList.push(cc);
      if (!cc.isFixed()) {
        allFixed = false;
      }
    }
  });
  groupNoFixedNodes.forEach(function (gNodes, idx) {
    if (Array.isArray(gNodes)) {
      var mode = 'v';
      if (Array.isArray(groupFixedNodes[idx]) && groupFixedNodes[idx].length > 0) {
        mode = 'f';
      }
      var cc = new CircleCollider(utils, mode);
      cc.setCoordinates(gNodes);
      colliderList.push(cc);
      if (!cc.isFixed()) {
        allFixed = false;
      }
    }
  });
  return {
    groups: colliderList,
    allFixed: allFixed
  };
}
function updateNodesGroup(groupMap, cacheMap, waitUpdateNodeIds, groupId) {
  var allInGroupIds = waitUpdateNodeIds;
  waitUpdateNodeIds.forEach(function (nodeId) {
    if (groupMap.has(nodeId)) {
      var oldGroupId = groupMap.get(nodeId);
      allInGroupIds = allInGroupIds.concat(cacheMap.get(oldGroupId) || []);
      cacheMap["delete"](oldGroupId);
    }
  });
  allInGroupIds = _toConsumableArray(new Set(allInGroupIds));
  cacheMap.set(groupId, allInGroupIds);
  allInGroupIds.forEach(function (nodeId) {
    groupMap.set(nodeId, groupId);
  });
}
function isFixed(node) {
  if (node && (node.hasOwnProperty('fx') || node.hasOwnProperty('fy'))) {
    return true;
  }
  return false;
}
function groupCollideTest(groups, alpha) {
  var len = groups.length;
  if (len > 1) {
    for (var i = 0; i < len; i++) {
      var testCollider = groups[i];
      for (var j = 0; j < len; j++) {
        if (i !== j) {
          var _collider = groups[j];
          if (!_collider.isFixed()) {
            var _offset = testCollider.hitTest(_collider);
            if (_offset) {
              _collider.moveSelf(_offset);
            }
          }
        }
      }
    }
    for (var _i = 0; _i < len; _i++) {
      groups[_i].moveNodes(alpha);
    }
  }
}

export { groupForce as default };
