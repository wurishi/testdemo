import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _assertThisInitialized from '@babel/runtime/helpers/assertThisInitialized';
import _inherits from '@babel/runtime/helpers/inherits';
import _possibleConstructorReturn from '@babel/runtime/helpers/possibleConstructorReturn';
import _getPrototypeOf from '@babel/runtime/helpers/getPrototypeOf';
import _defineProperty from '@babel/runtime/helpers/defineProperty';
import BaseBehavior from '../base.js';
import CONSTANTS from '../../constants.js';
import { getData, getRelatedNodesAndLinks } from '../../utils.js';
import groupForce from './groupForce.js';

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var DRAGGED_FIELD = '@fixlayoutDragged';
var FixLayout = /*#__PURE__*/function (_BaseBehavior) {
  _inherits(FixLayout, _BaseBehavior);
  var _super = _createSuper(FixLayout);
  function FixLayout(graph, options) {
    var _this;
    _classCallCheck(this, FixLayout);
    _this = _super.call(this, graph, options);
    // private graph: IGraph
    _defineProperty(_assertThisInitialized(_this), "_relatedNodes", void 0);
    _defineProperty(_assertThisInitialized(_this), "_dragCenterNodes", void 0);
    _defineProperty(_assertThisInitialized(_this), "_enabled", void 0);
    _defineProperty(_assertThisInitialized(_this), "_staticNodes", void 0);
    _this._dragCenterNodes = options.dragCenterNodes || [];
    _this._staticNodes = options.staticNodes || [];
    _this._relatedNodes = [];
    _this._enabled = typeof options.enabled === 'boolean' ? options.enabled : true;
    return _this;
  }
  _createClass(FixLayout, [{
    key: "_recoredNodePosition",
    value: function _recoredNodePosition(nodes) {
      nodes.forEach(function (node) {
        node.fx = node.x;
        node.fy = node.y;
      });
    }
  }, {
    key: "_onDragStart",
    value: function _onDragStart(node) {
      var _this2 = this;
      if (!this._enabled) {
        return;
      }
      var selectedNodes = this.graph.selectedNodes;
      var graphNodes = getData.call(this.graph).nodes;
      if (selectedNodes.includes(node.id)) {
        var hasDragCenter = selectedNodes.some(function (sid) {
          return _this2._dragCenterNodes.includes(sid);
        });
        if (hasDragCenter) {
          this._relatedNodes = getRelatedNodesAndLinks(selectedNodes, getData.call(this.graph)).nodes;
        } else {
          this._relatedNodes = graphNodes.filter(function (n) {
            return selectedNodes.includes(n.id);
          });
        }
      } else if (this._dragCenterNodes.includes(node.id)) {
        this._relatedNodes = getRelatedNodesAndLinks([node.id], getData.call(this.graph)).nodes;
      } else {
        this._relatedNodes = [node];
      }
    }
  }, {
    key: "_onDragging",
    value: function _onDragging(node, evt) {
      var _this3 = this;
      if (!this._enabled) {
        return;
      }
      this._relatedNodes.forEach(function (v) {
        if (v.id === node.id || _this3._dragCenterNodes.includes(v.id) || _this3._staticNodes.includes(v.id)) {
          return;
        }
        var isDragged = !!v[DRAGGED_FIELD];
        var isInSelectedNodes = _this3.graph.selectedNodes.includes(node.id) && _this3.graph.selectedNodes.includes(v.id);
        var withCenter = isInSelectedNodes && _this3.graph.selectedNodes.some(function (sid) {
          return _this3._dragCenterNodes.includes(sid);
        });
        if (!isDragged && !withCenter && !isInSelectedNodes) {
          // then its CP exclude dragCenter ones and dragged ones need delete position info
          delete v.fx;
          delete v.fy;
        } else if (isDragged && !isInSelectedNodes) {
          // then its CP exclude dragCenter ones and selected ones which is dragged ones need move translational
          // selected ones will move translational in below condition
          v.fx = v.fx + evt.dx;
          v.fy = v.fy + evt.dy;
        }
      });
    }
  }, {
    key: "_onDragEnd",
    value: function _onDragEnd(_v, evt) {
      var _this4 = this;
      if (!this._enabled) {
        return;
      }
      this._relatedNodes.forEach(function (node) {
        if (_this4.graph.selectedNodes.includes(evt.subject.id) && _this4.graph.selectedNodes.includes(node.id)) {
          node[DRAGGED_FIELD] = true;
        } else if (!_this4.graph.selectedNodes.includes(evt.subject.id) && node.id === evt.subject.id) {
          node[DRAGGED_FIELD] = true;
        }
      });
      this._recoredNodePosition(this._relatedNodes);
    }
  }, {
    key: "setDragCenterNodes",
    value: function setDragCenterNodes(dragCenterNodes) {
      this._dragCenterNodes = dragCenterNodes;
    }
  }, {
    key: "dragCenterNodes",
    get: function get() {
      return this._dragCenterNodes;
    }
  }, {
    key: "setStaticNodes",
    value: function setStaticNodes(staticNodes) {
      this._staticNodes = staticNodes;
    }
  }, {
    key: "setEnabled",
    value: function setEnabled(enabled) {
      this._enabled = enabled;
    }
  }, {
    key: "getEnabled",
    value: function getEnabled() {
      return this._enabled;
    }
  }, {
    key: "init",
    value: function init() {
      var _this5 = this;
      this.graph.event.on(CONSTANTS.EVENT.LAYOUT_TICK_END, function () {
        if (!_this5._enabled) {
          return;
        }
        var graphData = getData.call(_this5.graph);
        _this5._recoredNodePosition(graphData.nodes);
      });
      this.graph.event.on(CONSTANTS.EVENT.DRAG_START, this._onDragStart.bind(this));
      this.graph.event.on(CONSTANTS.EVENT.DRAG, this._onDragging.bind(this));
      this.graph.event.on(CONSTANTS.EVENT.DRAG_END, this._onDragEnd.bind(this));
      this.graph.event.emit(CONSTANTS.EVENT.LAYOUT_FORCE_EXTEND, 'groupForce', groupForce(this));
    }
  }]);
  return FixLayout;
}(BaseBehavior);

export { FixLayout as default };
