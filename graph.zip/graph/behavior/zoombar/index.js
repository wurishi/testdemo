import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _inherits from '@babel/runtime/helpers/inherits';
import _possibleConstructorReturn from '@babel/runtime/helpers/possibleConstructorReturn';
import _getPrototypeOf from '@babel/runtime/helpers/getPrototypeOf';
import _slicedToArray from '@babel/runtime/helpers/slicedToArray';
import './style.scss.js';
import 'rc-slider/assets/index.css';
import React, { useMemo, useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import BaseBehavior from '../base.js';
import RcSlider from 'rc-slider';
import CONSTANTS from '../../constants.js';
import { floatPlus } from '../../utils.js';
import Tooltip, { Theme } from '../../../components/Tooltip/index.js';

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var scaleTimer = null;
function Bar(props) {
  var _props$options2;
  var toolTipPosition = useMemo(function () {
    var _props$options;
    return ((_props$options = props.options) === null || _props$options === void 0 ? void 0 : _props$options.position) === 'left' ? 'right' : 'left';
  }, [(_props$options2 = props.options) === null || _props$options2 === void 0 ? void 0 : _props$options2.position]);
  var _useState = useState(4),
    _useState2 = _slicedToArray(_useState, 2),
    sliderValue = _useState2[0],
    setSliderValue = _useState2[1];
  var minValue = 1,
    maxValue = 7;
  var sliderStep = 0.01;
  var sliderArr = [1, 2, 3, 4, 5, 6, 7];
  var scaleArr = [0.11, 0.214, 0.417, 0.812, 1.58, 3, 6];
  var calculateScaleFormula = function calculateScaleFormula(arrNum, num) {
    var min = scaleArr[arrNum];
    var max = scaleArr[arrNum + 1];
    return min + (max - min) / 100 * num;
  };
  /** calculateMapping */
  var sliderObj = useMemo(function () {
    var graphScale = 0;
    var num = 0;
    var sliderToScaleObj = {};
    var scaleToSliderObj = {};
    var scaleToSliderArr = [];
    for (var i = 1; i <= 7;) {
      num++;
      if (sliderArr.includes(i)) {
        num = 0;
        if (i === 7) {
          graphScale = 6;
        }
      }
      var arrNum = Math.floor(i) - 1;
      if (i !== 7) {
        graphScale = calculateScaleFormula(arrNum, num);
      }
      var tempValue = parseFloat(i.toFixed(2));
      sliderToScaleObj[tempValue] = graphScale;
      scaleToSliderObj[graphScale] = tempValue;
      scaleToSliderArr.push(graphScale);
      i = floatPlus(i, sliderStep);
    }
    return {
      sliderToScaleObj: sliderToScaleObj,
      scaleToSliderObj: scaleToSliderObj,
      scaleToSliderArr: scaleToSliderArr
    };
  }, []);
  useEffect(function () {
    /** update sliderValue when user zoom end event triggered */
    var onZoomEnd = function onZoomEnd() {
      var _props$graph$getZoom = props.graph.getZoom(),
        transform = _props$graph$getZoom.transform;
      var graphScale = transform.k;
      var sValue = 1;
      var scaleValue = 0.11;
      if (graphScale >= scaleArr[6]) {
        scaleValue = scaleArr[6];
      }
      for (var i = 0; i < sliderObj.scaleToSliderArr.length - 1; i++) {
        var beforeScale = sliderObj.scaleToSliderArr[i];
        var afterScale = sliderObj.scaleToSliderArr[i + 1];
        if (graphScale === beforeScale) {
          scaleValue = beforeScale;
          break;
        }
        if (graphScale > beforeScale && graphScale < afterScale) {
          scaleValue = afterScale;
          break;
        }
      }
      sValue = sliderObj.scaleToSliderObj[scaleValue];
      setSliderValue(sValue);
    };
    props.graph.event.on(CONSTANTS.EVENT.LAYOUT_ZOOM_END, onZoomEnd);
    return function () {
      props.graph.event.off(CONSTANTS.EVENT.LAYOUT_ZOOM_END, onZoomEnd);
    };
  }, []);

  /** update graph zoom, zoom origin will be center of container */
  function changeZoomScale(k) {
    var _props$graph$getZoom2 = props.graph.getZoom(),
      transform = _props$graph$getZoom2.transform,
      zoomTo = _props$graph$getZoom2.zoomTo;
    if (!transform) {
      return;
    }
    var _props$graph$getConta = props.graph.getContainer(),
      width = _props$graph$getConta.width,
      height = _props$graph$getConta.height;
    var x = (transform.x - width / 2) / transform.k * k + width / 2;
    var y = (transform.y - height / 2) / transform.k * k + height / 2;
    zoomTo(x, y, k);
  }
  function onSlideChange(v) {
    setSliderValue(v);
    var scale = sliderObj.sliderToScaleObj[v];
    if (scaleTimer) {
      clearTimeout(scaleTimer);
    }
    scaleTimer = setTimeout(function () {
      return changeZoomScale(scale);
    }, 100);
  }
  function fitGraph() {
    props.graph.fitGraph();
  }
  function zoomPlus() {
    if (sliderValue >= maxValue) {
      return;
    }
    if (scaleTimer) {
      clearTimeout(scaleTimer);
    }
    scaleTimer = setTimeout(function () {
      return onSlideChange(Math.min(floatPlus(sliderValue, 1), maxValue));
    }, 100);
  }
  function zoomMinus() {
    if (sliderValue <= minValue) {
      return;
    }
    if (scaleTimer) {
      clearTimeout(scaleTimer);
    }
    scaleTimer = setTimeout(function () {
      return onSlideChange(Math.max(floatPlus(sliderValue, -1), minValue));
    }, 100);
  }
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Tooltip, {
    content: "Fit Graph",
    position: toolTipPosition,
    className: props.options.tooltipClassName,
    theme: props.options.tooltipTheme || Theme.v1
  }, /*#__PURE__*/React.createElement("div", {
    className: "zoombar-btn fit",
    onClick: fitGraph
  }, /*#__PURE__*/React.createElement("span", {
    className: CONSTANTS.CLASSNAME.GRAPH_ICON
  }, "\uE90B"))), /*#__PURE__*/React.createElement(Tooltip, {
    content: "Zoom in",
    position: toolTipPosition,
    className: props.options.tooltipClassName,
    theme: props.options.tooltipTheme || Theme.v1
  }, /*#__PURE__*/React.createElement("div", {
    className: "zoombar-btn plus",
    onClick: zoomPlus
  }, /*#__PURE__*/React.createElement("span", {
    className: CONSTANTS.CLASSNAME.GRAPH_ICON
  }, "\uE92A"))), /*#__PURE__*/React.createElement(RcSlider, {
    min: minValue,
    max: maxValue,
    step: sliderStep,
    value: sliderValue,
    vertical: true,
    onChange: onSlideChange
  }), /*#__PURE__*/React.createElement(Tooltip, {
    content: "Zoom out",
    position: toolTipPosition,
    className: props.options.tooltipClassName,
    theme: props.options.tooltipTheme || Theme.v1
  }, /*#__PURE__*/React.createElement("div", {
    className: "zoombar-btn minus",
    onClick: zoomMinus
  }, /*#__PURE__*/React.createElement("span", {
    className: CONSTANTS.CLASSNAME.GRAPH_ICON
  }, "\uE929"))), props.options.renderExtraContent && props.options.renderExtraContent());
}
var ZOOMBARID = 'graph-behavior-zoombar';
var ZoomBar = /*#__PURE__*/function (_BaseBehavior) {
  _inherits(ZoomBar, _BaseBehavior);
  var _super = _createSuper(ZoomBar);
  // private graph: IGraph
  function ZoomBar(graph, options) {
    _classCallCheck(this, ZoomBar);
    return _super.call(this, graph, options);
  }
  /**
   * find or create zoombar dom element
   * @returns {HTMLDivElement}
   */
  _createClass(ZoomBar, [{
    key: "getBarEl",
    value: function getBarEl() {
      var _this = this;
      var _this$graph$getContai = this.graph.getContainer(),
        container = _this$graph$getContai.container;
      var barEL = container.querySelector("#".concat(ZOOMBARID));
      if (!barEL) {
        barEL = document.createElement('div');
        barEL.id = ZOOMBARID;
        container.append(barEL);
      }
      barEL.removeAttribute('style');
      if (this.options.offset) {
        ['left', 'right', 'bottom', 'top'].forEach(function (k) {
          if (_this.options.offset[k]) {
            barEL.style[k] = _this.options.offset[k];
          }
        });
      }
      barEL.className = this.options.className || '';
      ['left', 'right'].forEach(function (k) {
        barEL.classList.remove("position-".concat(k));
      });
      if (this.options.position) {
        barEL.classList.add("position-".concat(this.options.position));
      }
      return barEL;
    }
  }, {
    key: "init",
    value: function init() {
      var barEl = this.getBarEl();
      /** ReactDom.render no longer supported in React 18, should add some compatible code here */
      ReactDOM.render( /*#__PURE__*/React.createElement(Bar, {
        graph: this.graph,
        options: this.options
      }), barEl);
    }
  }]);
  return ZoomBar;
}(BaseBehavior);

export { ZoomBar as default };
