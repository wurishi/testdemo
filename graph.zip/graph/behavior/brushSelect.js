import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _assertThisInitialized from '@babel/runtime/helpers/assertThisInitialized';
import _inherits from '@babel/runtime/helpers/inherits';
import _possibleConstructorReturn from '@babel/runtime/helpers/possibleConstructorReturn';
import _getPrototypeOf from '@babel/runtime/helpers/getPrototypeOf';
import _defineProperty from '@babel/runtime/helpers/defineProperty';
import * as d3 from 'd3v7';
import BaseBehavior from './base.js';
import { isDomVisible } from '../utils.js';
import CONSTANTS from '../constants.js';

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var BRUSH_CONTAINER_CLASSNAME = 'graph__brush-container';
var BrushSelect = /*#__PURE__*/function (_BaseBehavior) {
  _inherits(BrushSelect, _BaseBehavior);
  var _super = _createSuper(BrushSelect);
  function BrushSelect(graph, options) {
    var _this;
    _classCallCheck(this, BrushSelect);
    _this = _super.call(this, graph, options);
    // private graph: IGraph
    _defineProperty(_assertThisInitialized(_this), "isBrushEnabled", void 0);
    _defineProperty(_assertThisInitialized(_this), "brush", void 0);
    _defineProperty(_assertThisInitialized(_this), "brushEL", void 0);
    _this.isBrushEnabled = false;
    return _this;
  }
  /**
   * be called when stop brush move
   * calculate how many nodes are inside the selection area
   * callback to vertical through options.onBrushEnd
   * @param {d3.D3BrushEvent<any>} evt
   * @returns
   */
  _createClass(BrushSelect, [{
    key: "brushEnd",
    value: function brushEnd(evt) {
      var selection = evt.selection;
      if (!selection || selection.length < 2 || !this.options.onBrushEnd) {
        if (!selection && this.options.onBrushEnd) {
          /** user click or brush.clear will cause selection equals null */
          this.options.onBrushEnd([], null);
        }
        return;
      }
      var _this$graph$getZoom$t = this.graph.getZoom().transform,
        x = _this$graph$getZoom$t.x,
        y = _this$graph$getZoom$t.y,
        k = _this$graph$getZoom$t.k;
      var graphSelection = selection.map(function (pos) {
        return [(pos[0] - x) / k, (pos[1] - y) / k];
      });
      var _this$graph$getContai = this.graph.getContainer(),
        nodeGroup = _this$graph$getContai.nodeGroup;
      var isAreaInside = function isAreaInside(nx, ny) {
        return nx > graphSelection[0][0] && nx < graphSelection[1][0] && ny > graphSelection[0][1] && ny < graphSelection[1][1];
      };
      var selectedNodes = nodeGroup.filter(function (v, idx, list) {
        return isAreaInside(v.x, v.y) && isDomVisible(list[idx]);
      }).data();
      this.graph.event.emit(CONSTANTS.EVENT.BEHAVIOR_BRUSHSELECT_ONBRUSHEND, selectedNodes, graphSelection);
      this.options.onBrushEnd(selectedNodes, graphSelection);
    }
    /**
     * create container element inside svg
     * bind brush to container
     */
  }, {
    key: "initBrush",
    value: function initBrush() {
      var _this$options, _this$options2;
      var _this$graph$getContai2 = this.graph.getContainer(),
        svg = _this$graph$getContai2.svg;
      svg.selectAll(".".concat(BRUSH_CONTAINER_CLASSNAME)).remove();
      this.brushEL = svg.append('g').classed(BRUSH_CONTAINER_CLASSNAME, true).classed((_this$options = this.options) === null || _this$options === void 0 ? void 0 : _this$options.className, !!((_this$options2 = this.options) !== null && _this$options2 !== void 0 && _this$options2.className));
      this.brushEL.call(this.brush);
    }
    /**
     * be called by vertical, to clear the current selection
     * @returns
     */
  }, {
    key: "clearSelection",
    value: function clearSelection() {
      if (!this.isBrushEnabled) {
        return;
      }
      this.brush.clear(this.brushEL);
    }
    /**
     * be called by vertical, to create a brush selection manually
     * @param {d3.BrushSelection} selection position of selection area
     * @returns
     */
  }, {
    key: "moveSelection",
    value: function moveSelection(selection) {
      if (!this.isBrushEnabled) {
        return;
      }
      this.brushEL.call(this.brush.move, selection);
    }
    /**
     * be called by vertical, user should control whether brush is enabled
     * @param {boolean} isEnabled optional, if not provide will be set as !this.isBrushEnabled
     * @returns
     */
  }, {
    key: "toggleBrushEnabled",
    value: function toggleBrushEnabled(isEnabled) {
      if (typeof isEnabled === 'boolean') {
        if (isEnabled === this.isBrushEnabled) {
          return;
        }
        this.isBrushEnabled = isEnabled;
      } else {
        this.isBrushEnabled = !this.isBrushEnabled;
      }
      if (this.isBrushEnabled) {
        this.initBrush();
      } else {
        this.destroy();
      }
    }
    /**
     * be called by vertical, return whether the brush is enabled
     * @returns {boolean}
     */
  }, {
    key: "isEnabled",
    value: function isEnabled() {
      return this.isBrushEnabled;
    }
  }, {
    key: "init",
    value: function init() {
      var _this2 = this;
      this.brush = d3.brush();
      this.brush.on('end', this.brushEnd.bind(this));
      this.graph.getZoom().zoom.filter(function (evt) {
        /** when brush enabled, should disable container zoom and transform */
        var v = (!evt.ctrlKey || evt.type === 'wheel') && !evt.button; // default value
        return !_this2.isBrushEnabled && v;
      });
    }
  }, {
    key: "destroy",
    value: function destroy() {
      this.isBrushEnabled = false;
      var _this$graph$getContai3 = this.graph.getContainer(),
        svg = _this$graph$getContai3.svg;
      svg.selectAll(".".concat(BRUSH_CONTAINER_CLASSNAME)).remove();
    }
  }]);
  return BrushSelect;
}(BaseBehavior);

export { BrushSelect as default };
