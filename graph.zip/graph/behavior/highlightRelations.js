import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _assertThisInitialized from '@babel/runtime/helpers/assertThisInitialized';
import _inherits from '@babel/runtime/helpers/inherits';
import _possibleConstructorReturn from '@babel/runtime/helpers/possibleConstructorReturn';
import _getPrototypeOf from '@babel/runtime/helpers/getPrototypeOf';
import _defineProperty from '@babel/runtime/helpers/defineProperty';
import BaseBehavior from './base.js';
import CONSTANTS from '../constants.js';
import { getRelatedNodesAndLinks, getData } from '../utils.js';

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var HighlightRelations = /*#__PURE__*/function (_BaseBehavior) {
  _inherits(HighlightRelations, _BaseBehavior);
  var _super = _createSuper(HighlightRelations);
  // @deprecated, miss-spelling
  function HighlightRelations(graph, options) {
    var _this;
    _classCallCheck(this, HighlightRelations);
    _this = _super.call(this, graph, options);
    // private graph: IGraph
    _defineProperty(_assertThisInitialized(_this), "timer", void 0);
    _defineProperty(_assertThisInitialized(_this), "isMoving", void 0);
    _defineProperty(_assertThisInitialized(_this), "extraLinkData", void 0);
    _defineProperty(_assertThisInitialized(_this), "hightlightByNodeId", void 0);
    _this.hightlightByNodeId = _this.highlightByNodeId.bind(_assertThisInitialized(_this)); // @deprecated, miss-spelling
    return _this;
  }
  _createClass(HighlightRelations, [{
    key: "highlight",
    value: function highlight(data) {
      var _this2 = this;
      if (this.isMoving) {
        return;
      }
      if (this.timer) {
        clearTimeout(this.timer);
      }
      this.timer = setTimeout(function () {
        var _this2$extraLinkData;
        var _this2$graph$getConta = _this2.graph.getContainer(),
          nodeGroup = _this2$graph$getConta.nodeGroup,
          linkGroup = _this2$graph$getConta.linkGroup;
        var relatedItems = getRelatedNodesAndLinks([data.id], getData.call(_this2.graph));
        var realtedNodeIds = relatedItems.nodes.map(function (v) {
            return v.id;
          }),
          relatedLinkIds = relatedItems.links.map(function (v) {
            return v.id;
          });
        nodeGroup.attr('opacity', function (d) {
          return realtedNodeIds.indexOf(d.id) >= 0 ? 1 : 0.1;
        });
        linkGroup.attr('opacity', function (d) {
          return relatedLinkIds.indexOf(d.id) >= 0 ? 1 : 0.1;
        });
        if ((_this2$extraLinkData = _this2.extraLinkData) !== null && _this2$extraLinkData !== void 0 && _this2$extraLinkData.links) {
          var _this2$extraLinkData2;
          (_this2$extraLinkData2 = _this2.extraLinkData) === null || _this2$extraLinkData2 === void 0 ? void 0 : _this2$extraLinkData2.links.attr('opacity', function (d) {
            var relatedId = _this2.extraLinkData.relatedMap[d.id];
            return relatedLinkIds.indexOf(relatedId) >= 0 ? 1 : 0.1;
          });
        }
      }, 100);
    }
  }, {
    key: "restore",
    value: function restore() {
      var _this$extraLinkData;
      if (this.isMoving) {
        return;
      }
      if (this.timer) {
        clearTimeout(this.timer);
      }
      var _this$graph$getContai = this.graph.getContainer(),
        nodeGroup = _this$graph$getContai.nodeGroup,
        linkGroup = _this$graph$getContai.linkGroup;
      nodeGroup.attr('opacity', '');
      linkGroup.attr('opacity', '');
      (_this$extraLinkData = this.extraLinkData) === null || _this$extraLinkData === void 0 ? void 0 : _this$extraLinkData.links.attr('opacity', '');
    }
  }, {
    key: "init",
    value: function init() {
      var _this3 = this;
      this.graph.event.on(CONSTANTS.EVENT.APPLY_EXTRA_LINKS, function (data) {
        _this3.extraLinkData = data;
      });
      // if (!this.options.disableHighlightByHover) {
      //   this.graph.event.on(CONSTANTS.EVENT.NODE_MOUSEENTER, function (data) {
      //     return _this3.highlight(data);
      //   });
      //   this.graph.event.on(CONSTANTS.EVENT.NODE_MOUSELEAVE, function () {
      //     return _this3.restore();
      //   });
      // }
      this.graph.event.on(CONSTANTS.EVENT.CHANGE_GRAPH_DATA, function () {
        return _this3.restore();
      });
      this.graph.event.on(CONSTANTS.EVENT.DRAG_START, function () {
        _this3.isMoving = true;
      });
      this.graph.event.on(CONSTANTS.EVENT.DRAG_END, function () {
        _this3.isMoving = false;
      });
    }
  }, {
    key: "highlightByNodeId",
    value: function highlightByNodeId(nodeId) {
      this.highlight({
        id: nodeId
      });
    }
  }, {
    key: "restoreHighlights",
    value: function restoreHighlights() {
      this.restore();
    }
  }]);
  return HighlightRelations;
}(BaseBehavior);

export { HighlightRelations as default };
