import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _defineProperty from '@babel/runtime/helpers/defineProperty';

var BaseBehavior = /*#__PURE__*/function () {
  function BaseBehavior(graph, options) {
    _classCallCheck(this, BaseBehavior);
    _defineProperty(this, "graph", void 0);
    _defineProperty(this, "options", void 0);
    _defineProperty(this, "_behaviorName", void 0);
    this.graph = graph;
    this.options = options && options.constructor === Object ? options : {};
  }
  _createClass(BaseBehavior, [{
    key: "init",
    value: function init() {}
  }, {
    key: "destroy",
    value: function destroy() {}
  }, {
    key: "name",
    get: function get() {
      return this._behaviorName;
    },
    set: function set(name) {
      this._behaviorName = name;
    }
  }]);
  return BaseBehavior;
}();

export { BaseBehavior as default };
