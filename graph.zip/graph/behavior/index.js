import _createClass from '@babel/runtime/helpers/createClass';
import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _inherits from '@babel/runtime/helpers/inherits';
import _possibleConstructorReturn from '@babel/runtime/helpers/possibleConstructorReturn';
import _getPrototypeOf from '@babel/runtime/helpers/getPrototypeOf';
import BaseBehavior from './base.js';
import CONSTANTS from '../constants.js';
import HighlightRelations from './highlightRelations.js';
import SubNodes from './subNodes/index.js';
import ZoomBar from './zoombar/index.js';
import BrushSelect from './brushSelect.js';
import LocateHighlight from './locateHighlight/index.js';
import FixLayout from './fixLayout/index.js';

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var DefaultBehavior = /*#__PURE__*/function (_BaseBehavior) {
  _inherits(DefaultBehavior, _BaseBehavior);
  var _super = _createSuper(DefaultBehavior);
  function DefaultBehavior() {
    _classCallCheck(this, DefaultBehavior);
    return _super.apply(this, arguments);
  }
  return _createClass(DefaultBehavior);
}(BaseBehavior);
var behaviorMap = {};
function registerBehavior(name, pluginClass) {
  if (behaviorMap[name]) {
    throw new Error("[registerBehavior] behavior '".concat(name, "' already exists."));
  }
  behaviorMap[name] = pluginClass;
}
registerBehavior(CONSTANTS.BEHAVIOR.HIGHLIGHT_RELATIONS, HighlightRelations);
registerBehavior(CONSTANTS.BEHAVIOR.SUBNODES, SubNodes);
registerBehavior(CONSTANTS.BEHAVIOR.ZOOMBAR, ZoomBar);
registerBehavior(CONSTANTS.BEHAVIOR.BRUSH_SELECT, BrushSelect);
registerBehavior(CONSTANTS.BEHAVIOR.LOCATE_HIGHLIGHT, LocateHighlight);
registerBehavior(CONSTANTS.BEHAVIOR.FIX_LAYOUT, FixLayout);
function behaviorController(behaviorOptions) {
  var name = typeof behaviorOptions === 'string' ? behaviorOptions : behaviorOptions === null || behaviorOptions === void 0 ? void 0 : behaviorOptions.type;
  return behaviorMap[name] || DefaultBehavior;
}

export { behaviorController as default, registerBehavior };
