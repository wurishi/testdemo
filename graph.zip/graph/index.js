import _toConsumableArray from '@babel/runtime/helpers/toConsumableArray';
import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _defineProperty from '@babel/runtime/helpers/defineProperty';
import * as d3 from 'd3v7';
import EventEmitter from 'eventemitter3';
import ResizeObserver from 'resize-observer-polyfill';
import debounce from 'lodash.debounce';
import layoutController from './layout/index.js';
import DrawGraph from './layout/draw.js';
import DragEvent from './events/drag.js';
import behaviorController from './behavior/index.js';
import { UpdateGraphScope } from './types.js';
import CONSTANTS from './constants.js';
import { hasDuplicates, deepCopy, getDataByAttributes, getLinksConnection, getGraphNodeUnions, setLinksAttributes, getGraphDataWhenNodesRemove, expandAggregatedEdges } from './utils.js';
import { updateClassName } from './layout/drawUtils.js';
import './styles/index.scss.js';

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
var Graph = /*#__PURE__*/function () {
  function Graph(props) {
    _classCallCheck(this, Graph);
    _defineProperty(this, "data", void 0);
    _defineProperty(this, "layout", void 0);
    _defineProperty(this, "outerContainer", void 0);
    _defineProperty(this, "container", void 0);
    _defineProperty(this, "zoom", void 0);
    _defineProperty(this, "_zoomTransform", void 0);
    _defineProperty(this, "svg", void 0);
    _defineProperty(this, "zoomContainer", void 0);
    _defineProperty(this, "drawController", void 0);
    _defineProperty(this, "_selectedNodes", void 0);
    _defineProperty(this, "_selectedLinks", void 0);
    _defineProperty(this, "dragEvent", void 0);
    _defineProperty(this, "options", void 0);
    _defineProperty(this, "event", void 0);
    _defineProperty(this, "_behaviors", void 0);
    _defineProperty(this, "_plugins", void 0);
    this.data = {
      nodes: [],
      links: []
    };
    // avoid raw data are modified
    this.data = deepCopy(props.data);
    this.outerContainer = props.outerContainer;
    this.options = _objectSpread({
      autoFitGraph: true
    }, props);
    this.event = new EventEmitter();
    this.initLayout();
    this.initBehavior(props.behaviors);
    this.initPlugins(props.plugins);
    this.registerEvent();
    this.event.emit(CONSTANTS.EVENT.GRAPH_ON_INSTANCE);
  }

  /**
   * check if graph data are valid
   * 1. if node has property id and not duplicated
   * 2. if link has property id and not duplicated
   * 3. if link's source/target exists in nodes
   * @param {IGraphData} data
   * @returns {string} return error message, not empty means invalid
   */
  _createClass(Graph, [{
    key: "verifyGraphData",
    value: function verifyGraphData(data) {
      var errorMessage = '';
      var allitems = function allitems(list, refIds) {
        var ids = [];
        var refExists = true;
        var flatList = list.map(function (v) {
          ids.push(v.id);
          if (refIds && refExists) {
            // check link source/target exists
            var vsourceId = typeof v.source === 'string' ? v.source : v.source.id;
            var vtargetId = typeof v.target === 'string' ? v.target : v.target.id;
            refExists = refIds.includes(vsourceId) && refIds.includes(vtargetId);
          }
          if (v.children && !refIds) {
            // should only consider nodes children
            return [{
              id: v.id
            }].concat(_toConsumableArray(v.children.map(function (c) {
              ids.push(c.id);
              if (refIds && refExists) {
                // check link source/target exists
                var isInclude = function isInclude(k) {
                  if (!k) return true;
                  return refIds.includes(typeof k === 'string' ? k : k.id);
                };
                refExists = isInclude(c.source) && isInclude(c.target);
              }
              return {
                id: c.id
              };
            })));
          }
          return [{
            id: v.id
          }];
        }).flat();
        return [flatList, ids, refExists];
      };
      var nodeItems = allitems(data.nodes);
      var linkItems = allitems(data.links, nodeItems[1]);
      var nodeError = hasDuplicates(nodeItems[0], 'id');
      var linkError = hasDuplicates(linkItems[0], 'id');
      if (nodeError) {
        errorMessage = nodeError;
      } else if (linkError) {
        errorMessage = linkError;
      } else if (!linkItems[2]) {
        errorMessage = 'source/target id not exists';
      }
      if (errorMessage) {
        console.log(new Error(errorMessage));
      }
      return errorMessage;
    }
  }, {
    key: "initLayout",
    value: function initLayout() {
      var _this$options$zoom,
        _this$options$zoom2,
        _this = this;
      this.outerContainer.innerHTML = '';
      this.container = document.createElement('div');
      this.container.className = 'graph__container';
      this.outerContainer.appendChild(this.container);
      var viewport = d3.select(this.container),
        width = this.outerContainer.offsetWidth,
        height = this.outerContainer.offsetHeight;
      this.svg = viewport.append('svg').attr('width', width).attr('height', height);
      this.zoomContainer = this.svg.append('g');
      var zoomMin = ((_this$options$zoom = this.options.zoom) === null || _this$options$zoom === void 0 ? void 0 : _this$options$zoom.min) || 0.005;
      var zoomMax = ((_this$options$zoom2 = this.options.zoom) === null || _this$options$zoom2 === void 0 ? void 0 : _this$options$zoom2.max) || 500;
      if (!this.options.zoom) {
        this.options.zoom = {};
      }
      this.options.zoom.min = zoomMin;
      this.options.zoom.max = zoomMax;
      var zoomstart = false;
      this.zoom = d3.zoom().scaleExtent([zoomMin, zoomMax]).on('zoom', function (evt) {
        var transform = evt.transform;
        if (transform && transform.k > 0 && !Number.isNaN(transform.x) && !Number.isNaN(transform.y)) {
          if (!zoomstart) {
            /** to avoid being triggered by click event */
            _this.event.emit(CONSTANTS.EVENT.LAYOUT_ZOOM_START, evt);
            zoomstart = true;
          }
          _this._zoomTransform = transform;
          _this.zoomContainer.attr('transform', transform);
          _this.event.emit(CONSTANTS.EVENT.LAYOUT_ZOOM);
        }
      }).on('end', function () {
        if (zoomstart) {
          var _this$event;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          (_this$event = _this.event).emit.apply(_this$event, [CONSTANTS.EVENT.LAYOUT_ZOOM_END].concat(args));
          zoomstart = false;
        }
      });
      this.svg.call(this.zoom).on('dblclick.zoom', null);
      this.layout = layoutController(this, this.options.layout);
      this.dragEvent = new DragEvent(this, this.layout);
      this.drawController = new DrawGraph(this, this.zoomContainer, this.dragEvent);
    }
  }, {
    key: "initBehavior",
    value: function initBehavior(behaviorOptions) {
      /** destroy previous behaviors */
      // todo - only destroy ones not in next config
      if (this._behaviors && this._behaviors.length > 0) {
        this._behaviors.forEach(function (v) {
          if (v.destroy) {
            v.destroy();
          }
        });
      }
      this._behaviors = [];
      /** register new behaviors */
      this.addBehaviors(behaviorOptions);
    }
  }, {
    key: "initPlugins",
    value: function initPlugins(plugins) {
      /** destroy previous plugins */
      // todo - only destroy ones not in next config
      if (this._plugins && this._plugins.length > 0) {
        this._plugins.forEach(function (v) {
          if (v.destroy) {
            v.destroy();
          }
        });
      }
      this._plugins = [];
      /** register new plugins */
      this.addPlugins(plugins);
    }
  }, {
    key: "registerEvent",
    value: function registerEvent() {
      var _this2 = this;
      this.event.on(CONSTANTS.EVENT.LAYOUT_TICK_END, function (isStart) {
        if (isStart && _this2.options.autoFitGraph) {
          _this2.fitGraph();
        }
      });
      if (this.options.isDragEnabled) {
        this.dragEvent.init();
      }
      var onChangeContainerSize = function onChangeContainerSize() {
        var containerData = _this2.getContainer();
        _this2.svg.attr('width', containerData.width);
        _this2.svg.attr('height', containerData.height);
        _this2.event.emit(CONSTANTS.EVENT.CHANGE_CONTAINER_SIZE, containerData);
      };
      var resizeObserver = new ResizeObserver(debounce(onChangeContainerSize, 100));
      resizeObserver.observe(this.outerContainer);
      this.svg.on('click', function (evt) {
        if (evt.target !== _this2.svg.node()) {
          return;
        }
        var offsetX = evt.offsetX,
          offsetY = evt.offsetY;
        var _this2$_zoomTransform = _this2._zoomTransform,
          x = _this2$_zoomTransform.x,
          y = _this2$_zoomTransform.y,
          k = _this2$_zoomTransform.k;
        var realX = (offsetX - x) / k,
          realY = (offsetY - y) / k;
        _this2.event.emit(CONSTANTS.EVENT.LAYOUT_CLICK, {
          realX: realX,
          realY: realY,
          isSvg: evt.target === evt.currentTarget
        }, evt);
      });
    }
  }, {
    key: "updateGraph",
    value: function updateGraph(scope, updateIds) {
      this.drawController.updateGraph(scope, updateIds);
    }
  }, {
    key: "render",
    value: function render(onError) {
      var _this3 = this;
      var verifyDataErrmsg = this.verifyGraphData(this.data);
      var rollbackData = function rollbackData(err) {
        _this3.data = {
          nodes: [],
          links: []
        };
        if (onError) {
          onError(err);
        }
        _this3.event.emit(CONSTANTS.EVENT.GRAPH_ON_ERROR, err);
      };
      if (verifyDataErrmsg) {
        rollbackData(new Error(verifyDataErrmsg));
      }
      this.zoomTo(0, 0, 1, 0);
      this.drawController.drawGraph();
      this.layout.start(function (err) {
        rollbackData(err);
        _this3.drawController.drawGraph();
      });
    }
  }, {
    key: "getData",
    value: function getData() {
      return deepCopy(this.data);
    }

    /**
     * get nodes by attributes
     * @param {any[]} values
     * @param {string} field eg. 'id' 'raw.properity.xxx'
     * @param {string} childField optional. if set value, will deep search from this field 'children' '@clusterSubItems.nodes'
     * @param {boolean} like optional. default is exactly match, can set to true to apply partly match
     * @returns {nodes:IGraphNode[], subNodes:Array<{parentNode:IGraphNode, nodes:IGraphNode[]}>}
     */
  }, {
    key: "getNodesByAttributes",
    value: function getNodesByAttributes(values, field, childField, like) {
      var d = getDataByAttributes(this.data.nodes, values, field, childField, like);
      return {
        nodes: d.items,
        subNodes: d.subItems.map(function (v) {
          return {
            parentNode: v.parent,
            nodes: v.items
          };
        })
      };
    }

    /**
     * get links by attributes
     * @param {any[]} values
     * @param {string} field eg. 'id' 'raw.properity.xxx'
     * @param {string} childField optional. if set value, will deep search from this field 'children' '@clusterSubItems'
     * @param {boolean} like optional. default is exactly match, can set to true to apply partly match
     * @returns {links:IGraphLink[], subLinks:Array<{parentLink:IGraphLink, links:IGraphLink[]}>}
     */
  }, {
    key: "getLinksByAttributes",
    value: function getLinksByAttributes(values, field, childField, like) {
      var d = getDataByAttributes(this.data.links, values, field, childField, like);
      return {
        links: d.items,
        subLinks: d.subItems.map(function (v) {
          return {
            parentLink: v.parent,
            links: v.items
          };
        })
      };
    }
  }, {
    key: "getContainer",
    value: function getContainer() {
      return {
        outerContainer: this.outerContainer,
        width: this.outerContainer.clientWidth,
        height: this.outerContainer.clientHeight,
        container: this.container,
        svg: this.svg,
        zoomContainer: this.zoomContainer,
        nodeGroup: this.drawController.nodeGroup,
        linkGroup: this.drawController.linkGroup
      };
    }
  }, {
    key: "graphBounds",
    value: function graphBounds() {
      var x = Number.POSITIVE_INFINITY;
      var X = Number.NEGATIVE_INFINITY;
      var y = Number.POSITIVE_INFINITY;
      var Y = Number.NEGATIVE_INFINITY;
      this.data.nodes.forEach(function (v) {
        x = Math.min(x, v.x - 100);
        X = Math.max(X, v.x + 100);
        y = Math.min(y, v.y - 100);
        Y = Math.max(Y, v.y + 100);
      });
      return {
        x: x,
        X: X,
        y: y,
        Y: Y
      };
    }
  }, {
    key: "zoomTo",
    value: function zoomTo(translateX, translateY, scale) {
      var duration = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 750;
      this.svg.transition().duration(duration).call(this.zoom.transform, d3.zoomIdentity.translate(translateX, translateY).scale(scale));
    }
  }, {
    key: "getZoom",
    value: function getZoom() {
      var _this$options$zoom3, _this$options$zoom4;
      return {
        min: ((_this$options$zoom3 = this.options.zoom) === null || _this$options$zoom3 === void 0 ? void 0 : _this$options$zoom3.min) || 0,
        max: ((_this$options$zoom4 = this.options.zoom) === null || _this$options$zoom4 === void 0 ? void 0 : _this$options$zoom4.max) || 0,
        zoomTo: this.zoomTo.bind(this),
        transform: this._zoomTransform,
        zoom: this.zoom
      };
    }
  }, {
    key: "fitGraph",
    value: function fitGraph() {
      var b = this.graphBounds();
      var w = b.X - b.x;
      var h = b.Y - b.y;
      var bbox = this.svg.node().getBoundingClientRect();
      var cw = bbox.width;
      var ch = bbox.height;
      var s = Math.min(cw / w, ch / h);
      if (s > 1) s = 1;
      var tx = -b.x * s + (cw / s - w) * s / 2;
      var ty = -b.y * s + (ch / s - h) * s / 2;
      this.zoomTo(tx, ty, s, 750);
      return [tx, ty, s]
    }

    /**
     * zoom and transform graph to makesure nodes are center and fit
     * @param {string[]} nodeIds node ids
     * @param {number} padding optional, padding space around, default is 20
     * @param {number} minZoom optional, if > 0, will be used as min zoom level when transform
     * @param {number} maxZoom optional, if > 0, will be used as max zoom level when transform
     * @returns
     */
  }, {
    key: "fitGraphByNodes",
    value: function fitGraphByNodes(nodeIds) {
      var padding = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 20;
      var minZoom = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
      var maxZoom = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;
      var nodes = this.drawController.nodeGroup.filter(function (v) {
        return nodeIds.includes(v.id);
      });
      var nodeEls = nodes.nodes();
      if (nodeEls.length === 0) {
        return;
      }
      var transform = this._zoomTransform;
      var minX = Infinity,
        minY = Infinity,
        maxX = -Infinity,
        maxY = -Infinity;
      nodeEls.forEach(function (n) {
        var box = n.getBoundingClientRect();
        minX = Math.min(minX, box.x);
        minY = Math.min(minY, box.y);
        maxX = Math.max(maxX, box.x + box.width);
        maxY = Math.max(maxY, box.y + box.height);
      });
      minX -= padding / 2;
      minY -= padding / 2;
      maxX += padding / 2;
      maxY += padding / 2;
      var width = maxX - minX,
        height = maxY - minY;
      var bbox = this.svg.node().getBoundingClientRect();
      var s = Math.min(bbox.width / (width / transform.k), bbox.height / (height / transform.k));
      if (minZoom) {
        s = Math.max(minZoom, s);
      }
      if (maxZoom) {
        s = Math.min(s, maxZoom);
      }
      var tx = (transform.x - (minX - bbox.x)) / transform.k * s + (bbox.width - width / transform.k * s) / 2;
      var ty = (transform.y - (minY - bbox.y)) / transform.k * s + (bbox.height - height / transform.k * s) / 2;
      this.zoomTo(tx, ty, s);
    }
  }, {
    key: "selectedNodes",
    get: function get() {
      return this._selectedNodes || [];
    },
    set: function set(ids) {
      this._selectedNodes = ids;
      this.event.emit(CONSTANTS.EVENT.CHANGE_SELECTED_NODES, ids);
    }
  }, {
    key: "selectedLinks",
    get: function get() {
      return this._selectedLinks || [];
    },
    set: function set(ids) {
      this._selectedLinks = ids;
      this.event.emit(CONSTANTS.EVENT.CHANGE_SELECTED_LINKS, ids);
    }
  }, {
    key: "getLinksConnection",
    value: function getLinksConnection$1() {
      return getLinksConnection(this.data);
    }

    /**
     * update graph data
     * @param {IGraphData} data
     * @param {(err: Error) => void} onError  when data not vaid, or has error then update graph layout
     * @returns {{ start: () => void, restart: (alpha?:number) => void }}
     */
  }, {
    key: "updateData",
    value: function updateData(data, onError) {
      var nonFunc = function nonFunc() {};
      var beforeUpdateData = this.options.beforeUpdateData;
      // incase there is nothing return from beforeUpdateData, data will be used
      var newData = (beforeUpdateData ? beforeUpdateData(data, getGraphNodeUnions(data)) : undefined) || data;
      var graphDataValidErrMsg = this.verifyGraphData(newData);
      if (graphDataValidErrMsg) {
        var invalidError = new Error(graphDataValidErrMsg);
        if (onError) {
          onError(invalidError);
        }
        this.event.emit(CONSTANTS.EVENT.GRAPH_ON_ERROR, invalidError);
        return {
          start: nonFunc,
          restart: nonFunc
        };
      }
      var prevData = this.getData();

      // update graph data
      this.data = deepCopy(newData);
      // link source & target will be overriden by d3 simulation,
      // restore back to string to aovid d3 missing new data
      this.data.links.map(function (v) {
        if (typeof v.source !== 'string') {
          v.source = v.source.id;
        }
        if (typeof v.target !== 'string') {
          v.target = v.target.id;
        }
      });
      // update layout simulation data
      try {
        this.layout.updateData();
      } catch (err) {
        // rollback data when err occurs
        this.data = prevData;
        if (onError) {
          onError(err);
        }
        this.event.emit(CONSTANTS.EVENT.GRAPH_ON_ERROR, err);
        return {
          start: nonFunc,
          restart: nonFunc
        };
      }
      // redraw graph from new data
      this.updateGraph();
      this.event.emit(CONSTANTS.EVENT.CHANGE_GRAPH_DATA, this.data);
      return {
        start: this.start.bind(this),
        restart: this.restart.bind(this)
      };
    }

    /** run base on changes */
  }, {
    key: "restart",
    value: function restart(alpha) {
      this.layout.restart(alpha);
    }

    /** create new simulation */
  }, {
    key: "start",
    value: function start() {
      this.layout.start();
    }

    /**
     * add new nodes / links
     * @param {IGraphData} data
     * @param {(err: Error) => void} onError
     * @returns {{ start: () => void, restart: (alpha?:number) => void }}
     */
  }, {
    key: "addData",
    value: function addData(data, onError) {
      return this.updateData({
        nodes: [].concat(_toConsumableArray(this.data.nodes), _toConsumableArray(data.nodes)),
        links: [].concat(_toConsumableArray(this.data.links), _toConsumableArray(data.links))
      }, onError);
    }

    /**
     * update node attribute data, update specific nodes in graph
     * @param {{[id:string]:Omit<Partial<IGraphNode>, 'id' | 'children'>}} nodeMap
     * @param {string[]} childFields deep search from this field, default is ['children]
     */
  }, {
    key: "setNodesAttributes",
    value: function setNodesAttributes(nodeMap) {
      var childFields = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : ['children'];
      this.data.nodes.forEach(function (n) {
        if (nodeMap[n.id]) {
          Object.assign(n, nodeMap[n.id], {
            id: n.id
          });
        }
        childFields === null || childFields === void 0 ? void 0 : childFields.forEach(function (k) {
          if (n[k] && Array.isArray(n[k])) {
            n[k].forEach(function (v) {
              if (nodeMap[v.id]) {
                Object.assign(v, nodeMap[v.id], {
                  id: v.id
                });
              }
            });
          }
        });
      });
      this.layout.updateData();
      this.updateGraph([UpdateGraphScope.nodeAttributes], Object.keys(nodeMap));
      this.event.emit(CONSTANTS.EVENT.CHANGE_GRAPH_DATA, this.data);
    }

    /**
     * update link attribute data, update specific links in graph
     * @param {{[id:string]:Omit<Partial<IGraphLink>, 'source' | 'target' | 'id' | 'children'>}} linkMap
     * @param {string[]} childFields deep search from this field, default is ['children]
     */
  }, {
    key: "setLinksAttributes",
    value: function setLinksAttributes$1(linkMap) {
      var childFields = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : ['children'];
      if (!linkMap || Object.keys(linkMap).length === 0) {
        return;
      }
      var copyLinkMap = _objectSpread({}, linkMap);
      var _utils$setLinksAttrib = setLinksAttributes(this.data.links, copyLinkMap, childFields),
        matchedIds = _utils$setLinksAttrib.matchedIds;
      if (Object.keys(copyLinkMap).length > 0) {
        this.event.emit(CONSTANTS.EVENT.SET_LINKS_ATTRIBUTES, {
          linkMap: copyLinkMap,
          childFields: childFields
        });
      }
      this.layout.updateData();
      this.updateGraph([UpdateGraphScope.linkAttributes], matchedIds);
      this.event.emit(CONSTANTS.EVENT.CHANGE_GRAPH_DATA, this.data);
      this.restart(0); // need one tick to calcaulate path
    }

    /**
     * set classname by batch, skip updateData and redraw, and update to dom directly
     * @param {string[]} ids link ids
     * @param {((d: IGraphLink) => string) | string} value
     */
  }, {
    key: "setLinksClassName",
    value: function setLinksClassName() {
      var ids;
      var value;
      for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        args[_key2] = arguments[_key2];
      }
      if (args.length === 1) {
        if (typeof args[0] === 'string' || typeof args[0] === 'function') {
          value = args[0];
        } else {
          return;
        }
      } else if (args.length === 2) {
        if (Array.isArray(args[0]) && args[0].length > 0 && (typeof args[1] === 'string' || typeof args[1] === 'function')) {
          ids = args[0];
          value = args[1];
        } else {
          return;
        }
      }
      updateClassName(this.getContainer().zoomContainer.selectAll('.graph__link-group'), ids, value);
    }

    /**
     * set classname by batch, skip updateData and redraw, and update to dom directly
     * @param {string[]} ids node ids
     * @param {((d: IGraphNode) => string) | string} value
     */
  }, {
    key: "setNodesClassName",
    value: function setNodesClassName() {
      var ids;
      var value;
      for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
        args[_key3] = arguments[_key3];
      }
      if (args.length === 1) {
        if (typeof args[0] === 'string' || typeof args[0] === 'function') {
          value = args[0];
        } else {
          return;
        }
      } else if (args.length === 2) {
        if (Array.isArray(args[0]) && args[0].length > 0 && (typeof args[1] === 'string' || typeof args[1] === 'function')) {
          ids = args[0];
          value = args[1];
        } else {
          return;
        }
      }
      updateClassName(this.getContainer().zoomContainer.selectAll('.graph__node-group'), ids, value);
    }

    /**
     * remove nodes and its related links
     * @param {string[]} ids
     */
  }, {
    key: "removeNodes",
    value: function removeNodes(ids) {
      this.event.emit(CONSTANTS.EVENT.BEFORE_REMOVE_NODES, ids);
      var newData = getGraphDataWhenNodesRemove(ids, this.data);
      this.updateData(newData).restart(0);
      return {
        data: this.getData(),
        unions: getGraphNodeUnions(this.data)
      };
    }

    /**
     * expand aggregated edge
     * @param {IGraphLink} d
     */
  }, {
    key: "expandAggregatedEdges",
    value: function expandAggregatedEdges$1(links) {
      if (!links || links.length === 0) {
        return;
      }
      var newData = expandAggregatedEdges(links, this.data);
      this.updateData(newData).restart(0);
    }

    /**
     * update graph configurations, exclude 'data' 'outerContainer'
     * @param {Omit<Partial<IGraphOptions>, 'data' | 'outerContainer'>} options
     */
  }, {
    key: "setOptions",
    value: function setOptions(options) {
      if (options.showSecondaryLabel !== this.options.showSecondaryLabel) {
        /** switch nodes label between primary and secondary */
        this.options.showSecondaryLabel = options.showSecondaryLabel;
        this.updateGraph([UpdateGraphScope.toggleLabel]);
      }
      this.options = _objectSpread(_objectSpread({}, this.options), options);
    }

    /**
     * return graph configure value, except 'data'
     * @param {keyof Omit<IGraphOptions, 'data'>} name
     * @returns
     */
  }, {
    key: "getOption",
    value: function getOption(name) {
      return this.options[name];
    }

    /**
     * get behavior instance by name
     * @param {string} name
     * @returns {IBehavior | undefined}
     */
  }, {
    key: "getBehavior",
    value: function getBehavior(name) {
      return this._behaviors.filter(function (b) {
        return b.name === name;
      })[0];
    }

    /**
     * add new behaviors
     * @param {IGraphOptionsBehavior[]} behaviorOptions
     */
  }, {
    key: "addBehaviors",
    value: function addBehaviors(behaviorOptions) {
      var _this4 = this;
      if (!behaviorOptions || behaviorOptions.length === 0) {
        return;
      }
      behaviorOptions.forEach(function (opt) {
        var BehaviorClass = behaviorController(opt);
        var behavior = new BehaviorClass(_this4, opt);
        behavior.init();
        behavior.name = typeof opt === 'string' ? opt : opt.type;
        _this4._behaviors.push(behavior);
      });
    }

    /**
     * remove behaviors by names, will call destroy() before remove
     * @param {string[]} behaviorNames
     */
  }, {
    key: "removeBehaviors",
    value: function removeBehaviors(behaviorNames) {
      if (!behaviorNames || behaviorNames.length === 0) {
        return;
      }
      this._behaviors = this._behaviors.filter(function (b) {
        if (behaviorNames.includes(b.name)) {
          if (b.destroy) {
            b.destroy();
          }
          return false;
        }
        return true;
      });
    }

    /**
     * add new plugins
     * @param {IPlugin[]} plugins
     */
  }, {
    key: "addPlugins",
    value: function addPlugins(plugins) {
      var _this5 = this;
      if (!plugins || plugins.length === 0) {
        return;
      }
      plugins.forEach(function (plugin) {
        plugin.init(_this5);
        _this5._plugins.push(plugin);
      });
    }

    /**
     * remove plugins by instance, will call destroy() before remove
     * @param {IPlugin[]} plugins
     */
  }, {
    key: "removePlugins",
    value: function removePlugins(plugins) {
      if (!plugins || plugins.length === 0) {
        return;
      }
      this._plugins = this._plugins.filter(function (p) {
        if (plugins.includes(p)) {
          if (p.destroy) {
            p.destroy();
          }
          return false;
        }
        return true;
      });
    }

    /**
     * return available layouts from registered layouts
     * each layout has selected layouts can be switched to
     * @returns {ILayout['layouts']} Object
     */
  }, {
    key: "layouts",
    get: function get() {
      return this.layout.layouts;
    }
  }]);
  return Graph;
}();

export { Graph as default };
