import _defineProperty from '@babel/runtime/helpers/defineProperty';
import React, { useRef, useMemo, useEffect } from 'react';
import CONSTANTS from '../constants.js';
import { deepCopy, getObjectValueByKeyChain, formatForDisplay } from '../../utils/utils.js';
import iaodConfig from '../../config.js';
import RCGraph from './index.js';
import classNames from 'classnames';
import style from './index.module.scss.js';

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
var GeneratorType = /*#__PURE__*/function (GeneratorType) {
  GeneratorType["Map"] = "map";
  GeneratorType["Method"] = "method";
  return GeneratorType;
}(GeneratorType || {});
var EVENT_TYPE = {
  CLICK: 'click',
  DBLCLICK: 'dblclick'
};
var EVENT_POSITION = {
  NODE: 'node',
  LINK: 'link'
};
var RCGraphChart = function RCGraphChart(props) {
  var _uiOptions$auto_fit_g, _uiOptions$is_drag_en;
  var graph = useRef();
  var containerStyle = useMemo(function () {
    var _props$chartContentSi;
    return {
      height: (_props$chartContentSi = props.chartContentSize) === null || _props$chartContentSi === void 0 ? void 0 : _props$chartContentSi.height
    };
  }, [props.chartContentSize]);
  useEffect(function () {
    if (graph.current && props.onInstance) {
      props.onInstance(graph.current);
    }
  }, [graph.current]);
  var rawData = useMemo(function () {
    return props.data ? deepCopy(props.data) : null;
  }, [props.data]);
  var uiOptions = useMemo(function () {
    return props.uiModel.options || {};
  }, [props.uiModel]);
  var generatorMethods = useMemo(function () {
    return _objectSpread(_objectSpread({}, iaodConfig.getConfig('customRender')), props.customRender);
  }, [props.customRender]);
  var graphData = useMemo(function () {
    var data = {
      nodes: [],
      links: []
    };
    var nodes_key = uiOptions.nodes_key,
      links_key = uiOptions.links_key,
      node_fields = uiOptions.node_fields,
      link_fields = uiOptions.link_fields;
    if (!nodes_key || !links_key || !rawData) {
      return data;
    }
    data.nodes = deepCopy(getObjectValueByKeyChain(rawData, nodes_key));
    data.links = deepCopy(getObjectValueByKeyChain(rawData, links_key));
    var setFieldValue = function setFieldValue(obj, field, value) {
      var ob = obj;
      var fields = field.split('.');
      fields.forEach(function (k, i) {
        if (!ob[k]) {
          var nxtK = fields[i + 1];
          if (nxtK && /^\d+$/.test(nxtK)) {
            ob[k] = [];
          } else {
            ob[k] = {};
          }
        }
        if (i === fields.length - 1) {
          ob[k] = value;
        } else {
          ob = ob[k];
        }
      });
    };
    var generateSubData = function generateSubData(fieldName, subFieldConfig) {
      if (!subFieldConfig || subFieldConfig.length === 0) {
        /** if not provide sub_fields configurations, push raw list into nodes/links directly */
        return data[fieldName] || [];
      }
      if (!data[fieldName]) {
        return [];
      }
      return data[fieldName].map(function (v) {
        subFieldConfig.forEach(function (f) {
          var _ref, _ref2, _f$generator;
          var targetValue = getObjectValueByKeyChain(v, f.key);
          if (f.format) {
            targetValue = formatForDisplay({
              value: targetValue,
              type: f.format
            });
          }
          if (f.generator) {
            switch (f.generator.type) {
              case GeneratorType.Map:
                var mapGenerator = f.generator;
                targetValue = (_ref = (_ref2 = mapGenerator.value && mapGenerator.value[targetValue]) !== null && _ref2 !== void 0 ? _ref2 : mapGenerator.default_value) !== null && _ref !== void 0 ? _ref : targetValue;
                break;
              case GeneratorType.Method:
                var method = generatorMethods[(_f$generator = f.generator) === null || _f$generator === void 0 ? void 0 : _f$generator.value];
                targetValue = method && method({
                  targetValue: targetValue,
                  columnData: v,
                  rawData: rawData
                }, f.generator.params);
                break;
            }
          }
          setFieldValue(v, f.target, targetValue);
        });
        /** push raw data that maybe used in vertical side */
        setFieldValue(v, 'rawData', v);
        return v;
      });
    };
    data.nodes = generateSubData('nodes', node_fields);
    data.links = generateSubData('links', link_fields);
    return data;
  }, [rawData, uiOptions]);
  var behaviors = useMemo(function () {
    var _uiOptions$zoom_bar, _uiOptions$highlight_;
    var bhs = [];
    if ((_uiOptions$zoom_bar = uiOptions.zoom_bar) !== null && _uiOptions$zoom_bar !== void 0 && _uiOptions$zoom_bar.enable) {
      bhs.push(_objectSpread({
        type: CONSTANTS.BEHAVIOR.ZOOMBAR
      }, uiOptions.zoom_bar.options || {}));
    }
    if ((_uiOptions$highlight_ = uiOptions.highlight_relations) !== null && _uiOptions$highlight_ !== void 0 && _uiOptions$highlight_.enable) {
      bhs.push(_objectSpread({
        type: CONSTANTS.BEHAVIOR.HIGHLIGHT_RELATIONS
      }, uiOptions.highlight_relations.options || {}));
    }
    return bhs;
  }, [uiOptions]);
  var layout = useMemo(function () {
    return uiOptions.layout || {
      type: 'force'
    };
  }, [uiOptions.layout]);
  var onEventHandler = function onEventHandler(data, evt, type, position) {
    if (props.eventHandler) {
      props.eventHandler({
        event_type: type,
        position: position,
        evt: evt,
        data: {
          rawData: data
        }
      });
    }
  };
  return /*#__PURE__*/React.createElement(RCGraph, {
    className: classNames(style.rcgraph__chart__container, props.className),
    style: containerStyle,
    data: graphData,
    graphRef: graph,
    effectWhenDataChange: "restart",
    behaviors: behaviors,
    autoFitGraph: (_uiOptions$auto_fit_g = uiOptions.auto_fit_graph) !== null && _uiOptions$auto_fit_g !== void 0 ? _uiOptions$auto_fit_g : true,
    showSecondaryLabel: uiOptions.show_secondary_label,
    isDragEnabled: (_uiOptions$is_drag_en = uiOptions.is_drag_enabled) !== null && _uiOptions$is_drag_en !== void 0 ? _uiOptions$is_drag_en : true,
    layout: layout,
    onClickNode: function onClickNode(data, evt) {
      return onEventHandler(data, evt, EVENT_TYPE.CLICK, EVENT_POSITION.NODE);
    },
    onClickLink: function onClickLink(data, evt) {
      return onEventHandler(data, evt, EVENT_TYPE.CLICK, EVENT_POSITION.LINK);
    },
    onDBLClickNode: function onDBLClickNode(data, evt) {
      return onEventHandler(data, evt, EVENT_TYPE.DBLCLICK, EVENT_POSITION.NODE);
    },
    onDBLClickLink: function onDBLClickLink(data, evt) {
      return onEventHandler(data, evt, EVENT_TYPE.DBLCLICK, EVENT_POSITION.LINK);
    }
  });
};

export { RCGraphChart as default };
