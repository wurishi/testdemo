import _defineProperty from '@babel/runtime/helpers/defineProperty';
import React, { useRef, useEffect } from 'react';
import classNames from 'classnames';
import style from './index.module.scss.js';
import Graph from '../index.js';
import CONSTANTS from '../constants.js';

var RCGraph = function RCGraph(props) {
  var graph = useRef();
  var containerEL = useRef(null);
  var propsRef = useRef(props);
  useEffect(function () {
    /** store props incase some of func are executed in a closure */
    propsRef.current = props;
  }, [props]);
  useEffect(function () {
    /** update data, this effect should locate before new Graph */
    if (graph.current) {
      var effectWhenDataChange = props.effectWhenDataChange || 'start';
      if (effectWhenDataChange === 'start') {
        graph.current.updateData(props.data).start();
        return;
      }
      graph.current.updateData(props.data).restart(0);
      if (props.effectWhenDataChange === 'restart.autofit') {
        graph.current.fitGraph();
      }
    }
  }, [props.data]);
  useEffect(function () {
    /** update options, this effect should locate before new Graph */
    if (!graph.current) {
      return;
    }
    var names = ['layout', 'autoFitGraph', 'zoom', 'showSecondaryLabel', 'getCustomShapePath', 'isDragEnabled', 'beforeUpdateData'];
    var options = {};
    names.forEach(function (v) {
      // @ts-ignore
      if (graph.current.getOption(v) !== props[v]) {
        options[v] = props[v];
      }
    });
    graph.current.setOptions(options);
  }, [props.layout, props.autoFitGraph, props.zoom, props.showSecondaryLabel, props.getCustomShapePath, props.isDragEnabled, props.beforeUpdateData]);
  useEffect(function () {
    if (containerEL.current) {
      var _props$autoFitGraph;
      /** register events */
      var registerEvent = function registerEvent(evtName, cbName) {
        if (propsRef.current[cbName]) {
          graph.current.event.on(evtName, function () {
            var _propsRef$current;
            (_propsRef$current = propsRef.current)[cbName].apply(_propsRef$current, arguments);
          });
        }
      };
      graph.current = new Graph({
        outerContainer: containerEL.current,
        data: props.data,
        layout: props.layout,
        autoFitGraph: (_props$autoFitGraph = props.autoFitGraph) !== null && _props$autoFitGraph !== void 0 ? _props$autoFitGraph : true,
        zoom: props.zoom,
        behaviors: props.behaviors,
        plugins: props.plugins,
        showSecondaryLabel: props.showSecondaryLabel,
        getCustomShapePath: props.getCustomShapePath,
        isDragEnabled: props.isDragEnabled,
        beforeUpdateData: props.beforeUpdateData
      });
      graph.current.render();
      registerEvent(CONSTANTS.EVENT.NODE_CLICK, 'onClickNode');
      registerEvent(CONSTANTS.EVENT.NODE_DBLCLICK, 'onDBLClickNode');
      registerEvent(CONSTANTS.EVENT.LINK_CLICK, 'onClickLink');
      registerEvent(CONSTANTS.EVENT.LINK_DBLCLICK, 'onLinkDBLClick');
      registerEvent(CONSTANTS.EVENT.DRAG_START, 'onDragStart');
      registerEvent(CONSTANTS.EVENT.DRAG, 'onDrag');
      registerEvent(CONSTANTS.EVENT.DRAG_END, 'onDragEnd');
      registerEvent(CONSTANTS.EVENT.LAYOUT_TICK_START, 'onLayoutTickStart');
      registerEvent(CONSTANTS.EVENT.LAYOUT_TICK_END, 'onLayoutTickEnd');
      registerEvent(CONSTANTS.EVENT.LAYOUT_CLICK, 'onClickLayout');
      registerEvent(CONSTANTS.EVENT.CHANGE_GRAPH_DATA, 'onChangeGraphData');
      registerEvent(CONSTANTS.EVENT.CHANGE_CONTAINER_SIZE, 'onChangeContainerSize');
      registerEvent(CONSTANTS.EVENT.GRAPH_ON_ERROR, 'onError');
    }
  }, []);
  useEffect(function () {
    if (props.graphRef) {
      props.graphRef.current = graph.current;
    }
  }, [props.graphRef]);
  useEffect(function () {
    if (graph.current) {
      graph.current.selectedNodes = props.selectedNodes || [];
    }
  }, [props.selectedNodes]);
  useEffect(function () {
    if (graph.current) {
      graph.current.selectedLinks = props.selectedLinks || [];
    }
  }, [props.selectedLinks]);
  return /*#__PURE__*/React.createElement("div", {
    className: classNames(style.rcgraph__container, _defineProperty({}, props.className, !!props.className)),
    style: props.style,
    ref: containerEL
  });
};

export { RCGraph as default };
