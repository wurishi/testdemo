import styleInject from 'style-inject';

var css_248z = ".ppiaod__rcgraph__container___0-15-4 svg * {\n  transition: none;\n}\n\n.ppiaod__rcgraph__chart__container___0-15-4 {\n  height: 100%;\n}\n.ppiaod__rcgraph__chart__container___0-15-4 > .graph__container {\n  min-height: unset;\n}";
var style = {"rcgraph__container":"ppiaod__rcgraph__container___0-15-4","rcgraph__chart__container":"ppiaod__rcgraph__chart__container___0-15-4"};
styleInject(css_248z);

export { style as default };
