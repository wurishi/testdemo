import _defineProperty from '@babel/runtime/helpers/defineProperty';
import CONSTANTS from '../constants.js';
import classNames from 'classnames';
import { isArray } from '../utils.js';

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function getNodeIcon(data) {
  // text
  var attr = {
    namespaceURI: 'http://www.w3.org/2000/svg',
    element: 'text',
    className: "graph__node__icon ".concat(data.className || ''),
    content: data.text
  };
  // image
  if (data.url && data.url.trim().length > 0) {
    attr.element = 'image';
    attr.content = null;
    attr.href = data.url;
  }
  return attr;
}
function generateGraphNodePath(d, getCustomShapePath) {
  var r = d.r || CONSTANTS.DEFAULT_NODE_RADIUS;
  if (d.shape === 'custom' && getCustomShapePath) {
    // draw custom shape path
    var customPath = getCustomShapePath(d, r);
    if (customPath) {
      return customPath;
    }
  } else if (d.shape === 'diamond') {
    // draw diamond
    return "M 0,0 m ".concat(r, " 0 l ").concat(-r, " ").concat(r, " l ").concat(-r, " ").concat(-r, " l ").concat(r, " ").concat(-r, " l ").concat(r, " ").concat(r);
  } else if (d.shape === 'hexagon') {
    var wh = Math.sqrt(3) * r / 2;
    return "M 0,0 m ".concat(r, " 0 l ").concat(-r / 2, " ").concat(wh, " l ").concat(-r, " 0 l ").concat(-r / 2, " ").concat(-wh, " l ").concat(r / 2, " ").concat(-wh, " l ").concat(r, " 0 z");
  }
  // draw circle by default
  return "M 0, 0 m ".concat(r, ", 0 a ").concat(-r, ", ").concat(r, " 0 1, 1 ").concat(-r * 2, ", 0 a ").concat(r, ", ").concat(-r, " 0 1, 1 ").concat(r * 2, ", 0");
}
function drawNodes(options) {
  var nodeGroupClassName = classNames('graph__node-group', _defineProperty({}, options.nodeGroupClassName, !!options.nodeGroupClassName));
  var nodeGroupSelectedClassName = classNames(CONSTANTS.CLASSNAME.NODEGROUP_SELECTED, _defineProperty({}, options.nodeGroupSelectedClassName, !!options.nodeGroupSelectedClassName));
  var nodeGroup = options.container.selectAll(".".concat(nodeGroupClassName.split(/\s+/).join('.'))).filter(function (_d, idx, list) {
    /** add filter to be sure all nodes are direct children of container, not include other descendants */
    return list[idx].parentNode === options.container.node();
  }).classed(nodeGroupSelectedClassName, function (d) {
    return (options.selectedNodes || []).includes(d.id);
  }).data(options.nodeData).join('g').attr('class', function (d) {
    return "".concat(nodeGroupClassName, " ").concat(d.className || '');
  }).classed(nodeGroupSelectedClassName, function (d) {
    return (options.selectedNodes || []).includes(d.id);
  });
  if (options.updateIds) {
    nodeGroup = nodeGroup.filter(function (d) {
      return options.updateIds.includes(d.id);
    });
  }
  // node
  nodeGroup.selectAll('.graph__node').data(function (d) {
    return [d];
  }).join('path').attr('class', 'graph__node').attr('d', function (d) {
    return generateGraphNodePath(d, options.getCustomShapePath);
  })
  // .attr('r', d => d.r || CONSTANTS.DEFAULT_NODE_RADIUS)
  .style('stroke-width', function (d) {
    return d.strokeWidth;
  }).style('fill', function (d) {
    return d.fill;
  }).style('stroke', function (d) {
    return d.stroke;
  });
  // node icons
  var iconPositions = ['top', 'middle', 'bottom', 'left', 'right'];
  iconPositions.forEach(function (key) {
    var cls = "graph__node__icon--".concat(key);
    nodeGroup.selectAll(".".concat(cls)).remove();
    nodeGroup.filter(function (d) {
      return d.icons && d.icons[key] && !!(d.icons[key].text || d.icons[key].url);
    }).insert(function (d) {
      return document.createElementNS(getNodeIcon(d.icons[key]).namespaceURI, getNodeIcon(d.icons[key]).element);
    }, 'g').attr('x', function (d) {
      var value = d.icons[key].url ? -6 : 0;
      var delta = (d.r || CONSTANTS.DEFAULT_NODE_RADIUS) - 2;
      if (key === 'left') {
        value -= delta;
      } else if (key === 'right') {
        value += delta;
      }
      return value;
    }).attr('y', function (d) {
      var value = d.icons[key].url ? -21 : -10;
      if (['middle', 'left', 'right'].includes(key)) {
        value += 15;
      } else if (key === 'bottom') {
        value += 30;
      }
      return value;
    }).attr('class', function (d) {
      return "".concat(getNodeIcon(d.icons[key]).className, " ").concat(cls);
    }).attr('xlink:href', function (d) {
      return getNodeIcon(d.icons[key]).href;
    }).style('fill', function (d) {
      return d.icons[key].color;
    }).style('text-anchor', function () {
      if (key === 'left') {
        return 'start';
      }
      if (key === 'right') {
        return 'end';
      }
      return 'middle';
    }).text(function (d) {
      var txt = getNodeIcon(d.icons[key]).content;
      if (!txt || txt.split('\n').length > 1) {
        return '';
      }
      return txt;
    }).selectAll('tspan').data(function (d) {
      var txt = getNodeIcon(d.icons[key]).content;
      if (txt && txt.split('\n').length > 1) {
        return txt.split('\n');
      }
      return [];
    }).join('tspan').attr('x', 0).attr('y', function (_d, i, list) {
      // @ts-ignore
      var py = this.parentNode.getAttribute('y');
      return i * 10 + (py ? +py : 0) - (list.length - 1) * 10 / 2;
    }).text(function (d) {
      return d;
    });
  });
  // label
  var labelLevels = ['primary', 'secondary', 'tertiary'];
  labelLevels.forEach(function (key) {
    // label wrapper
    var cls = "graph__node__label-group--".concat(key);
    var labelGroup = nodeGroup.selectAll(".".concat(cls)).data(function (d) {
      var _d$labels;
      return (_d$labels = d.labels) !== null && _d$labels !== void 0 && _d$labels[key] ? [d] : [];
    }).join('g').attr('labelLevel', key).attr('class', function (d) {
      var _d$labels2;
      var clsName = "graph__node__label-group ".concat(cls, " ").concat(((_d$labels2 = d.labels) === null || _d$labels2 === void 0 ? void 0 : _d$labels2.className) || '');
      if (key === 'primary' && options.showSecondaryLabel || key === 'secondary' && !options.showSecondaryLabel) {
        clsName = "".concat(clsName, " ").concat(CONSTANTS.CLASSNAME.HIDDEN);
      }
      return clsName;
    });
    labelGroup.nodes().forEach(function (n) {
      n.innerHTML = '';
    });

    // label text
    labelGroup.filter(function (d) {
      return d.labels && d.labels[key];
    }).append('text').attr('x', 0).attr('y', function (d) {
      var yNum = key === 'tertiary' ? 36 : 20;
      return (d.r || CONSTANTS.DEFAULT_NODE_RADIUS) + yNum;
    }).attr('class', "graph__node__label graph__node__label--".concat(key)).text(function (d) {
      var _d$labels3;
      return (_d$labels3 = d.labels) === null || _d$labels3 === void 0 ? void 0 : _d$labels3[key];
    });

    // label background if highlighted
    // has to be insert after text is created as the width of the text is needed
    labelGroup.filter(function (d) {
      var _d$labels4;
      return ((_d$labels4 = d.labels) === null || _d$labels4 === void 0 ? void 0 : _d$labels4.ishighlighted) && key !== 'tertiary';
    }).insert('rect', ':first-child').attr('x', function () {
      var parentNode = this.parentNode;
      return -(parentNode.getBBox().width + 12) / 2;
    }).attr('y', function (d) {
      return (d.r || CONSTANTS.DEFAULT_NODE_RADIUS) + 5;
    }).attr('rx', 5).attr('ry', 5).attr('height', 20).attr('width', function () {
      var parentNode = this.parentNode;
      return parentNode.getBBox().width + 12;
    });
  });
  // badges
  nodeGroup.selectAll('.graph__node__badge').remove();
  var badges = nodeGroup.selectAll('.graph__node__badge').data(function (d) {
    return d.badges && d.badges.map(function (v) {
      return _objectSpread(_objectSpread({}, v), {}, {
        nodeR: d.r || CONSTANTS.DEFAULT_NODE_RADIUS
      });
    }) || [];
  }).join('g').attr('class', function (d) {
    return "graph__node__badge graph__node__badge-".concat(d.position || 'topRight', " ").concat(d.className || '');
  }).attr('transform', function (d, _, el) {
    if (d.position === 'mask') {
      var maskPadding = d.maskPadding || 0;
      return "translate(-".concat(d.nodeR - maskPadding, ", -").concat(d.nodeR - maskPadding, ")");
    }
    var shape = el[0].parentNode.querySelector('.graph__node');
    if (!shape) {
      return '';
    }
    var cLength = shape.getTotalLength();
    if (!cLength) {
      return '';
    }
    var cPoint = shape.getPointAtLength(d.position === 'bottomRight' ? cLength * 1 / 8 : cLength * 7 / 8);
    return "translate(".concat(cPoint.x - 6, ", ").concat(cPoint.y, ")");
  });
  var getBadgeMaskR = function getBadgeMaskR(d) {
    var maskPadding = d.maskPadding || 0;
    return d.nodeR - maskPadding;
  };
  var badgeDefaultWidth = 34,
    badgeDefaultHeight = 18,
    badgeDefaultTxtPadding = 5;
  badges.selectAll('rect').data(function (d) {
    return d.text ? [d] : [];
  }).join('rect').attr('fill', function (d) {
    return d.background || '#c9effe';
  }).attr('stroke', function (d) {
    return d.stroke;
  }).attr('strokeWidth', function (d) {
    return d.strokeWidth;
  }).attr('rx', function (d) {
    return d.position === 'mask' ? getBadgeMaskR(d) : (d.height || badgeDefaultHeight) / 2;
  }).attr('ry', function (d) {
    return d.position === 'mask' ? getBadgeMaskR(d) : (d.height || badgeDefaultHeight) / 2;
  }).attr('height', function (d) {
    return d.position === 'mask' ? getBadgeMaskR(d) * 2 : d.height || badgeDefaultHeight;
  }).attr('y', function (d) {
    return d.position === 'mask' ? 0 : -7;
  });
  badges.selectAll('text').data(function (d) {
    return d.text ? [d] : [];
  }).join('text').text(function (d) {
    return d.text;
  }).style('font-size', function (d) {
    return d.fontSize;
  }).attr('fill', function (d) {
    return d.color;
  }).attr('x', function (d) {
    if (d.position === 'mask') {
      return getBadgeMaskR(d);
    }
    if (d.width) {
      return d.width / 2;
    }
    return badgeDefaultTxtPadding;
  }).attr('y', function (d) {
    return d.position === 'mask' ? getBadgeMaskR(d) : (d.height || badgeDefaultHeight) / 2 - 6;
  }).attr('dominant-baseline', 'middle').attr('text-anchor', 'middle');
  badges.selectAll('rect').attr('width', function (d, _i, el) {
    var _el$;
    if (d.position === 'mask') {
      return getBadgeMaskR(d) * 2;
    }
    if (d.width) {
      return d.width;
    }
    var txt = (_el$ = el[0]) === null || _el$ === void 0 || (_el$ = _el$.parentElement) === null || _el$ === void 0 ? void 0 : _el$.querySelector('text');
    if (txt) {
      var w = Math.max(d.height || 18, txt.getBBox().width + badgeDefaultTxtPadding * 2);
      txt.setAttribute('x', String(w / 2));
      return w;
    }
    return badgeDefaultWidth;
  });
  badges.selectAll('image').data(function (d) {
    return d.image ? [d] : [];
  }).join('image').attr('href', function (d) {
    return d.image;
  }).attr('width', function (d) {
    return d.position === 'mask' ? getBadgeMaskR(d) * 2 : 17.75;
  }).attr('height', function (d) {
    return d.position === 'mask' ? getBadgeMaskR(d) * 2 : 17.75;
  }).attr('y', function (d) {
    return d.position === 'mask' ? 0 : -8;
  });
  return nodeGroup;
}
function bindStrokeWidth(d) {
  var strokeWidth;
  var normal = CONSTANTS.DEFAULT.STROKE_WIDTH;
  var limit = CONSTANTS.LIMIT.STROKE_WIDTH;
  if (d.strokeWidth) {
    // use provided stroke width which can customize
    strokeWidth = d.strokeWidth;
  } else {
    // if not, the calculation is based on the number of children or default
    strokeWidth = isArray(d.children) && d.children.length ? Math.log10(d.children.length) + normal : normal;
  }

  // set the upper limit of stroke width
  return strokeWidth > limit ? limit : strokeWidth;
}
function getMarkerEndID(stroke, container) {
  if (!stroke || !container) {
    return 'end-arrow';
  }
  var markerID = "marker-arrow-".concat(stroke.replace(/[^\d|^\w]/g, '_'));
  if (container.select(markerID).empty()) {
    container.append('svg:defs').append('svg:marker').attr('id', markerID).attr('viewBox', '0 -5 10 10').attr('refX', 6).attr('markerWidth', 3).attr('markerHeight', 3).attr('orient', 'auto').append('svg:path').attr('d', 'M0,-5L10,0L0,5').attr('fill', stroke);
  }
  return markerID;
}
function drawLinks(options) {
  var selectedLinks = options.selectedLinks || [];
  var linkGroupClassName = classNames('graph__link-group', _defineProperty({}, options.linkGroupClassName, !!options.linkGroupClassName));
  var linkGroupSelectedClassName = classNames(CONSTANTS.CLASSNAME.LINKGROUP_SELECTED, _defineProperty({}, options.linkGroupSelectedClassName, !!options.linkGroupSelectedClassName));
  var linkGroup = options.container.selectAll(".".concat(linkGroupClassName.split(/\s+/).join('.'))).classed(linkGroupSelectedClassName, function (d) {
    return selectedLinks.includes(d.id);
  }).data(options.linkData).join('g').attr('id', function (d) {
    return "link_".concat(d.id);
  }).attr('class', function (d) {
    return "".concat(linkGroupClassName, " ").concat(d.className || '');
  }).classed(linkGroupSelectedClassName, function (d) {
    return selectedLinks.includes(d.id);
  });
  if (options.updateIds) {
    linkGroup = linkGroup.filter(function (v) {
      return options.updateIds.includes(v.id);
    });
  }
  // links
  var links = linkGroup.selectAll('.graph__link--path').data(function (d) {
    return [d];
  }).join('path').attr('class', 'graph__link--path').style('stroke', function (d) {
    return d.stroke;
  }).style('stroke-width', function (d) {
    return bindStrokeWidth(d);
  }).style('marker-end', function (d) {
    return d.arrow ? "url(#".concat(getMarkerEndID(d.stroke, options.container), ")") : '';
  });
  // path displays when mouse hoverover on it
  var linksOverlay = linkGroup.selectAll('.graph__link--path--overlay').data(function (d) {
    return [d];
  }).join('path').attr('class', 'graph__link--path--overlay').style('stroke', function (d) {
    return d.stroke;
  }).style('stroke-width', function (d) {
    return bindStrokeWidth(d) + 15;
  });
  // label
  linkGroup.selectAll('.graph__link--label').remove();
  var label = linkGroup.selectAll('.graph__link--label').data(function (d) {
    return d.label ? [d] : [];
  }).join('g').attr('class', function (d) {
    var _d$label;
    return "graph__link--label ".concat(((_d$label = d.label) === null || _d$label === void 0 ? void 0 : _d$label.className) || '');
  });
  label.selectAll('rect').data(function (d) {
    var _d$label2;
    return ((_d$label2 = d.label) === null || _d$label2 === void 0 ? void 0 : _d$label2.type) !== 'textpath' ? [d] : [];
  }).join('rect').attr('fill', '#fff');
  label.selectAll('path').data(function (d) {
    var _d$label3;
    return ((_d$label3 = d.label) === null || _d$label3 === void 0 ? void 0 : _d$label3.type) === 'textpath' ? [d] : [];
  }).join('path').attr('id', function (d) {
    return d.id;
  }).style('opacity', 0);
  label.selectAll('text').data(function (d) {
    return [d];
  }).join('text').attr('text-anchor', 'middle').attr('fill', function (d) {
    var _d$label4;
    return (_d$label4 = d.label) === null || _d$label4 === void 0 ? void 0 : _d$label4.fill;
  }).text(function (d) {
    var _d$label5, _d$label6;
    return ((_d$label5 = d.label) === null || _d$label5 === void 0 ? void 0 : _d$label5.type) === 'textpath' ? '' : (_d$label6 = d.label) === null || _d$label6 === void 0 ? void 0 : _d$label6.text;
  }).attr('dy', function (d) {
    var _d$label7;
    return ((_d$label7 = d.label) === null || _d$label7 === void 0 ? void 0 : _d$label7.type) === 'textpath' ? -7 : 0;
  }).append('textPath').attr('xlink:href', function (d) {
    return "#".concat(d.id);
  }).attr('startOffset', '50%').text(function (d) {
    var _d$label8, _d$label9;
    return ((_d$label8 = d.label) === null || _d$label8 === void 0 ? void 0 : _d$label8.type) === 'textpath' ? (_d$label9 = d.label) === null || _d$label9 === void 0 ? void 0 : _d$label9.text : '';
  });
  label.selectAll('rect').attr('width', function (d) {
    if (!d.label || d.label.type === 'textpath') {
      return 0;
    }
    //@ts-ignore
    var parentNode = this.parentNode.querySelector('text');
    return parentNode.getBBox().width;
  }).attr('height', function (d) {
    if (!d.label || d.label.type === 'textpath') {
      return 0;
    }
    //@ts-ignore
    var parentNode = this.parentNode.querySelector('text');
    return parentNode.getBBox().height;
  }).attr('transform', function (d) {
    if (!d.label || d.label.type === 'textpath') {
      return '';
    }
    //@ts-ignore
    var parentNode = this.parentNode.querySelector('text'),
      _parentNode$getBBox = parentNode.getBBox(),
      x = _parentNode$getBBox.x,
      y = _parentNode$getBBox.y;
    return "translate(".concat(x, ",").concat(y, ")");
  });
  return {
    linkGroup: linkGroup,
    links: links,
    linksOverlay: linksOverlay
  };
}
function countRelInOut(linksConnection, id, id1) {
  var _linksConnection$id, _linksConnection$id2;
  var len = (((_linksConnection$id = linksConnection[id]) === null || _linksConnection$id === void 0 ? void 0 : _linksConnection$id.length) || 0) + (((_linksConnection$id2 = linksConnection[id1]) === null || _linksConnection$id2 === void 0 ? void 0 : _linksConnection$id2.length) || 0);
  return len;
}
function calculateRelPos(linksConnection, d, id) {
  return linksConnection[id] ? linksConnection[id].indexOf(d.id) : -1;
}
function countRel(linksConnection, id) {
  var _linksConnection$id3;
  var len = ((_linksConnection$id3 = linksConnection[id]) === null || _linksConnection$id3 === void 0 ? void 0 : _linksConnection$id3.length) || 0;
  return len;
}
function angleRadiants(pos, length) {
  var sourceAngle = 90 - 90 / length * pos;
  var targetAngle = 180 - (90 - 90 / length * pos);
  return {
    source: sourceAngle * (Math.PI / 180),
    target: targetAngle * (Math.PI / 180)
  };
}
function calculateDR(dx, dy, pos, length) {
  pos = length - pos;
  var dr = Math.sqrt(dx * dx + dy * dy);
  dr = dr / (1 + 1 / length * (pos - 1));
  return dr;
}

/**
 * calculate link path
 * @param {IGraphLink} d
 * @param {ILinksConnection} linksConnection
 * @param {boolean} reverse if true will return reversed path, usecase is like to avoid the text along path upside down
 * @returns {string} svg link path
 */
function calculateLinkPath(d, linksConnection) {
  var reverse = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
  if (typeof d.target === 'string' || typeof d.source === 'string') {
    return '';
  }
  var padd = 5;
  var target = d.target,
    source = d.source;
  var radiusSource = source.r || CONSTANTS.DEFAULT_NODE_RADIUS;
  var radiusTarget = target.r || CONSTANTS.DEFAULT_NODE_RADIUS;
  var deltaX = target.x - source.x;
  var deltaY = target.y - source.y;
  var dist = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
  var rightArrow = !!d.arrow;
  var normX = deltaX / (dist !== 0 ? dist : 1);
  var normY = deltaY / (dist !== 0 ? dist : 1);
  var sourcePadding = radiusSource;
  var targetPadding = rightArrow ? radiusTarget + padd : radiusTarget;
  var sourceX = source.x + sourcePadding * normX;
  var sourceY = source.y + sourcePadding * normY;
  var targetX = target.x - targetPadding * normX;
  var targetY = target.y - targetPadding * normY;
  var v1 = source;
  var v2 = target;
  var id = "".concat(v1.id, "_").concat(v2.id);
  var id1 = "".concat(v2.id, "_").concat(v1.id);
  var rel = countRelInOut(linksConnection, id, id1);
  var realPos = calculateRelPos(linksConnection, d, id);
  var showReversePath = reverse;
  if (id === id1) {
    // draw self link
    var length1 = radiusSource;
    var length2 = rightArrow ? radiusSource + padd : radiusSource;
    sourceX = source.x - Math.sqrt(length1 * length1 / 2);
    sourceY = source.y - Math.sqrt(length1 * length1 / 2);
    targetX = source.x + Math.sqrt(length2 * length2 / 2);
    targetY = source.y - Math.sqrt(length2 * length2 / 2);
    var loopDelta = radiusSource * 3 * (1 + realPos * 0.5);
    return "M ".concat(sourceX, " ").concat(sourceY, " C ").concat(sourceX - loopDelta, " ").concat(sourceY - loopDelta, ", ").concat(targetX + loopDelta, " ").concat(targetY - loopDelta, ", ").concat(targetX, " ").concat(targetY);
  }
  if (rel === 1) {
    if (showReversePath) {
      return "M ".concat(targetX, " ").concat(targetY, " L ").concat(sourceX, " ").concat(sourceY);
    }
    return 'M' + sourceX + ',' + sourceY + ' L' + targetX + ',' + targetY;
  }
  if (realPos === 0) {
    var rate = 5; // TODO currently can see extra space between circle and path, set to 0 seems can fixed this, but need further investigate before change
    var absX = deltaY > 0 ? 1 : -1;
    var absY = deltaX > 0 ? -1 : 1;
    var sourcePX = rate * absX;
    var sourcePy = rate * absY;
    var targetPX = rate * absX;
    var targetPY = rate * absY;
    if (showReversePath) {
      return "M ".concat(targetX + targetPX, " ").concat(targetY + targetPY, " L ").concat(sourceX + sourcePX, " ").concat(sourceY + sourcePy);
    }
    return 'M' + (sourceX + sourcePX) + ',' + (sourceY + sourcePy) + ' L' + (targetX + targetPX) + ',' + (targetY + targetPY);
  }
  var pos = realPos + 1;
  var m = deltaX === 0 ? 0 : deltaY / deltaX;
  var val = Math.atan(m) * 180 / Math.PI;
  var trans = val * (Math.PI / 180) * -1;
  var edgesLength = countRel(linksConnection, id);
  var radiansConfig = angleRadiants(pos, edgesLength);
  var angleSource;
  var angleTarget;
  var signSourceX;
  var signSourceY;
  var signTargetX;
  var signTargetY;
  if (deltaX < 0) {
    signSourceX = 1;
    signSourceY = 1;
    signTargetX = 1;
    signTargetY = 1;
    angleSource = radiansConfig.target - trans - 0.5;
    angleTarget = radiansConfig.source - trans + 0.5;
  } else {
    signSourceX = 1;
    signSourceY = -1;
    signTargetX = 1;
    signTargetY = -1;
    angleSource = radiansConfig.source + trans + 0.5;
    angleTarget = radiansConfig.target + trans - 0.5;
  }
  sourceX = source.x + signSourceX * (sourcePadding * Math.cos(angleSource));
  sourceY = source.y + signSourceY * (sourcePadding * Math.sin(angleSource));
  targetX = target.x + signTargetX * (targetPadding * Math.cos(angleTarget));
  targetY = target.y + signTargetY * (targetPadding * Math.sin(angleTarget));
  var dr = calculateDR(targetX - sourceX, targetY - sourceY, pos, edgesLength);
  if (showReversePath) {
    return "M ".concat(targetX, " ").concat(targetY, " A ").concat(dr, " ").concat(dr, " 0 0 0 ").concat(sourceX, " ").concat(sourceY);
  }
  return 'M' + sourceX + ',' + sourceY + 'A' + dr + ',' + dr + ' 0 0,1 ' + targetX + ',' + targetY;
}
function updateLinkLabelPosition(linkGroup) {
  linkGroup.selectAll('.graph__link--label').attr('transform', function (d, _i, groups) {
    if (d.label && d.label.type !== 'textpath') {
      var linkPath = groups[0].parentNode.querySelector('.graph__link--path'),
        pathLength = linkPath.getTotalLength();
      if (!pathLength) {
        return '';
      }
      var pathCenterPoint = linkPath.getPointAtLength(pathLength / 2);
      return "translate(".concat(pathCenterPoint.x, ", ").concat(pathCenterPoint.y, ")");
    }
    return '';
  });
}
function updateClassName(selection, ids,
// if undefined, will set to all selection items
value) {
  var group = selection;
  if (ids) {
    group = group.filter(function (d) {
      return ids.includes(d.id);
    });
  }
  group.attr('class', function (d) {
    var curClassList = d.className ? d.className.trim().split(/\s+/) : [];
    var nxtClassList = Array.from(this.classList).filter(function (v) {
      return !curClassList.includes(v);
    });
    d.className = typeof value === 'function' ? value(d) : value;
    if (d.className) {
      nxtClassList.push(d.className);
    }
    return nxtClassList.join(' ');
  });
}

export { calculateLinkPath, drawLinks, drawNodes, updateClassName, updateLinkLabelPosition };
