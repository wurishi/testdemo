import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _inherits from '@babel/runtime/helpers/inherits';
import _possibleConstructorReturn from '@babel/runtime/helpers/possibleConstructorReturn';
import _getPrototypeOf from '@babel/runtime/helpers/getPrototypeOf';
import BaseLayout from './baseLayout.js';

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var NetworkLayout = /*#__PURE__*/function (_BaseLayout) {
  _inherits(NetworkLayout, _BaseLayout);
  var _super = _createSuper(NetworkLayout);
  // private graph: IGraph

  function NetworkLayout(graph) {
    _classCallCheck(this, NetworkLayout);
    return _super.call(this, graph);
  }
  _createClass(NetworkLayout, [{
    key: "start",
    value: function start() {}
  }, {
    key: "restart",
    value: function restart() {}
  }, {
    key: "stop",
    value: function stop() {}

    /**
     * return available layouts from registered layouts
     * only selected layouts can be switched each other
     * @returns {Layout}
     */
  }, {
    key: "layouts",
    get: function get() {
      return {};
    }
  }], [{
    key: "switch",
    value: function _switch() {}
  }]);
  return NetworkLayout;
}(BaseLayout);

export { NetworkLayout as default };
