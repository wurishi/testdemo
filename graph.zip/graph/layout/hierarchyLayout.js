import _toConsumableArray from '@babel/runtime/helpers/toConsumableArray';
import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _inherits from '@babel/runtime/helpers/inherits';
import _possibleConstructorReturn from '@babel/runtime/helpers/possibleConstructorReturn';
import _getPrototypeOf from '@babel/runtime/helpers/getPrototypeOf';
import * as d3 from 'd3v7';
import ForceLayout from './forceLayout.js';
import { registeredLayouts } from './index.js';
import CONSTANTS from '../constants.js';

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var HierarchyLayout = /*#__PURE__*/function (_ForceLayout) {
  _inherits(HierarchyLayout, _ForceLayout);
  var _super = _createSuper(HierarchyLayout);
  function HierarchyLayout(graph, layoutOptions) {
    var _this;
    _classCallCheck(this, HierarchyLayout);
    _this = _super.call(this, graph, layoutOptions);
    // update nodes positions before render
    _this.graph.event.on(CONSTANTS.EVENT.GRAPH_ON_INSTANCE, function () {
      var newData = setTreeNodePosition(graph.getContainer().svg, graph.getData());
      graph.updateData(newData);
    });
    return _this;
  }

  /**
   * switch to hierarchy layout
   * @param {IGraph} graph
   * @param {IGraphData} data
   */
  _createClass(HierarchyLayout, [{
    key: "layouts",
    get:
    /**
     * return available layouts from registered layouts
     * only selected layouts can be switched each other
     * @returns {ILayout['layouts']}
     */
    function get() {
      var _registeredLayouts = registeredLayouts(),
        _force = _registeredLayouts.force,
        _hierarchy = _registeredLayouts.hierarchy;
      var graph = this.graph;
      return {
        force: function force(data) {
          _force["switch"](graph, data);
        },
        hierarchy: function hierarchy(data) {
          _hierarchy["switch"](graph, data);
        }
      };
    }
  }], [{
    key: "switch",
    value: function _switch(graph, data) {
      var nodeWithPos = [];
      var nodeWithoutPos = [];
      // if user pass data in, use user data
      if (data) {
        data.nodes.forEach(function (node) {
          if (node.fx || node.fy || node.fx === 0 || node.fy === 0) {
            nodeWithPos.push(node);
          } else {
            nodeWithoutPos.push(node);
          }
        });
        // send nodeWithoutPos to setTreeNodePosition to cal the position
        data.nodes = [].concat(_toConsumableArray(setTreeNodePosition(graph.getContainer().svg, {
          nodes: nodeWithoutPos
        }).nodes), nodeWithPos);
        // if no data pass in, use the graph data and ignore existing x y of nodes
      } else {
        data = setTreeNodePosition(graph.getContainer().svg, graph.getData());
      }
      graph.updateData(data).restart(0);
    }
  }]);
  return HierarchyLayout;
}(ForceLayout);
/**
 *  set fixed position of tree nodes
 *  level and orderInLevel are must have
 * @param {d3.Selection} svg
 * @param {IGraphData} data
 */
function setTreeNodePosition(svg, data) {
  var bound = svg.node().getBoundingClientRect();
  if (data.nodes.length > 0) {
    var getMaxObjectFromArray = function getMaxObjectFromArray(prev, current, key) {
      var prevLevel = prev[key];
      var currentLevel = current[key];
      return prevLevel > currentLevel ? prev : current;
    };

    // get the max level
    var maxYNodes = data.nodes.reduce(function (prev, current) {
      current.level = parseInt(current.level, 10) || 0;
      current.orderInLevel = parseInt(current.orderInLevel, 10) || 0;
      prev.level = parseInt(prev.level, 10) || 0;
      prev.orderInLevel = parseInt(prev.orderInLevel, 10) || 0;
      return getMaxObjectFromArray(prev, current, 'level');
    });

    // get domain array
    var yDomain = Array.from(Array(maxYNodes.level + 1).keys());

    /**
     * get the max orderInLevel
     * const maxXNodes = newData.nodes.reduce((prev, current) =>
     *  getMaxObjectFromArray(prev, current, 'orderInLevel'),
     * )
     * const xDomain = Array.from(
     *   Array(maxXNodes.orderInLevel + 1).keys(),
     * )
     **/

    var yScale = d3.scaleLinear().domain([Math.min.apply(Math, yDomain), Math.max.apply(Math, yDomain)]).range([0, bound.height]);
    var xScale = d3.scaleLinear().domain([0, 10]).range([0, bound.width]);
    data.nodes.forEach(function (node) {
      node.fy = yScale(node.level);
      node.fx = xScale(node.orderInLevel);
    });
  }
  return data;
}

export { HierarchyLayout as default };
