import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _defineProperty from '@babel/runtime/helpers/defineProperty';

var BaseLayout = /*#__PURE__*/function () {
  function BaseLayout(graph) {
    _classCallCheck(this, BaseLayout);
    _defineProperty(this, "graph", void 0);
    this.graph = graph;
  }
  _createClass(BaseLayout, [{
    key: "start",
    value: function start() {}
  }, {
    key: "updateData",
    value: function updateData() {}
  }, {
    key: "restart",
    value: function restart() {}
  }, {
    key: "stop",
    value: function stop() {}
  }, {
    key: "layouts",
    get: function get() {
      return {};
    }
  }]);
  return BaseLayout;
}();

export { BaseLayout as default };
