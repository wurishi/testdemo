import _defineProperty from '@babel/runtime/helpers/defineProperty';
import _createClass from '@babel/runtime/helpers/createClass';
import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _inherits from '@babel/runtime/helpers/inherits';
import _possibleConstructorReturn from '@babel/runtime/helpers/possibleConstructorReturn';
import _getPrototypeOf from '@babel/runtime/helpers/getPrototypeOf';
import BaseLayout from './baseLayout.js';
import ForceLayout from './forceLayout.js';
import NetworkLayout from './networkLayout.js';
import HierarchyLayout from './hierarchyLayout.js';
import CONSTANTS from '../constants.js';

var _layoutMap;
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var DefaultLayout = /*#__PURE__*/function (_BaseLayout) {
  _inherits(DefaultLayout, _BaseLayout);
  var _super = _createSuper(DefaultLayout);
  function DefaultLayout() {
    _classCallCheck(this, DefaultLayout);
    return _super.apply(this, arguments);
  }
  return _createClass(DefaultLayout);
}(BaseLayout);
var layoutMap = (_layoutMap = {}, _defineProperty(_layoutMap, CONSTANTS.LAYOUT.FORCE, ForceLayout), _defineProperty(_layoutMap, CONSTANTS.LAYOUT.NETWORK, NetworkLayout), _defineProperty(_layoutMap, CONSTANTS.LAYOUT.HIERARCHY, HierarchyLayout), _layoutMap);

/**
 * register customized layout
 * @param {String}, name, name of the layout
 */
function registerLayout(name, layoutClass) {
  if (layoutMap[name]) {
    throw new Error("[registerLayout] layout '".concat(name, "' already exists."));
  }
  layoutMap[name] = layoutClass;
}

/**
 * init a layout instance
 * @param {IGraph}, graph
 * @param {IGraphOptionsLayout}, layoutOptions
 * @returns layout instance
 */
function layoutController(graph) {
  var layoutOptions = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {
    type: CONSTANTS.LAYOUT.FORCE
  };
  var name = layoutOptions['type'];
  var Layout = layoutMap[name] || DefaultLayout;
  return new Layout(graph, layoutOptions);
}
function registeredLayouts() {
  return layoutMap;
}

export { layoutController as default, registerLayout, registeredLayouts };
