import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _defineProperty from '@babel/runtime/helpers/defineProperty';
import { UpdateGraphScope } from '../types.js';
import CONSTANTS from '../constants.js';
import { clickcancel, getData } from '../utils.js';
import { drawNodes, calculateLinkPath, drawLinks, updateLinkLabelPosition } from './drawUtils.js';

var DrawGraph = /*#__PURE__*/function () {
  function DrawGraph(graph, zoomContainer, dragEvent) {
    _classCallCheck(this, DrawGraph);
    _defineProperty(this, "graph", void 0);
    _defineProperty(this, "zoomContainer", void 0);
    _defineProperty(this, "dragEvent", void 0);
    _defineProperty(this, "nodeGroup", void 0);
    _defineProperty(this, "linkGroup", void 0);
    _defineProperty(this, "linksConnection", void 0);
    _defineProperty(this, "isOnTick", void 0);
    _defineProperty(this, "links", void 0);
    _defineProperty(this, "linksOverlay", void 0);
    this.graph = graph;
    this.zoomContainer = zoomContainer;
    this.dragEvent = dragEvent;
    this.linksConnection = {};
    // arrow defs
    this.zoomContainer.append('svg:defs').append('svg:marker').attr('id', 'end-arrow').attr('viewBox', '0 -5 10 10').attr('refX', 6).attr('markerWidth', 3).attr('markerHeight', 3).attr('orient', 'auto').append('svg:path').attr('d', 'M0,-5L10,0L0,5').attr('fill', '#000000').attr('class', 'end-arrow');
  }
  _createClass(DrawGraph, [{
    key: "createNodes",
    value: function createNodes(data) {
      var nodeGroupContainer = this.zoomContainer.select('.graph__nodes');
      if (nodeGroupContainer.size() === 0) {
        nodeGroupContainer = this.zoomContainer.append('g').attr('class', 'graph__nodes');
      }
      this.nodeGroup = drawNodes({
        container: nodeGroupContainer,
        nodeData: data.nodes,
        selectedNodes: this.graph.selectedNodes || [],
        showSecondaryLabel: this.graph.getOption('showSecondaryLabel'),
        getCustomShapePath: this.graph.getOption('getCustomShapePath')
      });
    }

    /**
     * calculate link path
     * @param {IGraphLink} d
     * @param {boolean} reverse if true will return reversed path, usecase is like to avoid the text along path upside down
     * @returns {string} svg link path
     */
  }, {
    key: "calculateLinkPath",
    value: function calculateLinkPath$1(d) {
      var reverse = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      return calculateLinkPath(d, this.linksConnection, reverse);
    }
  }, {
    key: "createLinks",
    value: function createLinks(data) {
      // init link connection
      this.linksConnection = this.graph.getLinksConnection();
      // link group wrapper
      var linkGroupContainer = this.zoomContainer.select('.graph__links');
      if (linkGroupContainer.size() === 0) {
        linkGroupContainer = this.zoomContainer.append('g').attr('class', 'graph__links');
      }
      var _drawLinks = drawLinks({
          container: linkGroupContainer,
          linkData: data.links,
          selectedLinks: this.graph.selectedLinks || []
        }),
        linkGroup = _drawLinks.linkGroup,
        links = _drawLinks.links,
        linksOverlay = _drawLinks.linksOverlay;
      this.linkGroup = linkGroup;
      this.links = links;
      this.linksOverlay = linksOverlay;
    }
  }, {
    key: "registerEvents",
    value: function registerEvents() {
      var _this = this;
      this.nodeGroup.call(clickcancel().on('click', function (evt, data) {
        _this.graph.event.emit(CONSTANTS.EVENT.NODE_CLICK, data, evt);
      }).on('dblclick', function (evt, data) {
        _this.graph.event.emit(CONSTANTS.EVENT.NODE_DBLCLICK, data, evt);
      }));
      this.nodeGroup.on('mouseenter', function (evt, data) {
        _this.graph.event.emit(CONSTANTS.EVENT.NODE_MOUSEENTER, data, evt);
      });
      this.nodeGroup.on('mouseleave', function (evt, data) {
        _this.graph.event.emit(CONSTANTS.EVENT.NODE_MOUSELEAVE, data, evt);
      });
      if (this.dragEvent.drag) {
        this.nodeGroup.call(this.dragEvent.drag);
      }
      var labelGroup = this.nodeGroup.selectAll('.graph__node__label-group');
      var getLabelLevel = function getLabelLevel(evt) {
        var _target$attributes$la;
        var target = evt.target;
        while (!target.classList.contains('graph__node__label-group') || target.tagName.toLowerCase() === 'svg') {
          target = target.parentElement;
        }
        return (_target$attributes$la = target.attributes['labelLevel']) === null || _target$attributes$la === void 0 ? void 0 : _target$attributes$la.value;
      };
      labelGroup.on('mouseenter', function (evt, data) {
        _this.graph.event.emit(CONSTANTS.EVENT.NODE_LABEL_MOUSEENTER, data, evt, getLabelLevel(evt));
      });
      labelGroup.on('mouseleave', function (evt, data) {
        _this.graph.event.emit(CONSTANTS.EVENT.NODE_LABEL_MOUSEELEAVE, data, evt, getLabelLevel(evt));
      });
      labelGroup.call(clickcancel({
        stopPropagation: true
      }).on('click', function (evt, data) {
        _this.graph.event.emit(CONSTANTS.EVENT.NODE_LABEL_CLICK, data, evt, getLabelLevel(evt));
      }).on('dblclick', function (evt, data) {
        _this.graph.event.emit(CONSTANTS.EVENT.NODE_LABEL_DBLCLICK, data, evt, getLabelLevel(evt));
      }));
      this.graph.event.on(CONSTANTS.EVENT.LAYOUT_TICK_START, function () {
        _this.isOnTick = true;
        /* performance enhancement, prevent path and label calculation from every tick */
        _this.linksOverlay.classed('graph-invisible', true);
        _this.linkGroup.selectAll('.graph__link--label').classed('graph-invisible', true);
        /* end performance enhancement */
      });

      this.graph.event.on(CONSTANTS.EVENT.LAYOUT_TICK_END, function () {
        _this.isOnTick = false;
        /* performance enhancement, prevent path and label calculation from every tick */
        _this.linksOverlay.classed('graph-invisible', false);
        _this.linksOverlay.attr('d', function (d) {
          return _this.calculateLinkPath.call(_this, d);
        });
        _this.linkGroup.selectAll('.graph__link--label').classed('graph-invisible', false);
        updateLinkLabelPosition(_this.linkGroup);
        _this.linkGroup.selectAll('.graph__link--label path').attr('d', function (d) {
          var sourceX = d.source.x,
            targetX = d.target.x;
          // set reverse path in case the textpath is upside down
          return _this.calculateLinkPath.call(_this, d, sourceX >= targetX);
        });
        /* end performance enhancement */
      });

      this.graph.event.on(CONSTANTS.EVENT.CHANGE_SELECTED_NODES, function () {
        var selectedNodes = _this.graph.selectedNodes || [];
        _this.nodeGroup.classed(CONSTANTS.CLASSNAME.NODEGROUP_SELECTED, function (d) {
          return selectedNodes.includes(d.id);
        });
      });
      this.graph.event.on(CONSTANTS.EVENT.CHANGE_SELECTED_LINKS, function () {
        var selectedLinks = _this.graph.selectedLinks || [];
        _this.linkGroup.classed(CONSTANTS.CLASSNAME.LINKGROUP_SELECTED, function (d) {
          return selectedLinks.includes(d.id);
        });
      });
      this.linksOverlay.on('mouseover', function (evt) {
        if (!_this.isOnTick) {
          // @ts-ignore
          evt.target.classList.add('graph-opacity');
        }
      });
      this.linksOverlay.on('mouseout', function (evt) {
        // @ts-ignore
        evt.target.classList.remove('graph-opacity');
      });
      this.linksOverlay.call(clickcancel().on('click', function (evt, data) {
        _this.graph.event.emit(CONSTANTS.EVENT.LINK_CLICK, data, evt);
      }).on('dblclick', function (evt, data) {
        _this.graph.event.emit(CONSTANTS.EVENT.LINK_DBLCLICK, data, evt);
      }));
      this.linkGroup.on('mouseenter', function (evt, data) {
        _this.graph.event.emit(CONSTANTS.EVENT.LINK_MOUSEENTER, data, evt);
      });
      this.linkGroup.on('mouseleave', function (evt, data) {
        _this.graph.event.emit(CONSTANTS.EVENT.LINK_MOUSELEAVE, data, evt);
      });
    }
  }, {
    key: "drawGraph",
    value: function drawGraph() {
      var data = getData.call(this.graph);
      this.createLinks(data);
      this.createNodes(data);
      this.registerEvents();
      this.graph.event.emit(CONSTANTS.EVENT.LAYOUT_AFTER_DRAW);
    }
  }, {
    key: "updateGraph",
    value: function updateGraph(scope, updateIds) {
      var _this2 = this;
      if (!scope || scope.length === 0) {
        this.drawGraph();
        return;
      }
      if (scope.indexOf(UpdateGraphScope.position) >= 0) {
        this.nodeGroup.attr('transform', function (d) {
          return 'translate(' + d.x + ',' + d.y + ')';
        });
        this.links.attr('d', function (d) {
          return _this2.calculateLinkPath.call(_this2, d);
        });
      }
      if (scope.indexOf(UpdateGraphScope.toggleLabel) >= 0) {
        this.nodeGroup.selectAll('.graph__node__label-group--primary').classed("".concat(CONSTANTS.CLASSNAME.HIDDEN), !!this.graph.getOption('showSecondaryLabel'));
        this.nodeGroup.selectAll('.graph__node__label-group--secondary').classed("".concat(CONSTANTS.CLASSNAME.HIDDEN), !this.graph.getOption('showSecondaryLabel'));
      }
      if (scope.indexOf(UpdateGraphScope.nodeAttributes) >= 0) {
        drawNodes({
          container: this.zoomContainer.select('.graph__nodes'),
          nodeData: getData.call(this.graph).nodes,
          selectedNodes: this.graph.selectedNodes || [],
          showSecondaryLabel: this.graph.getOption('showSecondaryLabel'),
          getCustomShapePath: this.graph.getOption('getCustomShapePath'),
          updateIds: updateIds
        });
        this.graph.event.emit(CONSTANTS.EVENT.LAYOUT_AFTER_DRAW);
      }
      if (scope.indexOf(UpdateGraphScope.linkAttributes) >= 0) {
        drawLinks({
          container: this.zoomContainer.select('.graph__links'),
          linkData: getData.call(this.graph).links,
          selectedLinks: this.graph.selectedLinks || [],
          updateIds: updateIds
        });
        this.graph.event.emit(CONSTANTS.EVENT.LAYOUT_AFTER_DRAW);
      }
    }
  }]);
  return DrawGraph;
}();

export { DrawGraph as default };
