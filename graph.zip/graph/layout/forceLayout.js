import _objectWithoutProperties from '@babel/runtime/helpers/objectWithoutProperties';
import _typeof from '@babel/runtime/helpers/typeof';
import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _assertThisInitialized from '@babel/runtime/helpers/assertThisInitialized';
import _inherits from '@babel/runtime/helpers/inherits';
import _possibleConstructorReturn from '@babel/runtime/helpers/possibleConstructorReturn';
import _getPrototypeOf from '@babel/runtime/helpers/getPrototypeOf';
import _defineProperty from '@babel/runtime/helpers/defineProperty';
import * as d3 from 'd3v7';
import BaseLayout from './baseLayout.js';
import { registeredLayouts } from './index.js';
import { UpdateGraphScope } from '../types.js';
import { isObject, getData, getTickCount } from '../utils.js';
import CONSTANTS from '../constants.js';

var _excluded = ["fx", "fy", "x", "y", "vx", "vy"];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

//import { getData } from '../../graph'
var ForceLayout = /*#__PURE__*/function (_BaseLayout) {
  _inherits(ForceLayout, _BaseLayout);
  var _super = _createSuper(ForceLayout);
  function ForceLayout(graph, layoutOptions) {
    var _this;
    _classCallCheck(this, ForceLayout);
    _this = _super.call(this, graph);
    _defineProperty(_assertThisInitialized(_this), "layoutOptions", void 0);
    _defineProperty(_assertThisInitialized(_this), "option", void 0);
    _defineProperty(_assertThisInitialized(_this), "simulation", void 0);
    _this.layoutOptions = isObject(layoutOptions) ? layoutOptions : {};
    _this.option = _objectSpread({
      linkDistance: 200,
      linkStrength: 0.2,
      chargeStrength: -1000
    }, _this.layoutOptions);
    _this.graph.event.on(CONSTANTS.EVENT.DRAG_START, function () {
      if (_this.simulation) {
        _this.graph.event.emit(CONSTANTS.EVENT.LAYOUT_TICK_START);
        _this.simulation.alphaTarget(0.1).alpha(0.3).restart();
      }
    });
    _this.graph.event.on(CONSTANTS.EVENT.DRAG_END, function () {
      if (_this.simulation) {
        _this.stop();
      }
    });
    _this.graph.event.on(CONSTANTS.EVENT.LAYOUT_FORCE_EXTEND, function (name, handler) {
      if (name) {
        _this.option.forceExtend = _objectSpread(_objectSpread({}, _this.option.forceExtend || {}), {}, _defineProperty({}, name, handler));
      }
    });
    return _this;
  }

  /**
   * switch to force layout
   * @param {IGraph} graph
   * @param {IGraphData} IGraphData
   */
  _createClass(ForceLayout, [{
    key: "getSimulation",
    value: function getSimulation(data) {
      var _this2 = this;
      var sim = d3.forceSimulation(data.nodes).force('link', d3.forceLink(data.links).id(function (d) {
        return d.id;
      }).distance(function (d) {
        var sourceR = _typeof(d.source) === 'object' ? d.source.r || CONSTANTS.DEFAULT_NODE_RADIUS : 0;
        var targetR = _typeof(d.target) === 'object' ? d.target.r || CONSTANTS.DEFAULT_NODE_RADIUS : 0;
        return Math.max(_this2.option.linkDistance, (sourceR + targetR) * 1.5);
      })
      // .distance(this.option.linkDistance)
      .strength(this.option.linkStrength)).force('charge', d3.forceManyBody().strength(this.option.chargeStrength) // prevent nodes overlapping each other
      //.distanceMax(this.option.chargeDistanceMax), // prevent nodes away too much from each other
      ).force('x', d3.forceX().strength(0.1)).force('y', d3.forceY().strength(0.1)).force('collide', d3.forceCollide().strength(1).radius(function (d) {
        return (d.r || CONSTANTS.DEFAULT_NODE_RADIUS) * 1.1;
      })).alphaMin(0.1);
      if (this.option.forceExtend) {
        /**
         * forceExtend configurations can be passed from vertical through layoutOptions
          > sample code
            const customForce = () => {
              const force = (alpha) => { }
              force.initialize = () => { }
              return force
            }
            const myGraph = new Graph({
              ...,
              layout: {
                type: 'force',
                forceExtend: {
                  'customForce': customForce()
                }
              }
            })
         * or emit from behavior/plugins/events
          > sample code
            this.graph.event.emit(CONSTANTS.EVENT.LAYOUT_FORCE_EXTEND, 'customForce', customForce())
         */
        for (var _name in this.option.forceExtend) {
          var handler = this.option.forceExtend[_name];
          if (handler) {
            sim.force(_name, handler);
          }
        }
      }
      return sim;
    }
  }, {
    key: "start",
    value: function start(onError) {
      var _this3 = this;
      var data = getData.call(this.graph);
      var isStart = true;
      this.graph.event.emit(CONSTANTS.EVENT.LAYOUT_TICK_START);
      if (this.simulation) {
        /** stop previous simulation to avoid untrackable tick which may affects the data */
        this.simulation.stop();
        this.simulation = undefined;
      }
      try {
        this.simulation = this.getSimulation(data);
      } catch (err) {
        if (onError) {
          onError(err);
        }
        return;
      }
      var pendingTicks = 0,
        eleCount = 0;
      this.simulation.on('end', function () {
        if (pendingTicks > 0) {
          _this3.graph.updateGraph([UpdateGraphScope.position]);
          _this3.graph.event.emit(CONSTANTS.EVENT.LAYOUT_TICK);
          pendingTicks = 0;
        }
        _this3.graph.event.emit(CONSTANTS.EVENT.LAYOUT_TICK_END, isStart);
        isStart = false;
        eleCount = 0;
      });
      this.simulation.on('tick', function () {
        if (!eleCount) {
          eleCount = _this3.simulation.nodes().length;
        }
        if (eleCount > 500) {
          if (pendingTicks > 1) {
            _this3.graph.updateGraph([UpdateGraphScope.position]);
            pendingTicks = 0;
          } else {
            pendingTicks++;
          }
        } else {
          _this3.graph.updateGraph([UpdateGraphScope.position]);
          _this3.graph.event.emit(CONSTANTS.EVENT.LAYOUT_TICK);
        }
      });

      // performance enhancement, get the total tick steps from alpha and set the tick to the last step to prevent too much dom manipulations
      this.simulation.stop();
      this.simulation.tick(getTickCount(this.simulation));
      this.restart(0);
    }
  }, {
    key: "restart",
    value: function restart(alpha) {
      this.graph.event.emit(CONSTANTS.EVENT.LAYOUT_TICK_START);
      this.simulation.alpha(typeof alpha === 'number' ? alpha : 0.3).restart();
    }

    // update simulation data
  }, {
    key: "updateData",
    value: function updateData() {
      var data = getData.call(this.graph);
      var newNodes = data.nodes.filter(function (v) {
        return !v.hasOwnProperty('x') || !v.hasOwnProperty('y');
      });
      if (newNodes.length > 0) {
        /** if new data include nodes without position, should calculate its position first */
        var tmpSim = this.getSimulation({
          nodes: data.nodes.map(function (v) {
            if (!v.hasOwnProperty('x') || !v.hasOwnProperty('y')) {
              return v;
            }
            return _objectSpread(_objectSpread({}, v), {}, {
              fx: v.x,
              fy: v.y
            });
          }),
          links: data.links.map(function (v) {
            return {
              id: v.id,
              source: typeof v.source === 'string' ? v.source : v.source.id,
              target: typeof v.target === 'string' ? v.target : v.target.id
            };
          })
        });
        tmpSim.stop();
        var tickCount = Math.ceil(Math.log(tmpSim.alphaMin()) / Math.log(1 - tmpSim.alphaDecay()));
        tmpSim.tick(0);
      }
      if (!this.simulation) {
        return;
      }
      this.simulation.nodes(data.nodes);
      this.simulation.force('link').links(data.links);
      for (var _name2 in this.option.forceExtend) {
        var forceHandler = this.simulation.force(_name2);
        forceHandler === null || forceHandler === void 0 ? void 0 : forceHandler.links(data.links);
      }
    }
  }, {
    key: "stop",
    value: function stop() {
      this.simulation.alphaTarget(0);
    }

    /**
     * return available layouts from registered layouts
     * only selected layouts can be switched each other
     * @returns {ILayout['layouts']}
     */
  }, {
    key: "layouts",
    get: function get() {
      var _registeredLayouts = registeredLayouts(),
        _hierarchy = _registeredLayouts.hierarchy,
        _force = _registeredLayouts.force;
      var graph = this.graph;
      return {
        hierarchy: function hierarchy(data) {
          _hierarchy["switch"](graph, data);
        },
        force: function force(data) {
          _force["switch"](graph, data);
        }
      };
    }
  }], [{
    key: "switch",
    value: function _switch(graph, data) {
      if (!data) {
        data = graph.getData();
        // remove fx, fy, x, y, vx, vy
        data.nodes = data.nodes.map(function (_ref) {
          _ref.fx;
            _ref.fy;
            _ref.x;
            _ref.y;
            _ref.vx;
            _ref.vy;
            var attrs = _objectWithoutProperties(_ref, _excluded);
          return attrs;
        });
      }
      graph.updateData(data).restart(0);
    }
  }]);
  return ForceLayout;
}(BaseLayout);

export { ForceLayout as default };
