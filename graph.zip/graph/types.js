// eslint-disable-next-line

var UpdateGraphScope = /*#__PURE__*/function (UpdateGraphScope) {
  UpdateGraphScope["position"] = "position";
  UpdateGraphScope["toggleLabel"] = "toggleLabel";
  UpdateGraphScope["nodeAttributes"] = "nodeAttributes";
  UpdateGraphScope["linkAttributes"] = "linkAttributes";
  return UpdateGraphScope;
}({});

export { UpdateGraphScope };
