var CONSTANTS = {
  CLASSNAME: {
    HIDDEN: 'graph-hidden',
    GRAPH_ICON: 'graph-icon--',
    NODEGROUP_SELECTED: 'graph__node-group-selected',
    LINKGROUP_SELECTED: 'graph__link-group-selected'
  },
  LAYOUT: {
    FORCE: 'force',
    NETWORK: 'network',
    HIERARCHY: 'hierarchy'
  },
  DEFAULT_NODE_RADIUS: 25,
  BEHAVIOR: {
    HIGHLIGHT_RELATIONS: 'highlightRelations',
    SUBNODES: 'subNodes',
    ZOOMBAR: 'zoomBar',
    BRUSH_SELECT: 'brushSelect',
    LOCATE_HIGHLIGHT: 'locateHighlight',
    FIX_LAYOUT: 'fixLayout'
  },
  EVENT: {
    GRAPH_ON_INSTANCE: 'graph:oninstance',
    GRAPH_ON_ERROR: 'graph:onerror',
    NODE_CLICK: 'node:click',
    NODE_DBLCLICK: 'node:dblclick',
    NODE_MOUSEENTER: 'node:mouseenter',
    NODE_MOUSELEAVE: 'node:mouseleave',
    NODE_LABEL_MOUSEENTER: 'node:labelmouseenter',
    NODE_LABEL_MOUSEELEAVE: 'node:labelmouseleave',
    NODE_LABEL_CLICK: 'node:labelclick',
    NODE_LABEL_DBLCLICK: 'node:labeldblclick',
    LINK_CLICK: 'link:click',
    LINK_DBLCLICK: 'link:dblclick',
    LINK_MOUSEENTER: 'link:mouseenter',
    LINK_MOUSELEAVE: 'link:mouseleave',
    DRAG_START: 'drag:start',
    DRAG: 'drag',
    DRAG_END: 'drag:end',
    LAYOUT_TICK_START: 'layout:tickstart',
    LAYOUT_TICK_END: 'layout:tickend',
    LAYOUT_TICK: 'layout:tick',
    LAYOUT_AFTER_DRAW: 'layout:afterdraw',
    LAYOUT_ZOOM_START: 'layout:zoomstart',
    LAYOUT_ZOOM: 'layout:zoom',
    LAYOUT_ZOOM_END: 'layout:zoomend',
    LAYOUT_CLICK: 'layout:click',
    LAYOUT_FORCE_EXTEND: 'layout:force_extend',
    SET_LINKS_ATTRIBUTES: 'set:links_attributes',
    CHANGE_GRAPH_DATA: 'change:graphdata',
    CHANGE_SELECTED_NODES: 'change:selectednodes',
    CHANGE_SELECTED_LINKS: 'change:selectedlinks',
    CHANGE_CONTAINER_SIZE: 'change:containersize',
    BEFORE_REMOVE_NODES: 'before:removenodes',
    APPLY_EXTRA_LINKS: 'apply:extralinks',
    BEHAVIOR_LOCATEHIGHLIGHT_ONLOCATE: 'behavior:locatehighlight_onlocate',
    BEHAVIOR_BRUSHSELECT_ONBRUSHEND: 'behavior:brushselect_onbrushend'
  },
  DEFAULT: {
    STROKE_WIDTH: 2,
    LEGEND_TOOLTIP_EXPAND: 'Close Legend',
    LEGEND_TOOLTIP_COLLAPSE: 'Open Legend'
  },
  LIMIT: {
    STROKE_WIDTH: 5
  }
};

export { CONSTANTS as default };
