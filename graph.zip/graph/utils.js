import '@babel/runtime/helpers/defineProperty';
import * as d3 from 'd3v7';
import 'uuid';
import cloneDeep from 'lodash.clonedeep';

/**
 * check if value is an array
 * @param {Array}, value
 * @returns {Boolean}
 */
function isArray(value) {
  return Object.prototype.toString.call(value) === '[object Array]';
}

/**
 * check if value is an object
 * @param {Object}, value
 * @returns {Boolean}
 */
function isObject(value) {
  return Object.prototype.toString.call(value) === '[object Object]';
}

/**
 * deep copy reference type
 * @param reference type, value
 * @returns reference type
 */
function deepCopy(value) {
  if (!value) {
    return null;
  }
  // return JSON.parse(JSON.stringify(value))
  return cloneDeep(value);
}

/**
 * check if an Array has the same object by specified object property
 * @param {Array}, data, object array
 * @param {String}, key, property key of the Object
 * @returns {String} error message, empty represents no duplicates found
 */
function hasDuplicates(data, key) {
  var set = new Set();
  var errMsg = '';
  for (var i in data) {
    if (errMsg) {
      break;
    }
    var _id = data[i][key];
    if (!_id) {
      errMsg = "".concat(key, " is required");
      break;
    }
    if (set.has(_id)) {
      errMsg = "can not have duplicated ".concat(key, " ").concat(_id);
      break;
    }
    set.add(_id);
  }
  return errMsg;
}

/**
 * return value in obj according to keyChain
 * @param {Object} obj such as { "a": { "b": 1, "c": 2 }, "d": 3 }
 * @param {string} keyChain such as "a.b"
 * @returns {any}
 */
function getObjectValueByKeyChain(obj, keyChain) {
  var keyArr = (keyChain === null || keyChain === void 0 ? void 0 : keyChain.split('.')) || [];
  var curRes = obj;
  for (var i in keyArr) {
    var _key = keyArr[i];
    if (!curRes.hasOwnProperty(_key)) {
      curRes = undefined;
      break;
    }
    curRes = curRes[_key];
  }
  if (curRes === obj) {
    curRes = undefined;
  }
  return curRes;
}

/**
 * return two float number plus value, this will prevent precision issues
 * @param {number} arg1
 * @param {number} arg2
 * @returns {number}
 */
function floatPlus(arg1, arg2) {
  var r1, r2;
  try {
    r1 = arg1.toString().split('.')[1].length;
  } catch (e) {
    r1 = 0;
  }
  try {
    r2 = arg2.toString().split('.')[1].length;
  } catch (e) {
    r2 = 0;
  }
  var c = Math.abs(r1 - r2);
  var m = Math.pow(10, Math.max(r1, r2));
  if (c > 0) {
    var cm = Math.pow(10, c);
    if (r1 > r2) {
      arg1 = Number(arg1.toString().replace('.', ''));
      arg2 = Number(arg2.toString().replace('.', '')) * cm;
    } else {
      arg1 = Number(arg1.toString().replace('.', '')) * cm;
      arg2 = Number(arg2.toString().replace('.', ''));
    }
  } else {
    arg1 = Number(arg1.toString().replace('.', ''));
    arg2 = Number(arg2.toString().replace('.', ''));
  }
  return (arg1 + arg2) / m;
}

/**
 * return if element can be seen in page through it's style
 * @param {Element} ele
 * @returns {boolean}
 */
function isDomVisible(ele) {
  var style = getComputedStyle(ele);
  var isHidden = style.display === 'none';
  var isInvisible = style.visibility === 'hidden';
  var isTransparent = style.opacity === '0';
  return !isHidden && !isInvisible && !isTransparent;
}
function clickcancel(options) {
  var event = d3.dispatch('click', 'dblclick');

  // Method is assumed to be a standard D3 getter-setter:
  // If passed with no arguments, gets the value.
  // If passed with arguments, sets the value and returns the target.
  var rebindMethod = function rebindMethod(target, source, method) {
    return function () {
      for (var _len = arguments.length, args = new Array(_len), _key2 = 0; _key2 < _len; _key2++) {
        args[_key2] = arguments[_key2];
      }
      var value = method.apply(source, args);
      return value === source ? target : value;
    };
  };

  // rebind is removed since d3 V4, write own rebind method
  // Copies a variable number of methods from source to target.
  var rebind = function rebind(target, source) {
    for (var _len2 = arguments.length, methods = new Array(_len2 > 2 ? _len2 - 2 : 0), _key3 = 2; _key3 < _len2; _key3++) {
      methods[_key3 - 2] = arguments[_key3];
    }
    for (var _i = 0, _methods = methods; _i < _methods.length; _i++) {
      var method = _methods[_i];
      target[method] = rebindMethod(target, source, source[method]);
    }
    return target;
  };
  var dist = function dist(a, b) {
    if (!a || !b || a.length === 0 || b.length === 0) return 0;
    return Math.sqrt(Math.pow(a[0] - b[0], 2));
  };
  var cc = function cc(selection) {
    var down;
    var tolerance = 5;
    var wait = null;
    var eventArgs;
    selection.on('mousedown', function (evt) {
      // @ts-ignore
      down = d3.pointer(evt, document.body);
      for (var _len3 = arguments.length, args = new Array(_len3 > 1 ? _len3 - 1 : 0), _key4 = 1; _key4 < _len3; _key4++) {
        args[_key4 - 1] = arguments[_key4];
      }
      eventArgs = [evt].concat(args);
    });
    selection.on('click', function (evt) {
      if (options !== null && options !== void 0 && options.stopPropagation) {
        evt.preventDefault();
        evt.stopPropagation();
      }
      // @ts-ignore
      if (dist(down, d3.pointer(evt, document.body)) > tolerance) return;
      if (wait) {
        window.clearTimeout(wait);
        wait = null;
        event.apply('dblclick', selection, eventArgs);
      } else {
        wait = window.setTimeout(function () {
          event.apply('click', selection, eventArgs);
          wait = null;
        }, 300);
      }
    });
  };
  return rebind(cc, event, 'on');
}

/**
 * group links with connection
 * @param {IGraphData} data
 * @returns {[connectionId:string]: string[]}
 */
function getLinksConnection(data) {
  var linksConnection = {};
  data.links.map(function (d) {
    if (d.source && d.target) {
      var targetId = typeof d.target === 'string' ? d.target : d.target.id;
      var sourceId = typeof d.source === 'string' ? d.source : d.source.id;
      var connectionId = "".concat(sourceId, "_").concat(targetId);
      if (!linksConnection[connectionId]) {
        linksConnection[connectionId] = [];
      }
      linksConnection[connectionId].push(d.id);
    }
  });
  return linksConnection;
}

/**
 * get realted nodes and links according to param
 * @param {string[]} targetNodeIds
 * @param {IGraphData} data
 * @returns {IGraphData}
 */
function getRelatedNodesAndLinks(targetNodeIds, data) {
  var nodeIds = new Set();
  targetNodeIds.forEach(function (v) {
    return nodeIds.add(v);
  });
  var links = data.links.filter(function (v) {
    var sourceId = typeof v.source === 'string' ? v.source : v.source.id;
    var targetId = typeof v.target === 'string' ? v.target : v.target.id;
    var hasRelation = targetNodeIds.includes(sourceId) || targetNodeIds.includes(targetId);
    if (hasRelation) {
      nodeIds.add(sourceId);
      nodeIds.add(targetId);
    }
    return hasRelation;
  });
  var nodes = data.nodes.filter(function (v) {
    return nodeIds.has(v.id);
  });
  return {
    nodes: nodes,
    links: links
  };
}

/**
 * get new graph data according to params, exclude removed nodes and its related links
 * @param {string[]} targetNodeIds
 * @param {IGraphData} data
 * @returns {IGraphData}
 */
function getGraphDataWhenNodesRemove(targetNodeIds, data) {
  // remove child node first
  data.nodes.forEach(function (v) {
    if (v.children && v.children.length > 0) {
      v.children = v.children.filter(function (n) {
        return !targetNodeIds.includes(n.id);
      });
    }
  });
  // remove top level nodes and links
  var removeNodeIds = new Set();
  var removeLinkIds = new Set();
  targetNodeIds.forEach(function (v) {
    return removeNodeIds.add(v);
  });
  var relatedNodesAndLinks = getRelatedNodesAndLinks(targetNodeIds, data);
  relatedNodesAndLinks.links.forEach(function (v) {
    return removeLinkIds.add(v.id);
  });
  return {
    nodes: data.nodes.filter(function (v) {
      return !removeNodeIds.has(v.id);
    }),
    links: data.links.filter(function (v) {
      return !removeLinkIds.has(v.id);
    })
  };
}
/**
 * get graph nodes unions to help user check their connection
 * @param {IGraphData} data
 * @returns {string[][]}
 */
function getGraphNodeUnions(data) {
  var idx = 1;
  var unionMap = {};
  var linkNodeIds = new Set();
  var nodeIds = new Set();
  data.nodes.forEach(function (d) {
    return nodeIds.add(d.id);
  });
  data.links.forEach(function (d) {
    var targetId = typeof d.target === 'string' ? d.target : d.target.id;
    var sourceId = typeof d.source === 'string' ? d.source : d.source.id;
    linkNodeIds.add(sourceId);
    linkNodeIds.add(targetId);
    var sourceUnion = 0,
      targetUnion = 0;
    for (var u in unionMap) {
      if (sourceUnion === 0 && unionMap[u].has(sourceId)) {
        sourceUnion = +u;
      }
      if (targetUnion === 0 && unionMap[u].has(targetId)) {
        targetUnion = +u;
      }
      if (targetUnion > 0 && sourceUnion > 0) {
        break;
      }
    }
    if (sourceUnion === 0 && targetUnion === 0) {
      unionMap[++idx] = new Set([sourceId, targetId]);
    } else if (sourceUnion !== targetUnion) {
      if (sourceUnion === 0) {
        unionMap[targetUnion].add(sourceId);
      } else if (targetUnion === 0) {
        unionMap[sourceUnion].add(targetId);
      } else {
        unionMap[targetUnion].forEach(function (v) {
          return unionMap[sourceUnion].add(v);
        });
        delete unionMap[targetUnion];
      }
    }
  });
  var singleNodes = Array.from(nodeIds).filter(function (id) {
    return !linkNodeIds.has(id);
  });
  singleNodes.forEach(function (d) {
    unionMap[++idx] = new Set([d]);
  });
  var res = [];
  for (var _k in unionMap) {
    var un = Array.from(unionMap[_k]);
    if (un.length > 0) {
      res.push(un);
    }
  }
  return res;
}

/**
 * expand aggregated edges (has children field) and return new graph data
 * @param {IGraphLink[]} links links need to be expanded
 * @param {IGraphData} data
 * @returns {IGraphData}
 */
function expandAggregatedEdges(links, data) {
  if (!isArray(links)) {
    throw new Error('The parameter type of expand aggregated edge needs to be array.');
  }
  var ids = [];
  var newLinks = data.links;
  var nodes = data.nodes;
  var linkIds = newLinks.map(function (v) {
    return v.id;
  });
  var nodeMap = {};
  nodes.forEach(function (n) {
    nodeMap[n.id] = n;
  });
  deepCopy(links).forEach(function (link) {
    if (isArray(link.children) && linkIds.includes(link.id)) {
      var sourceId = typeof link.source === 'string' ? link.source : link.source.id;
      var targetId = typeof link.target === 'string' ? link.target : link.target.id;
      var sourceNode = nodeMap[sourceId],
        targetNode = nodeMap[targetId];
      link.children.forEach(function (child) {
        child.source = sourceNode;
        child.target = targetNode;
        if (!linkIds.includes(child.id)) {
          newLinks.push(child);
          linkIds.push(child.id);
        }
      });
      ids.push(link.id);
    }
  });
  ids.forEach(function (id) {
    var index = newLinks.findIndex(function (link) {
      return link.id === id;
    });
    if (index >= 0) {
      newLinks.splice(index, 1);
    }
  });
  return {
    nodes: nodes,
    links: newLinks
  };
}

/**
 * get items by attributes
 * @param {T[]} list nodelist or linklist
 * @param {any[]} values
 * @param {string} field eg. 'id' 'raw.properity.xxx'
 * @param {string} childField optional. if set value, will deep search from this field 'children' '@clusterSubItems'
 * @param {boolean} like optional. default is exactly match, can set to true to apply partly match
 * @returns {items:T[], subItems:Array<{parent:T, items:T[]}>}
 */
function getDataByAttributes(list, values, field, childField, like) {
  var items = [];
  var subItems = [];
  var isMatch = function isMatch(value) {
    if (!like) {
      return values.includes(value);
    }
    if (!value) {
      return false;
    }
    var ismatch = false;
    values.forEach(function (v) {
      if (!ismatch && value.indexOf(v) >= 0) {
        ismatch = true;
      }
    });
    return ismatch;
  };
  list.forEach(function (v) {
    var value = getObjectValueByKeyChain(v, field);
    if (isMatch(value)) {
      items.push(v);
    }
    if (childField) {
      var subitems = getObjectValueByKeyChain(v, childField);
      if (subitems && subitems.length > 0) {
        var matchedSubLinks = subitems.filter(function (s) {
          return isMatch(getObjectValueByKeyChain(s, field));
        });
        if (matchedSubLinks.length > 0) {
          subItems.push({
            parent: v,
            items: matchedSubLinks
          });
        }
      }
    }
  });
  return {
    items: items,
    subItems: subItems
  };
}

/** functions does not expose to instance */
/**
 * get data
 * @returns {IGraphData}
 */
function getData() {
  return this.data;
}

/**
 * get the total tick steps from d3 simulation alphaMin and alphaDecay
 * @param {Simulation} sim, d3 simulation
 * @returns {Integer} number of tick steps
 */
function getTickCount(sim) {
  return Math.ceil(Math.log(sim.alphaMin()) / Math.log(1 - sim.alphaDecay()));
}

/**
 * common function to set links attributes, can be used in graph/index and behaviors
 * @param links
 * @param linkMap
 * @param childFields
 * @returns { links: IGraphLink[], matchedIds: string[] }
 */
function setLinksAttributes(links, linkMap) {
  var childFields = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : ['children'];
  var matchedIds = [];
  if (!links || !linkMap || Object.keys(linkMap).length === 0) {
    return {
      links: links,
      matchedIds: matchedIds
    };
  }
  links.forEach(function (n) {
    if (linkMap[n.id]) {
      Object.assign(n, linkMap[n.id], {
        id: n.id,
        source: n.source,
        target: n.target
      });
      matchedIds.push(n.id);
      delete linkMap[n.id];
    }
    childFields === null || childFields === void 0 ? void 0 : childFields.forEach(function (k) {
      if (n[k] && Array.isArray(n[k])) {
        n[k].forEach(function (v) {
          if (linkMap[v.id]) {
            Object.assign(v, linkMap[v.id], {
              id: v.id
            });
            matchedIds.push(v.id);
            delete linkMap[v.id];
          }
        });
      }
    });
  });
  return {
    links: links,
    matchedIds: matchedIds
  };
}

export { clickcancel, deepCopy, expandAggregatedEdges, floatPlus, getData, getDataByAttributes, getGraphDataWhenNodesRemove, getGraphNodeUnions, getLinksConnection, getObjectValueByKeyChain, getRelatedNodesAndLinks, getTickCount, hasDuplicates, isArray, isDomVisible, isObject, setLinksAttributes };
