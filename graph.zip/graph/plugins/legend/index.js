import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _assertThisInitialized from '@babel/runtime/helpers/assertThisInitialized';
import _inherits from '@babel/runtime/helpers/inherits';
import _possibleConstructorReturn from '@babel/runtime/helpers/possibleConstructorReturn';
import _getPrototypeOf from '@babel/runtime/helpers/getPrototypeOf';
import _defineProperty from '@babel/runtime/helpers/defineProperty';
import _slicedToArray from '@babel/runtime/helpers/slicedToArray';
import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import BasePlugin from '../base.js';
import CONSTANTS from '../../constants.js';
import { Tooltip } from '@paypalcorp/pp-react-tooltip';
import { getData } from '../../utils.js';
import ppreact from '../../../components/PPReactThemeProvider/index.js';
import './index.scss.js';

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function GraphLegend(props) {
  var _collapse$tooltip, _collapse$tooltip2;
  var options = props.options,
    content = props.content;
  var position = options.position,
    collapse = options.collapse,
    onToggleLegend = options.onToggleLegend;
  var _useState = useState(collapse === null || collapse === void 0 ? void 0 : collapse.expand),
    _useState2 = _slicedToArray(_useState, 2),
    expand = _useState2[0],
    setExpand = _useState2[1];
  function toggleLegendAction() {
    setExpand(!expand);
    onToggleLegend(expand);
  }
  var collapseIcon = typeof (collapse === null || collapse === void 0 ? void 0 : collapse.collapseIcon) === 'function' ? collapse === null || collapse === void 0 ? void 0 : collapse.collapseIcon() : collapse === null || collapse === void 0 ? void 0 : collapse.collapseIcon;
  var expandIcon = typeof (collapse === null || collapse === void 0 ? void 0 : collapse.expandIcon) === 'function' ? collapse === null || collapse === void 0 ? void 0 : collapse.expandIcon() : collapse === null || collapse === void 0 ? void 0 : collapse.expandIcon;
  var icons = collapseIcon && expandIcon && (expand ? collapseIcon : expandIcon) || /*#__PURE__*/React.createElement("i", {
    className: "graph-icon--".concat(expand ? 'collapse' : 'expand')
  });
  var expandText = (collapse === null || collapse === void 0 || (_collapse$tooltip = collapse.tooltip) === null || _collapse$tooltip === void 0 ? void 0 : _collapse$tooltip.expandText) || CONSTANTS.DEFAULT.LEGEND_TOOLTIP_EXPAND;
  var collapseText = (collapse === null || collapse === void 0 || (_collapse$tooltip2 = collapse.tooltip) === null || _collapse$tooltip2 === void 0 ? void 0 : _collapse$tooltip2.collapseText) || CONSTANTS.DEFAULT.LEGEND_TOOLTIP_COLLAPSE;
  return /*#__PURE__*/React.createElement("div", {
    className: "graph__legend__container graph__legend--".concat(position ? position : 'top', " graph__legend--").concat(expand ? 'expand' : 'collapse')
  }, collapse && /*#__PURE__*/React.createElement("span", {
    onClick: toggleLegendAction,
    className: "graph__legend__collapse"
  }, /*#__PURE__*/React.createElement(React.Fragment, null, collapse.tooltip ? /*#__PURE__*/React.createElement(Tooltip, {
    triggerClassName: "graph-icon--".concat(expand ? 'collapse' : 'expand'),
    description: expand ? expandText : collapseText
  }) : /*#__PURE__*/React.createElement("span", null), icons)), /*#__PURE__*/React.createElement("div", {
    className: "graph__legend__content"
  }, content));
}
var WrappedGraphLegend = ppreact(GraphLegend);
var Legend = /*#__PURE__*/function (_BasePlugin) {
  _inherits(Legend, _BasePlugin);
  var _super = _createSuper(Legend);
  function Legend(options) {
    var _this;
    _classCallCheck(this, Legend);
    _this = _super.call(this);
    // private graph: IGraph
    _defineProperty(_assertThisInitialized(_this), "legendOptions", void 0);
    _defineProperty(_assertThisInitialized(_this), "legendContainer", void 0);
    _this.legendOptions = options.constructor === Object ? options : {};
    return _this;
  }
  _createClass(Legend, [{
    key: "init",
    value: function init(graph) {
      var _graph$getContainer = graph.getContainer(),
        container = _graph$getContainer.container;
      var _this$legendOptions = this.legendOptions,
        className = _this$legendOptions.className,
        content = _this$legendOptions.content;
      this.legendContainer = document.createElement('div');
      this.legendContainer.className = className;
      container.appendChild(this.legendContainer);
      var contents = typeof content === 'function' ? content(getData.call(graph)) : content;
      this.setContent(contents);
    }
  }, {
    key: "setContent",
    value: function setContent(content) {
      ReactDOM.render( /*#__PURE__*/React.createElement(WrappedGraphLegend, {
        options: this.legendOptions,
        content: content
      }), this.legendContainer);
    }
  }]);
  return Legend;
}(BasePlugin);

export { Legend as default };
