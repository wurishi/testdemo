import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _assertThisInitialized from '@babel/runtime/helpers/assertThisInitialized';
import _inherits from '@babel/runtime/helpers/inherits';
import _possibleConstructorReturn from '@babel/runtime/helpers/possibleConstructorReturn';
import _getPrototypeOf from '@babel/runtime/helpers/getPrototypeOf';
import _defineProperty from '@babel/runtime/helpers/defineProperty';
import React from 'react';
import ReactDOM from 'react-dom';
import * as d3 from 'd3v7';
import BasePlugin from '../base.js';
import CONSTANTS from '../../constants.js';
import './index.scss.js';

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var Tooltip = /*#__PURE__*/function (_BasePlugin) {
  _inherits(Tooltip, _BasePlugin);
  var _super = _createSuper(Tooltip);
  function Tooltip(options) {
    var _this;
    _classCallCheck(this, Tooltip);
    _this = _super.call(this);
    _defineProperty(_assertThisInitialized(_this), "tooltipOptions", void 0);
    _defineProperty(_assertThisInitialized(_this), "container", void 0);
    _defineProperty(_assertThisInitialized(_this), "targetEL", void 0);
    _defineProperty(_assertThisInitialized(_this), "selection", void 0);
    _this.tooltipOptions = options.constructor === Object ? options : {};
    return _this;
  }
  _createClass(Tooltip, [{
    key: "tooltipContainer",
    value: function tooltipContainer(options, data, evt) {
      var content = typeof options.content === 'function' ? options.content(data, evt) : options.content;
      return content ? /*#__PURE__*/React.createElement(React.Fragment, null, content) : null;
    }
  }, {
    key: "showTooptip",
    value: function showTooptip(data, evt) {
      var content = this.tooltipContainer(this.tooltipOptions, data, evt);
      if (content) {
        this.updateContainerPosition(evt);
        this.container.style.display = 'block';
        ReactDOM.render(content, this.container);
      }
    }
  }, {
    key: "updateContainerPosition",
    value: function updateContainerPosition(evt) {
      var left = evt.pageX,
        top = evt.pageY;
      if (this.tooltipOptions.position === 'top') {
        left -= this.container.clientWidth / 2;
        top -= this.container.clientHeight + 10;
      } else {
        // default is 'right'
        left += 5;
        top += 5;
      }
      this.container.style.left = "".concat(left, "px");
      this.container.style.top = "".concat(top, "px");
    }
  }, {
    key: "hideTooptip",
    value: function hideTooptip() {
      this.container.style.display = 'none';
    }
  }, {
    key: "bindEvents",
    value: function bindEvents(data, evt) {
      var _this2 = this;
      var selector = this.tooltipOptions.selector;
      if (evt.target !== this.targetEL) {
        this.targetEL = evt.target;
        if (this.selection) {
          // remove event
          this.selection.on('.tooltip', null);
        }
        this.selection = d3.select(this.targetEL);
        if (selector) {
          this.selection = this.selection.selectAll(selector);
        } else {
          this.showTooptip(data, evt);
        }
        this.selection.on('mouseenter.tooltip', function (ev) {
          _this2.showTooptip(data, ev);
        });
        this.selection.on('mousemove.tooltip', function (ev) {
          _this2.updateContainerPosition(ev);
        });
        this.selection.on('mouseleave.tooltip', function () {
          _this2.hideTooptip();
        });
      }
    }
  }, {
    key: "unbindEvents",
    value: function unbindEvents() {
      if (this.selection) {
        this.selection.on('.tooltip', null);
        this.selection = undefined;
        this.targetEL = undefined;
        this.hideTooptip();
      }
    }
  }, {
    key: "init",
    value: function init(graph) {
      var _this3 = this;
      var _this$tooltipOptions = this.tooltipOptions,
        className = _this$tooltipOptions.className,
        target = _this$tooltipOptions.target,
        _this$tooltipOptions$ = _this$tooltipOptions.position,
        position = _this$tooltipOptions$ === void 0 ? 'rightBottom' : _this$tooltipOptions$;
      var div = document.createElement('div');
      div.className = "graph__tooltip__container graph__tooltip__container-".concat(position, " ").concat(className || '');
      document.body.appendChild(div);
      this.container = div;
      switch (target) {
        case 'link':
          graph.event.on(CONSTANTS.EVENT.LINK_MOUSEENTER, function (data, evt) {
            _this3.bindEvents(data, evt);
          });
          graph.event.on(CONSTANTS.EVENT.LINK_MOUSELEAVE, function () {
            _this3.unbindEvents();
          });
          break;
        case 'node':
          graph.event.on(CONSTANTS.EVENT.NODE_MOUSEENTER, function (data, evt) {
            _this3.bindEvents(data, evt);
          });
          graph.event.on(CONSTANTS.EVENT.NODE_MOUSELEAVE, function () {
            _this3.unbindEvents();
          });
          break;
      }
    }
  }, {
    key: "destroy",
    value: function destroy() {
      this.unbindEvents();
      this.container.remove();
    }
  }]);
  return Tooltip;
}(BasePlugin);

export { Tooltip as default };
