import styleInject from 'style-inject/dist/style-inject.es.js';

var css_248z = ".graph__tooltip__container {\n  width: auto;\n  height: auto;\n  background-color: #fff;\n  border-radius: 4px;\n  border: 1px solid #ccc;\n  box-sizing: content-box;\n  box-shadow: 0 4px 4px rgba(0, 0, 0, 0.15);\n  pointer-events: none;\n  position: absolute;\n  display: none;\n}\n\n.graph__tooltip__container-top::before {\n  position: absolute;\n  content: \"\";\n  width: 10px;\n  height: 10px;\n  background-color: #fff;\n  border-left: 1px solid #ccc;\n  border-bottom: 1px solid #ccc;\n  left: 50%;\n  bottom: -8px;\n  transform-origin: bottom left;\n  transform: rotate(-45deg);\n}";
styleInject(css_248z);

export { css_248z as default };
