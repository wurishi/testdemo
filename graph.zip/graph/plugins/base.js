import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _defineProperty from '@babel/runtime/helpers/defineProperty';

var BasePlugin = /*#__PURE__*/function () {
  function BasePlugin() {
    _classCallCheck(this, BasePlugin);
    _defineProperty(this, "graph", void 0);
  }
  _createClass(BasePlugin, [{
    key: "init",
    value: function init(graph) {
      this.graph = graph;
    }
  }, {
    key: "destroy",
    value: function destroy() {}
  }]);
  return BasePlugin;
}();

export { BasePlugin as default };
