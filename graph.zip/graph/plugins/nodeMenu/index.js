import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _assertThisInitialized from '@babel/runtime/helpers/assertThisInitialized';
import _inherits from '@babel/runtime/helpers/inherits';
import _possibleConstructorReturn from '@babel/runtime/helpers/possibleConstructorReturn';
import _getPrototypeOf from '@babel/runtime/helpers/getPrototypeOf';
import _defineProperty from '@babel/runtime/helpers/defineProperty';
import './index.scss.js';
import * as d3 from 'd3v7';
import BasePlugin from '../base.js';
import CONSTANTS from '../../constants.js';
import NodeAction from './actionbtn/index.js';
import { isDomVisible, getData } from '../../utils.js';
import Tooltip from '../../../components/Tooltip/index.js';

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var DELTA_RADIUS = 35;
var NodeMenu = /*#__PURE__*/function (_BasePlugin) {
  _inherits(NodeMenu, _BasePlugin);
  var _super = _createSuper(NodeMenu);
  function NodeMenu(options) {
    var _this;
    _classCallCheck(this, NodeMenu);
    _this = _super.call(this);
    _defineProperty(_assertThisInitialized(_this), "menuOptions", void 0);
    _defineProperty(_assertThisInitialized(_this), "nodeAction", void 0);
    _defineProperty(_assertThisInitialized(_this), "selectedIds", void 0);
    _defineProperty(_assertThisInitialized(_this), "menuNodeContainer", void 0);
    _defineProperty(_assertThisInitialized(_this), "menuNodeGroup", void 0);
    _defineProperty(_assertThisInitialized(_this), "tooltipKeys", void 0);
    _this.menuOptions = options.constructor === Object ? options : {};
    _this.nodeAction = new NodeAction(_this.menuOptions);
    _this.selectedIds = [];
    _this.tooltipKeys = new Set();
    return _this;
  }
  _createClass(NodeMenu, [{
    key: "handleClick",
    value: function handleClick(data) {
      var action = data.menuConfig.actions[data.menuConfig.idx];
      if (action && action.onClick) {
        action.onClick(data);
      }
    }
  }, {
    key: "onChangeSelectedNodes",
    value: function onChangeSelectedNodes(ids) {
      this.selectedIds = ids;
      this.renderMenus();
    }
  }, {
    key: "renderMenus",
    value: function renderMenus() {
      var _this2 = this;
      var ids = this.selectedIds || [];
      var pie = d3.pie().sort(null).value(function () {
        return 1;
      });
      var arc = d3.arc().innerRadius(function (d) {
        var _d$data;
        return ((_d$data = d.data) === null || _d$data === void 0 ? void 0 : _d$data.r) || CONSTANTS.DEFAULT_NODE_RADIUS;
      }).outerRadius(function (d) {
        var _d$data2;
        return (((_d$data2 = d.data) === null || _d$data2 === void 0 ? void 0 : _d$data2.r) || CONSTANTS.DEFAULT_NODE_RADIUS) + DELTA_RADIUS;
      });
      var tweenPie = function tweenPie(b) {
        var _b$data;
        b.outerRadius = ((_b$data = b.data) === null || _b$data === void 0 ? void 0 : _b$data.r) || CONSTANTS.DEFAULT_NODE_RADIUS;
        b.innerRadius = b.outerRadius + DELTA_RADIUS;
        var i = d3.interpolate({
          startAngle: 0,
          endAngle: 0,
          outerRadius: 0,
          innerRadius: 0
        }, b);
        return function (t) {
          return arc(i(t));
        };
      };
      var _this$graph$getContai = this.graph.getContainer(),
        zoomContainer = _this$graph$getContai.zoomContainer;
      var nodeMenuContainer = zoomContainer.select('.graph__menu__container');
      if (nodeMenuContainer.size() === 0) {
        nodeMenuContainer = zoomContainer.append('g').attr('class', 'graph__menu__container');
      }
      var nodeGroup = zoomContainer.selectAll('.graph__node-group');
      var nodeVisibleMap = {};

      /** draw circle background for not-circle shape */
      nodeGroup.selectAll('.graph__menu__node-circle').remove();
      var n = nodeGroup.filter(function (v, idx, list) {
        if (ids.includes(v.id)) {
          nodeVisibleMap[v.id] = isDomVisible(list[idx]);
        }
        return ids.includes(v.id) && !!v.shape && v.shape !== 'circle';
      });
      var dd = n.data();
      n.nodes().forEach(function (el, idx) {
        var _dd$idx;
        var c = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        c.classList.add('graph__menu__node-circle');
        c.setAttribute('r', String(((_dd$idx = dd[idx]) === null || _dd$idx === void 0 ? void 0 : _dd$idx.r) || CONSTANTS.DEFAULT_NODE_RADIUS));
        c.setAttribute('fill', 'rgba(0, 0, 0, 0.8)');
        el.prepend(c);
      });
      nodeGroup.selectAll('.graph__menu__node-circle').on('click', function (evt) {
        evt.preventDefault();
        evt.stopPropagation();
      });

      /** draw menu */
      var menuData = [];
      getData.call(this.graph).nodes.forEach(function (v) {
        if (ids.includes(v.id)) {
          menuData.push(_objectSpread(_objectSpread({}, v), {}, {
            menuConfig: {
              idx: -1,
              actions: _this2.nodeAction.getActionButtons(v)
            }
          }));
        } else if (v.children) {
          v.children.forEach(function (d) {
            if (ids.includes(d.id)) {
              menuData.push(_objectSpread(_objectSpread({}, d), {}, {
                x: d.x + v.x,
                y: d.y + v.y,
                menuConfig: {
                  idx: -1,
                  actions: _this2.nodeAction.getActionButtons(d)
                }
              }));
            }
          });
        }
      });
      menuData.sort(function (a, b) {
        return ids.indexOf(a.id) > ids.indexOf(b.id) ? 1 : -1;
      });
      var menuContainer = nodeMenuContainer.selectAll('.graph__menu').data(menuData).join('g').attr('class', this.menuOptions.className || '').classed('graph__menu', true).style('visibility', function (d) {
        return nodeVisibleMap[d.id] === false ? 'hidden' : null;
      }).attr('transform', function (d) {
        return "translate(".concat(d.x, ",").concat(d.y, ")");
      });
      var menuGroup = menuContainer.selectAll('.graph__menu__item').data(function (d) {
        var actions = d.menuConfig.actions;
        if (actions) {
          if (actions.length === 0) {
            // draw a empty ring if actions be set as []
            return pie([_objectSpread(_objectSpread({}, d), {}, {
              menuConfig: {
                idx: 0,
                actions: []
              }
            })]);
          }
          return pie(actions.map(function (_v, idx) {
            return _objectSpread(_objectSpread({}, d), {}, {
              menuConfig: _objectSpread(_objectSpread({}, d.menuConfig), {}, {
                idx: idx
              })
            });
          }));
        }
        return pie([]);
      }).join('g').attr('class', function (d) {
        var _d$data3;
        var cl = ['graph__menu__item'];
        var action = (_d$data3 = d.data) === null || _d$data3 === void 0 ? void 0 : _d$data3.menuConfig.actions[d.data.menuConfig.idx];
        if (action !== null && action !== void 0 && action.className) {
          cl.push(action.className);
        }
        if (action !== null && action !== void 0 && action.disabled) {
          cl.push('graph__menu__item-disabled');
        }
        return cl.join(' ');
      }).attr('data-key', function (d) {
        var _d$data4;
        var action = (_d$data4 = d.data) === null || _d$data4 === void 0 ? void 0 : _d$data4.menuConfig.actions[d.data.menuConfig.idx];
        return (action === null || action === void 0 ? void 0 : action.key) || '';
      }).on('click', function (evt, d) {
        var _d$data5;
        var action = (_d$data5 = d.data) === null || _d$data5 === void 0 ? void 0 : _d$data5.menuConfig.actions[d.data.menuConfig.idx];
        if (action !== null && action !== void 0 && action.disabled) {
          return;
        }
        Tooltip.removeTip(action.key);
        _this2.tooltipKeys["delete"](action.key);
        if (d.data) {
          _this2.handleClick(d.data);
        }
        evt.stopPropagation();
      }).on('mousemove', function (evt, d) {
        var toolTipOption = _this2.menuOptions.tooltip;
        var toolTipContentOption = toolTipOption === null || toolTipOption === void 0 ? void 0 : toolTipOption.content;
        if (toolTipContentOption) {
          var _d$data6;
          evt.preventDefault();
          evt.stopImmediatePropagation();
          var action = (_d$data6 = d.data) === null || _d$data6 === void 0 ? void 0 : _d$data6.menuConfig.actions[d.data.menuConfig.idx];
          if (!action) return;
          var content = typeof toolTipContentOption === 'function' ? toolTipContentOption(action.options.name, action.node) : toolTipContentOption;
          if (content) {
            Tooltip.showTip({
              tipId: action.key,
              targetPosition: {
                left: evt.clientX,
                top: evt.clientY
              },
              props: {
                content: content,
                theme: toolTipOption.theme,
                position: toolTipOption.position,
                className: toolTipOption.className
              }
            });
            _this2.tooltipKeys.add(action.key);
          }
        }
      }).on('mouseleave', function (_evt, d) {
        var _this2$menuOptions$to;
        var toolTipContentOption = (_this2$menuOptions$to = _this2.menuOptions.tooltip) === null || _this2$menuOptions$to === void 0 ? void 0 : _this2$menuOptions$to.content;
        if (toolTipContentOption) {
          var _d$data7;
          var action = (_d$data7 = d.data) === null || _d$data7 === void 0 ? void 0 : _d$data7.menuConfig.actions[d.data.menuConfig.idx];
          if (!action) return;
          Tooltip.removeTip(action.key);
          _this2.tooltipKeys["delete"](action.key);
        }
      });
      menuGroup.selectAll('.graph__menu__item__path').data(function (d) {
        return [d];
      }).join(function (enter) {
        var t = enter.append('path').attr('fill', function () {
          return '#aec7e8';
        }).attr('d', arc).attr('class', 'graph__menu__item__path');
        t.transition().duration(500).ease(d3.easeExpOut).attrTween('d', tweenPie);
        return t;
      }, function (update) {
        return update.attr('d', arc);
      });
      menuGroup.selectAll('.graph__menu__item__text').data(function (d) {
        return [d];
      }).join('text').attr('class', 'graph__menu__item__text').attr('dy', '.35em').attr('transform', function (d) {
        var _d$data8;
        var innerR = ((_d$data8 = d.data) === null || _d$data8 === void 0 ? void 0 : _d$data8.r) || CONSTANTS.DEFAULT_NODE_RADIUS;
        var outerR = innerR + DELTA_RADIUS;
        var centroid = d3.arc().innerRadius(innerR).outerRadius(outerR).startAngle(d.startAngle).endAngle(d.endAngle).centroid(null);
        return "translate(".concat(centroid[0], ", ").concat(centroid[1], ")");
      }).text(function (d) {
        var _d$data9;
        var action = (_d$data9 = d.data) === null || _d$data9 === void 0 ? void 0 : _d$data9.menuConfig.actions[d.data.menuConfig.idx];
        if (action !== null && action !== void 0 && action.getText) {
          return action.getText() || '';
        }
        return '';
      });
      this.menuNodeContainer = nodeMenuContainer;
      this.menuNodeGroup = menuContainer;
    }
  }, {
    key: "presetNodeActions",
    value: function presetNodeActions(data, resetActionNames) {
      return this.nodeAction.setNodeActions(data, resetActionNames);
    }
  }, {
    key: "getActionStore",
    value: function getActionStore(fieldName) {
      return this.nodeAction.getActionStore(fieldName);
    }
  }, {
    key: "init",
    value: function init(graph) {
      var _this3 = this;
      this.graph = graph;
      this.nodeAction.registerActionButtons(this.graph, this.menuOptions, true);
      this.graph.event.on(CONSTANTS.EVENT.CHANGE_GRAPH_DATA, function () {
        _this3.nodeAction.registerActionButtons(_this3.graph, _this3.menuOptions);
        _this3.renderMenus();
      });
      this.graph.event.on(CONSTANTS.EVENT.CHANGE_SELECTED_NODES, function (ids) {
        return _this3.onChangeSelectedNodes(ids);
      });
      var isOnTick = false,
        isOnDrag = false;
      this.graph.event.on(CONSTANTS.EVENT.LAYOUT_TICK_START, function () {
        var _this3$menuNodeContai;
        (_this3$menuNodeContai = _this3.menuNodeContainer) === null || _this3$menuNodeContai === void 0 ? void 0 : _this3$menuNodeContai.style('visibility', 'hidden');
        isOnTick = true;
      });
      this.graph.event.on(CONSTANTS.EVENT.DRAG_START, function () {
        var _this3$menuNodeContai2;
        (_this3$menuNodeContai2 = _this3.menuNodeContainer) === null || _this3$menuNodeContai2 === void 0 ? void 0 : _this3$menuNodeContai2.style('visibility', 'hidden');
        isOnDrag = true;
      });
      this.graph.event.on(CONSTANTS.EVENT.LAYOUT_TICK_END, function () {
        if (!isOnDrag) {
          var _this3$menuNodeContai3;
          (_this3$menuNodeContai3 = _this3.menuNodeContainer) === null || _this3$menuNodeContai3 === void 0 ? void 0 : _this3$menuNodeContai3.style('visibility', '');
          _this3.renderMenus();
        }
        isOnTick = false;
      });
      this.graph.event.on(CONSTANTS.EVENT.DRAG_END, function () {
        if (!isOnTick) {
          var _this3$menuNodeContai4;
          (_this3$menuNodeContai4 = _this3.menuNodeContainer) === null || _this3$menuNodeContai4 === void 0 ? void 0 : _this3$menuNodeContai4.style('visibility', '');
          _this3.renderMenus();
        }
        isOnDrag = false;
      });
      this.graph.event.on(CONSTANTS.EVENT.LAYOUT_ZOOM_START, function () {
        _this3.tooltipKeys.forEach(function (v) {
          return Tooltip.removeTip(v);
        });
      });
      if (!this.menuOptions.disableTransparentActions) {
        this.graph.event.on(CONSTANTS.EVENT.NODE_MOUSEENTER, function (node) {
          var _this3$menuNodeGroup;
          (_this3$menuNodeGroup = _this3.menuNodeGroup) === null || _this3$menuNodeGroup === void 0 ? void 0 : _this3$menuNodeGroup.filter(function (d) {
            return d.id !== node.id;
          }).style('opacity', 0.1);
          _this3.graph.getContainer().nodeGroup.filter(function (d) {
            return d.id !== node.id;
          }).selectAll('.graph__menu__node-circle').style('opacity', 0.1);
        });
        this.graph.event.on(CONSTANTS.EVENT.NODE_MOUSELEAVE, function () {
          var _this3$menuNodeGroup2;
          (_this3$menuNodeGroup2 = _this3.menuNodeGroup) === null || _this3$menuNodeGroup2 === void 0 ? void 0 : _this3$menuNodeGroup2.style('opacity', null);
          _this3.graph.getContainer().nodeGroup.selectAll('.graph__menu__node-circle').style('opacity', null);
        });
      }
    }
  }]);
  return NodeMenu;
}(BasePlugin);

export { NodeMenu as default };
