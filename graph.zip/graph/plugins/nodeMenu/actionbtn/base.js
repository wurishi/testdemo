import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _defineProperty from '@babel/runtime/helpers/defineProperty';
import { v4 } from 'uuid';

var BaseActionBtn = /*#__PURE__*/function () {
  function BaseActionBtn(graph, node, nodeActions, options, actionStore) {
    _classCallCheck(this, BaseActionBtn);
    _defineProperty(this, "graph", void 0);
    _defineProperty(this, "node", void 0);
    _defineProperty(this, "nodeActions", void 0);
    _defineProperty(this, "actionStore", void 0);
    _defineProperty(this, "options", void 0);
    _defineProperty(this, "key", void 0);
    _defineProperty(this, "className", void 0);
    _defineProperty(this, "disabled", void 0);
    this.graph = graph;
    this.node = node;
    this.nodeActions = nodeActions;
    this.options = options;
    this.key = v4();
    this.actionStore = actionStore;
  }
  _createClass(BaseActionBtn, [{
    key: "getContainer",
    value: function getContainer() {
      return document.querySelector(".graph__menu__item[data-key='".concat(this.key, "']"));
    }
  }, {
    key: "getText",
    value: function getText() {
      return '';
    }
  }, {
    key: "onClick",
    value: function onClick() {}
  }, {
    key: "onNodeActionUpdate",
    value: function onNodeActionUpdate() {
      return Promise.resolve();
    }
  }, {
    key: "onDestroy",
    value: function onDestroy() {}
  }]);
  return BaseActionBtn;
}();

export { BaseActionBtn as default };
