import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _assertThisInitialized from '@babel/runtime/helpers/assertThisInitialized';
import _inherits from '@babel/runtime/helpers/inherits';
import _possibleConstructorReturn from '@babel/runtime/helpers/possibleConstructorReturn';
import _getPrototypeOf from '@babel/runtime/helpers/getPrototypeOf';
import _defineProperty from '@babel/runtime/helpers/defineProperty';
import BaseActionBtn from './base.js';

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var ActionName = 'remove';
var RemoveActionBtn = /*#__PURE__*/function (_BaseActionBtn) {
  _inherits(RemoveActionBtn, _BaseActionBtn);
  var _super = _createSuper(RemoveActionBtn);
  function RemoveActionBtn(graph, node, _a, options) {
    var _this;
    _classCallCheck(this, RemoveActionBtn);
    _this = _super.call(this, graph, node, _a, options);
    _defineProperty(_assertThisInitialized(_this), "text", void 0);
    _defineProperty(_assertThisInitialized(_this), "className", 'graph__ppui__icon');
    _this.graph = graph;
    _this.text = "\uE957";
    return _this;
  }
  _createClass(RemoveActionBtn, [{
    key: "getText",
    value: function getText() {
      return this.text;
    }
  }, {
    key: "onClick",
    value: function onClick() {
      this.graph.selectedNodes = [];
      this.graph.selectedLinks = [];
      var newData = this.graph.removeNodes([this.node.id]);
      if (this.options.onRemoved) {
        this.options.onRemoved(this.node.id, newData);
      }
    }
  }]);
  return RemoveActionBtn;
}(BaseActionBtn);

export { ActionName, RemoveActionBtn as default };
