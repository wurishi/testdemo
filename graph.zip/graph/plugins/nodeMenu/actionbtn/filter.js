import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _assertThisInitialized from '@babel/runtime/helpers/assertThisInitialized';
import _inherits from '@babel/runtime/helpers/inherits';
import _possibleConstructorReturn from '@babel/runtime/helpers/possibleConstructorReturn';
import _getPrototypeOf from '@babel/runtime/helpers/getPrototypeOf';
import _defineProperty from '@babel/runtime/helpers/defineProperty';
import * as d3 from 'd3v7';
import BaseActionBtn from './base.js';
import { getRelatedNodesAndLinks, getData } from '../../../utils.js';
import CONSTANTS from '../../../constants.js';

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var STATUS = /*#__PURE__*/function (STATUS) {
  STATUS["ALL"] = "ALL";
  STATUS["ONLY_SEND"] = "ONLY_SEND";
  STATUS["ONLY_RECEIVE"] = "ONLY_RECEIVE";
  return STATUS;
}(STATUS || {});
var ActionName = 'filter';
var FilterFieldName = '@filterStatus';
var filterFlag = {};
var FilterActionBtn = /*#__PURE__*/function (_BaseActionBtn) {
  _inherits(FilterActionBtn, _BaseActionBtn);
  var _super = _createSuper(FilterActionBtn);
  function FilterActionBtn(graph, node, nodeActions, options, actionStore) {
    var _this;
    _classCallCheck(this, FilterActionBtn);
    _this = _super.call(this, graph, node, nodeActions, options, actionStore);
    _defineProperty(_assertThisInitialized(_this), "className", CONSTANTS.CLASSNAME.GRAPH_ICON);
    _defineProperty(_assertThisInitialized(_this), "status", void 0);
    _defineProperty(_assertThisInitialized(_this), "filters", void 0);
    // save node status value
    _defineProperty(_assertThisInitialized(_this), "filterableVertex", void 0);
    _defineProperty(_assertThisInitialized(_this), "filterData", void 0);
    _defineProperty(_assertThisInitialized(_this), "extraLinkData", void 0);
    _defineProperty(_assertThisInitialized(_this), "curAction", void 0);
    _defineProperty(_assertThisInitialized(_this), "onEventLayoutAfterDraw", function () {
      _this.onEventThrotte(function () {
        _this.updateGraph();
      });
    });
    _defineProperty(_assertThisInitialized(_this), "onEventApplyExtraLinks", function (data) {
      _this.extraLinkData = data;
      _this.onEventThrotte(function () {
        // this.updateGraph()
        if (filterFlag.isDataChangeApplying) {
          clearTimeout(filterFlag.isDataChangeApplying);
        }
        _this.applyFilter();
      }, 'APPLY_EXTRA_LINKS');
    });
    _defineProperty(_assertThisInitialized(_this), "onEventChangeSelectedNodes", function () {
      _this.onEventAction(function () {
        setTimeout(function () {
          return _this.updateMenu();
        }); // should be call after nodemenu dom draw
      });
    });
    _defineProperty(_assertThisInitialized(_this), "onEventAction", function (act, flag, ignoreStatus) {
      var evtFlag = flag || 'isApplying';
      if ((_this.status !== STATUS.ALL || ignoreStatus) && _this.curAction) {
        if (filterFlag[evtFlag]) {
          clearTimeout(filterFlag[evtFlag]);
        }
        filterFlag[evtFlag] = setTimeout(function () {
          act();
          filterFlag[evtFlag] = false;
        });
      }
    });
    _defineProperty(_assertThisInitialized(_this), "onEventThrotte", function (act, flag) {
      var evtFlag = flag || 'isApplyingThrotte';
      if (_this.status !== STATUS.ALL && !filterFlag[evtFlag] && _this.curAction) {
        filterFlag[evtFlag] = true;
        act();
        setTimeout(function () {
          filterFlag[evtFlag] = false;
        });
      }
    });
    _defineProperty(_assertThisInitialized(_this), "onGraphDataChange", function (ignoreStatus, resolve) {
      _this.curAction = _this.nodeActions[_this.node.id].find(function (v) {
        return v.name === ActionName;
      });
      var flagName = 'isDataChangeApplying';
      var flagResolveName = 'isDataChangeApplying_resolve';
      filterFlag[flagResolveName] = filterFlag[flagResolveName] || {};
      if (resolve) {
        filterFlag[flagResolveName][_this.node.id] = resolve;
      }
      var onResolve = function onResolve() {
        if (resolve) {
          resolve();
        }
        for (var k in filterFlag[flagResolveName]) {
          if (k !== _this.node.id) {
            filterFlag[flagResolveName][k]();
          }
        }
        filterFlag[flagResolveName] = {};
      };
      _this.onEventAction(function () {
        _this.applyFilter();
        onResolve();
      }, flagName, ignoreStatus);
    });
    _defineProperty(_assertThisInitialized(_this), "updateGraph", function () {
      var _this$graph$getContai = _this.graph.getContainer(),
        nodeGroup = _this$graph$getContai.nodeGroup,
        linkGroup = _this$graph$getContai.linkGroup;
      linkGroup.classed('graph__menu__graph-item-hidden', function (d) {
        var _this$filterData$link;
        return (_this$filterData$link = _this.filterData.linkMap[d.id]) === null || _this$filterData$link === void 0 ? void 0 : _this$filterData$link.hidden;
      }).classed('graph__menu__graph-link-transparent', function (d) {
        var _this$filterData$link2;
        return (_this$filterData$link2 = _this.filterData.linkMap[d.id]) === null || _this$filterData$link2 === void 0 ? void 0 : _this$filterData$link2.transparent;
      }).classed('graph__menu__link-is-reserved', function (d) {
        var _this$filterData$link3;
        return (_this$filterData$link3 = _this.filterData.linkMap[d.id]) === null || _this$filterData$link3 === void 0 ? void 0 : _this$filterData$link3.dash;
      });
      if (_this.extraLinkData && _this.extraLinkData.links) {
        var getClassed = function getClassed(d, filedName) {
          if (_this.filterData.linkMap[d.id]) {
            return _this.filterData.linkMap[d.id][filedName];
          }
          var relatedId = _this.extraLinkData.relatedMap[d.id];
          if (relatedId && _this.filterData.linkMap[relatedId]) {
            return _this.filterData.linkMap[relatedId][filedName];
          }
          return false;
        };
        _this.extraLinkData.links.classed('graph__menu__graph-item-hidden', function (d) {
          return getClassed(d, 'hidden');
        }).classed('graph__menu__graph-link-transparent', function (d) {
          return getClassed(d, 'transparent');
        }).classed('graph__menu__link-is-reserved', function (d) {
          return getClassed(d, 'dash');
        });
      }
      nodeGroup.classed('graph__menu__graph-item-hidden', function (d) {
        var _this$filterData$node;
        return (_this$filterData$node = _this.filterData.nodeMap[d.id]) === null || _this$filterData$node === void 0 ? void 0 : _this$filterData$node.hidden;
      }).classed('graph__menu__graph-node-transparent', function (d) {
        var _this$filterData$node2;
        return (_this$filterData$node2 = _this.filterData.nodeMap[d.id]) === null || _this$filterData$node2 === void 0 ? void 0 : _this$filterData$node2.transparent;
      }).classed('graph__menu__node-has-filter', function (d) {
        return !!_this.filters[d.id];
      });
      _this.updateMenu();
    });
    _this.curAction = _this.nodeActions[_this.node.id].find(function (v) {
      return v.name === ActionName;
    });
    _this.status = _this.getStatus();
    _this.filters = {};
    _this.filterData = {
      nodeMap: {},
      linkMap: {}
    };
    _this.graph.event.on(CONSTANTS.EVENT.CHANGE_GRAPH_DATA, _this.onGraphDataChange);
    _this.graph.event.on(CONSTANTS.EVENT.LAYOUT_AFTER_DRAW, _this.onEventLayoutAfterDraw);
    _this.graph.event.on(CONSTANTS.EVENT.APPLY_EXTRA_LINKS, _this.onEventApplyExtraLinks);
    _this.graph.event.on(CONSTANTS.EVENT.CHANGE_SELECTED_NODES, _this.onEventChangeSelectedNodes);
    _this.onGraphDataChange();
    if (actionStore && !actionStore.get('filterData')) {
      actionStore.set('filterData', _this.filterData);
    }
    return _this;
  }
  _createClass(FilterActionBtn, [{
    key: "getStatus",
    value: function getStatus() {
      return this.curAction ? this.curAction[FilterFieldName] || STATUS.ALL : STATUS.ALL;
    }
  }, {
    key: "setStatus",
    value: function setStatus(value) {
      this.status = value;
      var act = this.nodeActions[this.node.id].find(function (v) {
        return v.name === ActionName;
      });
      act[FilterFieldName] = value;
      this.curAction = act;
    }
  }, {
    key: "isMatchFilter",
    value: function isMatchFilter(sourceId, targetId) {
      var sourceStatus = this.filters[sourceId];
      var targetStatus = this.filters[targetId];
      if (!sourceStatus && !targetStatus) {
        return true;
      }
      if (sourceStatus === targetStatus && sourceStatus === STATUS.ALL) {
        return true;
      }
      if (!sourceStatus) {
        return targetStatus === STATUS.ONLY_RECEIVE;
      }
      if (!targetStatus) {
        return sourceStatus === STATUS.ONLY_SEND;
      }
      return sourceStatus === STATUS.ONLY_SEND && targetStatus === STATUS.ONLY_RECEIVE;
    }
  }, {
    key: "generateFilterData",
    value: function generateFilterData(data) {
      var _this2 = this;
      this.filterData = {
        nodeMap: {},
        linkMap: {}
      };
      var pendingLinks = [];
      var pendingNodeIds = [];
      var validateIds = new Set();
      var staticNodeIds = typeof this.options.staticNodeIds === 'function' ? this.options.staticNodeIds() : this.options.staticNodeIds;
      data.links.forEach(function (v) {
        var sourceId = v.source.id;
        var targetId = v.target.id;
        var bothHasFilter = !!(_this2.filters[sourceId] && _this2.filters[targetId]);
        var matchFilter = _this2.isMatchFilter(sourceId, targetId);
        var connected = v.arrow && (bothHasFilter || matchFilter);
        if (connected) {
          validateIds.add(sourceId);
          validateIds.add(targetId);
        } else {
          if (!v.arrow) {
            pendingNodeIds.push(sourceId);
            pendingNodeIds.push(targetId);
            pendingLinks.push(v);
          }
        }
        _this2.filterData.linkMap[v.id] = {
          matchFilter: matchFilter,
          dash: _this2.isEdgeReversed(v),
          transparent: false,
          hidden: false
        };
      });
      pendingNodeIds = pendingNodeIds.filter(function (nid) {
        return !validateIds.has(nid) && !_this2.filterableVertex.has(nid);
      });
      data.links.forEach(function (v) {
        var sourceId = v.source.id;
        var targetId = v.target.id;
        var bothFilterable = _this2.filterableVertex.has(sourceId) && _this2.filterableVertex.has(targetId);
        var bothValidate = validateIds.has(sourceId) && validateIds.has(targetId);
        var l = _this2.filterData.linkMap[v.id];
        var hidden = !bothFilterable;
        if (hidden) {
          hidden = v.arrow ? !l.matchFilter : !bothValidate;
        }
        l.hidden = hidden;
        l.transparent = bothFilterable && !l.matchFilter && !l.dash;
      });
      var pendingLinkIds = pendingLinks.map(function (v) {
        return v.id;
      });
      data.nodes.forEach(function (v) {
        if (data.links.length === 0) {
          validateIds.add(v.id);
        }
        var hidden = !validateIds.has(v.id) && !_this2.filterableVertex.has(v.id);
        var isStatic = staticNodeIds && staticNodeIds.includes(v.id);
        var transparent = false;
        if (!isStatic && !validateIds.has(v.id) && !_this2.filters[v.id]) {
          var relatedLinks = new Set(getRelatedNodesAndLinks([v.id], data).links.map(function (l) {
            return l.id;
          }));
          if (_this2.filterableVertex.has(v.id)) {
            if (relatedLinks.size === 1) {
              var l = _this2.filterData.linkMap[Array.from(relatedLinks)[0]];
              transparent = l.transparent;
            } else {
              transparent = Array.from(relatedLinks).filter(function (d) {
                return !pendingLinkIds.includes(d);
              }).every(function (d) {
                var l = _this2.filterData.linkMap[d];
                return l.transparent;
              });
            }
          }
          if (pendingNodeIds.includes(v.id)) {
            var relatedNonPendingLinkds = Array.from(relatedLinks).filter(function (d) {
              return !pendingLinkIds.includes(d);
            });
            hidden = relatedNonPendingLinkds.some(function (d) {
              var l = _this2.filterData.linkMap[d] || {
                hidden: true
              };
              return l.hidden;
            });
          }
        }
        _this2.filterData.nodeMap[v.id] = {
          filterable: _this2.filterableVertex.has(v.id),
          filter: _this2.filters[v.id] || (_this2.filterableVertex.has(v.id) ? STATUS.ALL : ''),
          transparent: transparent,
          hidden: isStatic ? false : hidden
        };
      });
      /** links without arrow, status depend on source and target nodes' status */
      pendingLinks.forEach(function (v) {
        var sourceNode = _this2.filterData.nodeMap[v.source.id];
        var targetNode = _this2.filterData.nodeMap[v.target.id];
        var link = _this2.filterData.linkMap[v.id];
        link.transparent = sourceNode.transparent || targetNode.transparent;
        link.hidden = sourceNode.hidden || targetNode.hidden;
      });
    }
  }, {
    key: "isEdgeReversed",
    value: function isEdgeReversed(link) {
      if (!link.arrow) {
        return false;
      }
      var sourceId = link.source.id;
      var targetId = link.target.id;
      var sourceStatus = this.filters[sourceId];
      var targetStatus = this.filters[targetId];
      if (sourceStatus && targetStatus) {
        if (sourceStatus === STATUS.ONLY_RECEIVE && targetStatus === STATUS.ONLY_SEND) {
          return false;
        }
        return sourceStatus === STATUS.ONLY_RECEIVE || targetStatus === STATUS.ONLY_SEND;
      }
      return false;
    }
  }, {
    key: "transFilter",
    value: function transFilter() {
      var _this3 = this;
      var data = getData.call(this.graph);
      this.filterData = {
        nodeMap: {},
        linkMap: {}
      };
      this.filters = {};
      this.filterableVertex = new Set();
      var _loop = function _loop(id) {
        var n = _this3.nodeActions[id].find(function (v) {
          return v.name === ActionName;
        });
        if (n) {
          if (!data.nodes.find(function (v) {
            return v.id === id;
          })) {
            /** if one node be deleted or be moved into cluster, reset its filter status */
            delete n[FilterFieldName];
          }
          _this3.filterableVertex.add(id);
          if (n[FilterFieldName] && n[FilterFieldName] !== STATUS.ALL) {
            _this3.filters[id] = n[FilterFieldName];
          }
        }
      };
      for (var id in this.nodeActions) {
        _loop(id);
      }
      var staticNodeIds = typeof this.options.staticNodeIds === 'function' ? this.options.staticNodeIds() : this.options.staticNodeIds;
      if (staticNodeIds) {
        staticNodeIds.forEach(function (v) {
          return _this3.filterableVertex.add(v);
        });
      }
      this.generateFilterData(data);
    }
  }, {
    key: "updateMenu",
    value: function updateMenu() {
      var _this4 = this;
      var menuGroup = this.graph.getContainer().svg.selectAll('.graph__menu');
      menuGroup.classed('graph__menu__graph-item-hidden', function (d) {
        var _this4$filterData$nod;
        return (_this4$filterData$nod = _this4.filterData.nodeMap[d.id]) === null || _this4$filterData$nod === void 0 ? void 0 : _this4$filterData$nod.hidden;
      }).classed('graph__menu__graph-node-transparent', function (d) {
        var _this4$filterData$nod2;
        return (_this4$filterData$nod2 = _this4.filterData.nodeMap[d.id]) === null || _this4$filterData$nod2 === void 0 ? void 0 : _this4$filterData$nod2.transparent;
      }).classed('graph__menu__node-has-filter', function (d) {
        return !!_this4.filters[d.id];
      });
    }
  }, {
    key: "applyFilter",
    value: function applyFilter() {
      this.transFilter();
      this.updateGraph();
      if (this.actionStore) {
        this.actionStore.set('filterData', this.filterData);
      }
    }
  }, {
    key: "getText",
    value: function getText() {
      this.status = this.getStatus();
      switch (this.status) {
        case STATUS.ONLY_SEND:
          return "\uE91D";
        case STATUS.ONLY_RECEIVE:
          return "\uE91C";
        default:
          return "\uE91E";
      }
    }
  }, {
    key: "onClick",
    value: function onClick() {
      var _this$options;
      switch (this.status) {
        case STATUS.ONLY_SEND:
          this.setStatus(STATUS.ONLY_RECEIVE);
          break;
        case STATUS.ONLY_RECEIVE:
          this.setStatus(STATUS.ALL);
          break;
        default:
          this.setStatus(STATUS.ONLY_SEND);
      }
      this.applyFilter();
      d3.select(this.getContainer()).select('.graph__menu__item__text').text(this.getText());
      if ((_this$options = this.options) !== null && _this$options !== void 0 && _this$options.onFiltered) {
        var _this$options2;
        (_this$options2 = this.options) === null || _this$options2 === void 0 ? void 0 : _this$options2.onFiltered({
          id: this.node.id,
          status: this.getStatus()
        }, this.filterData);
      }
    }
  }, {
    key: "onNodeActionUpdate",
    value: function onNodeActionUpdate() {
      var _this5 = this;
      return new Promise(function (resolve) {
        _this5.status = _this5.getStatus();
        _this5.onGraphDataChange(true, resolve);
        d3.select(_this5.getContainer()).select('.graph__menu__item__text').text(_this5.getText());
      });
    }
  }, {
    key: "onDestroy",
    value: function onDestroy() {
      this.graph.event.removeListener(CONSTANTS.EVENT.CHANGE_GRAPH_DATA, this.onGraphDataChange);
      this.graph.event.removeListener(CONSTANTS.EVENT.LAYOUT_AFTER_DRAW, this.onEventLayoutAfterDraw);
      this.graph.event.removeListener(CONSTANTS.EVENT.APPLY_EXTRA_LINKS, this.onEventApplyExtraLinks);
      this.graph.event.removeListener(CONSTANTS.EVENT.CHANGE_SELECTED_NODES, this.onEventChangeSelectedNodes);
    }
  }]);
  return FilterActionBtn;
}(BaseActionBtn);

export { ActionName, FilterActionBtn as default };
