import _typeof from '@babel/runtime/helpers/typeof';
import _classCallCheck from '@babel/runtime/helpers/classCallCheck';
import _createClass from '@babel/runtime/helpers/createClass';
import _defineProperty from '@babel/runtime/helpers/defineProperty';
import RemoveActionBtn, { ActionName } from './remove.js';
import FilterActionBtn, { ActionName as ActionName$1 } from './filter.js';
import { getData, deepCopy } from '../../../utils.js';

var _actionButtons;
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
var actionButtons = (_actionButtons = {}, _defineProperty(_actionButtons, ActionName, RemoveActionBtn), _defineProperty(_actionButtons, ActionName$1, FilterActionBtn), _actionButtons);
var NodeAction = /*#__PURE__*/function () {
  function NodeAction(options) {
    var _this = this;
    _classCallCheck(this, NodeAction);
    _defineProperty(this, "cache", void 0);
    _defineProperty(this, "nodeActions", void 0);
    _defineProperty(this, "_actionStore", void 0);
    // storage for action
    _defineProperty(this, "options", void 0);
    _defineProperty(this, "actionStore", {
      get: function get(field) {
        if (field) {
          return _this._actionStore[field];
        }
        return _this._actionStore;
      },
      set: function set(field, value) {
        var prevValue = _this._actionStore[field];
        var hasChange = false;
        if (_typeof(prevValue) === 'object' && _typeof(value) === 'object') {
          hasChange = JSON.stringify(prevValue) !== JSON.stringify(value);
        } else {
          hasChange = prevValue !== value;
        }
        if (hasChange) {
          _this._actionStore[field] = value;
          if (_this.options.onActionStoreUpdate) {
            _this.options.onActionStoreUpdate(field, _typeof(value) === 'object' ? deepCopy(value) : value);
          }
        }
      }
    });
    this.cache = {};
    this.nodeActions = {};
    this._actionStore = {};
    this.options = options;
  }
  _createClass(NodeAction, [{
    key: "getCacheKey",
    value: function getCacheKey(nodeId, name) {
      return "".concat(nodeId, "@").concat(name);
    }
  }, {
    key: "registerActionButtons",
    value: function registerActionButtons(graph, menuOptions, syncPresetNodeActions) {
      var _this2 = this;
      menuOptions = menuOptions || this.options;
      if (!menuOptions.getActions) {
        return;
      }
      this.options = menuOptions;
      var presetActionsMap = {};
      if (syncPresetNodeActions) {
        var _menuOptions$presetNo;
        (_menuOptions$presetNo = menuOptions.presetNodeActions) === null || _menuOptions$presetNo === void 0 ? void 0 : _menuOptions$presetNo.forEach(function (v) {
          presetActionsMap["".concat(v.nodeId, "@").concat(v.name)] = v;
        });
      }
      var _getData$call = getData.call(graph),
        nodes = _getData$call.nodes;
      var curCacheKeys = new Set(Object.keys(this.cache));
      var registerByNode = function registerByNode(node) {
        var oldNodeActions = _this2.nodeActions[node.id] || [];
        var actions = menuOptions.getActions(node);
        if (actions) {
          _this2.nodeActions[node.id] = [];
          actions.forEach(function (v) {
            var name = typeof v === 'string' ? v : v.name;
            var disabled = typeof v === 'string' ? false : !!v.disabled;
            if (typeof v === 'string' || actionButtons[v.name]) {
              var _cacheKey = _this2.getCacheKey(node.id, name);
              if (_this2.cache[_cacheKey]) {
                _this2.nodeActions[node.id].push(_objectSpread(_objectSpread({}, oldNodeActions.find(function (o) {
                  return o.cacheKey === _cacheKey;
                })), {}, {
                  name: name,
                  cacheKey: _cacheKey
                }, presetActionsMap["".concat(node.id, "@").concat(name)]));
                curCacheKeys["delete"](_cacheKey);
                _this2.cache[_cacheKey].disabled = disabled;
                return;
              }
              var BtnClass = actionButtons[name];
              var options = typeof v === 'string' ? null : v;
              _this2.nodeActions[node.id].push(_objectSpread({
                name: name,
                cacheKey: _cacheKey
              }, presetActionsMap["".concat(node.id, "@").concat(name)]));
              var instance = new BtnClass(graph, node, _this2.nodeActions, options || {}, _this2.actionStore);
              _this2.cache[_cacheKey] = instance;
              _this2.cache[_cacheKey].disabled = disabled;
            } else {
              _this2.nodeActions[node.id].push(_objectSpread({
                name: name,
                instance: v
              }, presetActionsMap["".concat(node.id, "@").concat(v.name)]));
            }
          });
        }
        var subNodesField = menuOptions.subNodesField || 'children';
        if (node[subNodesField]) {
          node[subNodesField].forEach(function (n) {
            return registerByNode(n);
          });
        }
      };
      nodes.forEach(function (node) {
        return registerByNode(node);
      });
      curCacheKeys.forEach(function (v) {
        if (_this2.cache[v] && _this2.cache[v].onDestroy) {
          _this2.cache[v].onDestroy();
        }
        delete _this2.cache[v];
      });
    }
  }, {
    key: "setNodeActions",
    value: function setNodeActions(data, resetActionNames) {
      var _this3 = this;
      var promiseList = [];
      Object.keys(this.nodeActions).forEach(function (nodeId) {
        var actions = _this3.nodeActions[nodeId] || [];
        actions.forEach(function (act) {
          var hasChange = false;
          if (resetActionNames && resetActionNames.includes(act.name)) {
            Object.keys(act).filter(function (f) {
              return f.startsWith('@');
            }).forEach(function (f) {
              delete act[f];
              hasChange = true;
            });
          }
          var presetMatch = data.find(function (d) {
            return d.nodeId === nodeId && d.name === act.name;
          });
          if (presetMatch) {
            Object.assign(act, presetMatch);
            hasChange = true;
          }
          if (hasChange) {
            var inst = act.instance || _this3.cache[act.cacheKey];
            if (inst && inst.onNodeActionUpdate) {
              promiseList.push(inst.onNodeActionUpdate());
            }
          }
        });
      });
      if (promiseList.length > 0) {
        return Promise.all(promiseList).then(function () {});
      }
      return Promise.resolve();
    }
  }, {
    key: "getActionButtons",
    value: function getActionButtons(node) {
      var _this$nodeActions$nod;
      var cache = this.cache;
      return (_this$nodeActions$nod = this.nodeActions[node.id]) === null || _this$nodeActions$nod === void 0 ? void 0 : _this$nodeActions$nod.map(function (v) {
        return cache[v.cacheKey] || v.instance;
      });
    }
  }, {
    key: "getActionStore",
    value: function getActionStore(field) {
      return this._actionStore[field];
    }
  }]);
  return NodeAction;
}();

export { NodeAction as default };
