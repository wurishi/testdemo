import styleInject from 'style-inject/dist/style-inject.es.js';

var css_248z = ".graph__menu__item {\n  cursor: pointer;\n}\n.graph__menu__item:hover {\n  opacity: 0.9;\n}\n\n.graph__menu__item.graph__menu__item-disabled {\n  cursor: not-allowed;\n  opacity: 1;\n}\n\n.graph__menu__item__path {\n  fill: rgba(0, 0, 0, 0.8);\n  stroke: rgba(0, 0, 0, 0.25);\n}\n\n.graph__menu__item__text {\n  text-anchor: middle;\n  fill: #fff;\n  font-size: 1.5rem;\n  font-weight: normal;\n  pointer-events: none;\n}\n\n.graph__menu__graph-item-hidden {\n  visibility: hidden;\n}\n\n.graph__menu__graph-link-transparent {\n  opacity: 0.1;\n}\n\n.graph__menu__graph-node-transparent > * {\n  opacity: 0.1;\n}\n.graph__menu__graph-node-transparent > .graph__menu {\n  opacity: 1;\n}\n\n.graph__menu__link-is-reserved {\n  opacity: 0.5;\n}\n.graph__menu__link-is-reserved .graph__link--path {\n  stroke-dasharray: 10, 5;\n}\n\n.graph__menu__node-has-filter .graph__node {\n  stroke: #000000;\n}";
styleInject(css_248z);

export { css_248z as default };
